IfxCcu6_PinMap.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.c :
IfxCcu6_PinMap.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_PinMap\IfxCcu6_PinMap.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_PinMap\IfxCcu6_PinMap.h :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxCcu6_PinMap.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
IfxCcu6_PinMap.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
