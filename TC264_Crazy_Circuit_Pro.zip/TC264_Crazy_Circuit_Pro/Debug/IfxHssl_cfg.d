IfxHssl_cfg.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.c :
IfxHssl_cfg.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxHssl_cfg.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxHssl_cfg.h :
IfxHssl_cfg.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxHssl_cfg.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxHssl_cfg.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxHssl_cfg.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxHssl_cfg.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxHssl_cfg.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxHssl_cfg.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxHssl_cfg.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHssl_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHssl_reg.h" :
IfxHssl_cfg.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHssl_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHssl_regdef.h" :
IfxHssl_cfg.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
IfxHssl_cfg.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHsct_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHsct_reg.h" :
IfxHssl_cfg.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHsct_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHsct_regdef.h" :
