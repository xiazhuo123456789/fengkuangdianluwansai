IfxI2c.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/I2c/Std/IfxI2c.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/I2c/Std/IfxI2c.c :
IfxI2c.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\I2c\Std\IfxI2c.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\I2c\Std\IfxI2c.h :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxI2c_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxI2c_cfg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxI2c.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxI2c_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxI2c_reg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxI2c_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxI2c_regdef.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxI2c_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxI2c_bf.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxI2c_PinMap.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxI2c_PinMap.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
IfxI2c.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
