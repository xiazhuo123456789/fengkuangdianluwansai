IfxIom.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/Iom/Std/IfxIom.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/Iom/Std/IfxIom.c :
IfxIom.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Iom\Std\IfxIom.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Iom\Std\IfxIom.h :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxIom_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxIom_cfg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxIom_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxIom_reg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxIom_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxIom_regdef.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxIom.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
IfxIom.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
