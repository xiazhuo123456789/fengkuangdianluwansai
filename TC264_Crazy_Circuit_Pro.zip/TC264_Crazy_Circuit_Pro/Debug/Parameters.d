Parameters.o :	../code/Parameters.c
../code/Parameters.c :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_headfile.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_headfile.h" :
Parameters.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
Parameters.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
Parameters.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
Parameters.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
Parameters.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
Parameters.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h" :
Parameters.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Parameters.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_typedef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_typedef.h" :
Parameters.o :	"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"E:\��������\ѧ�ƾ���\���ܳ���ѹ��ͷ��Ӣ����ѧϰ����\Infineon\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_clock.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_clock.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_debug.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_debug.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_interrupt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_interrupt.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_fifo.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_fifo.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_font.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_font.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_function.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_function.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\user\isr_config.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\user\isr_config.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_adc.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_adc.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_delay.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_delay.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_dma.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_dma.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_exti.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_exti.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_encoder.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_encoder.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_exti.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_exti.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_flash.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_flash.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_gpio.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_gpio.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_pit.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_pit.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_pwm.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_pwm.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_soft_iic.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_soft_iic.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_spi.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_spi.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_soft_spi.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_soft_spi.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_uart.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_uart.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_timer.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_timer.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_absolute_encoder.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_absolute_encoder.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_ble6a20.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_ble6a20.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_bluetooth_ch9141.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_bluetooth_ch9141.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_gnss.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_gnss.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_camera.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_camera.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_uart.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_driver\zf_driver_uart.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_type.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_type.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_dl1a.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_dl1a.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_dl1b.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_dl1b.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_icm20602.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_icm20602.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_imu660ra.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_imu660ra.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_imu660rb.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_imu660rb.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_imu660rx.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_imu660rx.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_imu963ra.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_imu963ra.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_ips114.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_ips114.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_ips200.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_ips200.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_ips200pro.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_ips200pro.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_key.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_key.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_menc15a.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_menc15a.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_mpu6050.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_mpu6050.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_mt9v03x_double.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_mt9v03x_double.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_oled.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_oled.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_ov7725.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_ov7725.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_scc8660.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_scc8660.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_tft180.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_tft180.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_tsl1401.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_tsl1401.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_uart_receiver.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_uart_receiver.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_virtual_oscilloscope.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_virtual_oscilloscope.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_wifi_uart.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_wifi_uart.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_wifi_spi.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_wifi_spi.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_wireless_uart.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_device\zf_device_wireless_uart.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_components\seekfree_assistant.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_components\seekfree_assistant.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_components\seekfree_assistant_interface.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_components\seekfree_assistant_interface.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\Encoder.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\Encoder.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_headfile.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\libraries\\zf_common\zf_common_headfile.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\Eye_of_Providence.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\Eye_of_Providence.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\Imu660.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\Imu660.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\menu.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\menu.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\Motor.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\Motor.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\Parameters.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\Parameters.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\wireless.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\wireless.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\user\isr.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\user\isr.h" :
Parameters.o :	"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\eeprom.h"
"C:\\Users\\Administrator\\AURIX-v1.10.2-workspace\\TC264_Crazy_Circuit_Pro\\code\eeprom.h" :
