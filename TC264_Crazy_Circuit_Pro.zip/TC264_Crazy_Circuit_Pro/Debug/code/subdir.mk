################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../code/Encoder.c \
../code/Eye_of_Providence.c \
../code/Imu660.c \
../code/Motor.c \
../code/Parameters.c \
../code/eeprom.c \
../code/menu.c \
../code/wireless.c 

COMPILED_SRCS += \
code/Encoder.src \
code/Eye_of_Providence.src \
code/Imu660.src \
code/Motor.src \
code/Parameters.src \
code/eeprom.src \
code/menu.src \
code/wireless.src 

C_DEPS += \
code/Encoder.d \
code/Eye_of_Providence.d \
code/Imu660.d \
code/Motor.d \
code/Parameters.d \
code/eeprom.d \
code/menu.d \
code/wireless.d 

OBJS += \
code/Encoder.o \
code/Eye_of_Providence.o \
code/Imu660.o \
code/Motor.o \
code/Parameters.o \
code/eeprom.o \
code/menu.o \
code/wireless.o 


# Each subdirectory must supply rules for building sources it contributes
code/Encoder.src: ../code/Encoder.c code/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/Administrator/AURIX-v1.10.2-workspace/TC264_Crazy_Circuit_Pro/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Encoder.o: code/Encoder.src code/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Eye_of_Providence.src: ../code/Eye_of_Providence.c code/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/Administrator/AURIX-v1.10.2-workspace/TC264_Crazy_Circuit_Pro/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Eye_of_Providence.o: code/Eye_of_Providence.src code/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Imu660.src: ../code/Imu660.c code/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/Administrator/AURIX-v1.10.2-workspace/TC264_Crazy_Circuit_Pro/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Imu660.o: code/Imu660.src code/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Motor.src: ../code/Motor.c code/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/Administrator/AURIX-v1.10.2-workspace/TC264_Crazy_Circuit_Pro/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Motor.o: code/Motor.src code/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/Parameters.src: ../code/Parameters.c code/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/Administrator/AURIX-v1.10.2-workspace/TC264_Crazy_Circuit_Pro/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/Parameters.o: code/Parameters.src code/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/eeprom.src: ../code/eeprom.c code/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/Administrator/AURIX-v1.10.2-workspace/TC264_Crazy_Circuit_Pro/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/eeprom.o: code/eeprom.src code/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/menu.src: ../code/menu.c code/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/Administrator/AURIX-v1.10.2-workspace/TC264_Crazy_Circuit_Pro/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/menu.o: code/menu.src code/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
code/wireless.src: ../code/wireless.c code/subdir.mk
	cctc -cs --dep-file="$(*F).d" --misrac-version=2004 -D__CPU__=tc26xb "-fC:/Users/Administrator/AURIX-v1.10.2-workspace/TC264_Crazy_Circuit_Pro/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
code/wireless.o: code/wireless.src code/subdir.mk
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-code

clean-code:
	-$(RM) code/Encoder.d code/Encoder.o code/Encoder.src code/Eye_of_Providence.d code/Eye_of_Providence.o code/Eye_of_Providence.src code/Imu660.d code/Imu660.o code/Imu660.src code/Motor.d code/Motor.o code/Motor.src code/Parameters.d code/Parameters.o code/Parameters.src code/eeprom.d code/eeprom.o code/eeprom.src code/menu.d code/menu.o code/menu.src code/wireless.d code/wireless.o code/wireless.src

.PHONY: clean-code

