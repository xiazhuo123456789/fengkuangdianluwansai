/*
 * Imu660.h
 *
 *  Created on: 2026��1��18��
 *      Author: ���
 */

#ifndef CODE_IMU660_H_
#define CODE_IMU660_H_

typedef struct
{
	int gyro_yaw;
	double yaw_angle;
	double target_angle;
	double diff_angle;
}POSTURE;//6
	

extern int gyro_flag;
extern int gyro_count;
extern POSTURE post;

void gyro_init(void);
void Gyro_Get(void);
void Gyro_Get_Angle(void);


#endif /* CODE_IMU660_H_ */
