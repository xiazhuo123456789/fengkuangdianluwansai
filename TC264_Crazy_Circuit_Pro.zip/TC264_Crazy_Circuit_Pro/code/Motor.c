/*
 * Motor.c
 *
 *  Created on: 2026��1��18��
 *      Author: Administrator
 */

#include "zf_common_headfile.h"

ERROR error = {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
MOTOR motor = {0,0,0,0,0,0,0,0,0,0};

float kp_m = 0;
float ki_m = 0;
float kd_m = 0;
int ki_out = 0;
int kp_out = 0;
int kd_out = 0;
int pid_out = 0;
int motor_range = 0;     //����޷�
int target_speed = 0;    //Ŀ���ٶ�
int slow_start_speed = 0;    //�������ٶ�
int duct_duty = 500;        //���ȳ�ʼռ�ձ�

void motor_init(void)
{
    pwm_init(MOTOR_L_PWM, 17000, 0);
    pwm_init(MOTOR_R_PWM, 17000, 0);
    pwm_init(MOTOR_DUCT_PIN, 50, 500);//��ˢ���

    gpio_init(MOTOR_L_DIR, GPO, GPIO_HIGH, GPO_PUSH_PULL);
    gpio_init(MOTOR_R_DIR, GPO, GPIO_HIGH, GPO_PUSH_PULL);
}

void motor_l_duty(int duty)
{
    if(duty >= 0)
    {
        gpio_set_level(MOTOR_L_DIR, GPIO_HIGH);
    }
    else
    {
        gpio_set_level(MOTOR_L_DIR, GPIO_LOW);
        duty = -duty;
    }
    pwm_set_duty(MOTOR_L_PWM, duty);
}

void motor_r_duty(int duty)
{
    if(duty >= 0)
    {
        gpio_set_level(MOTOR_R_DIR, GPIO_HIGH);
    }
    else
    {
        gpio_set_level(MOTOR_R_DIR, GPIO_LOW);
        duty = -duty;
    }
    pwm_set_duty(MOTOR_R_PWM, duty);
}

void motor_fuya_duty(int duty)
{
    pwm_set_duty(MOTOR_DUCT_PIN, duty);
}

void Speed_Loop(void)
{
    float A = 0.9;  // ��ͨ�˲�ϵ��
	error.currentL = (double)(motor.speedTL - encoder.speedL);
	error.derivationL = error.currentL - 2*error.previousL + error.beforeL;
	error.proportionL = error.currentL - error.previousL;
	error.integrationL = error.currentL;
	
	error.beforeL = error.previousL;
	error.previousL = error.currentL;
	kp_out+=(int)(kp_m*error.proportionL);
	ki_out+=(int)(ki_m*error.integrationL);
    kd_out+=(int)(kd_m*error.derivationL);
    
    pid_out = kp_out + ki_out + kd_out;
    motor.l_speed_out_last = motor.l_speed_out;
    motor.l_speed_out += (kp_m*error.proportionL + ki_m*error.integrationL + kd_m*error.derivationL);
	motor.l_speed_out = (A*motor.l_speed_out + (1-A)*motor.l_speed_out_last);
	
	error.currentR = (double)(motor.speedTR - encoder.speedR);
	error.derivationR = error.currentR - 2*error.previousR + error.beforeR;
	error.proportionR = error.currentR - error.previousR;
	error.integrationR = error.currentR;
	
	error.beforeR = error.previousR;
	error.previousR = error.currentR;
    motor.r_speed_out_last = motor.r_speed_out;
	motor.r_speed_out += (kp_m*error.proportionR + ki_m*error.integrationR + kd_m*error.derivationR);
	motor.r_speed_out = (A*motor.r_speed_out + (1-A)*motor.r_speed_out_last);

	if(motor.l_speed_out>motor_range)  motor.l_speed_out =  motor_range;
	if(motor.l_speed_out<-motor_range) motor.l_speed_out = -motor_range;
	if(motor.r_speed_out>motor_range)  motor.r_speed_out =  motor_range;
	if(motor.r_speed_out<-motor_range) motor.r_speed_out = -motor_range;

    motor.dutyL = (int)motor.l_speed_out;
    motor.dutyR = (int)motor.r_speed_out;

    motor_l_duty(motor.dutyL);
    motor_r_duty(motor.dutyR);
}
 
float Inner_Ring_P = 0,Inner_Ring_D=0;   
float Inner_Ring_Out = 0,Inner_Ring_Last_Out = 0;
int out_ang_speed;//�⻷���Ŀ����ٶ�
int Error_Current_Inner,Error_Last_Inner;
int Inner_Ring_PID(int expect_speed)   //�ڻ������⻷�����ת��Ŀ����ٶ���ʵ�ʵ�Z����ٶ�����ʹ��ʵ�ʵ�Z����ٶȱƽ�ת��Ŀ���ٶȣ��ú����õ��������ֵĲ��ٶ�
{
   float A = 0.9;  // ��ͨ�˲�ϵ��
   int  ek = 0,ek1 = 0;
   Error_Current_Inner=expect_speed - post.gyro_yaw;
   ek=Error_Current_Inner;
   ek1=Error_Current_Inner-Error_Last_Inner;
   Error_Last_Inner=Error_Current_Inner;
   Inner_Ring_Last_Out = Inner_Ring_Out;  // ������һ�����
   Inner_Ring_Out = Inner_Ring_P * ek + Inner_Ring_D * ek1;		//λ��ʽPD����
   Inner_Ring_Out = (int)(A*Inner_Ring_Out + (1-A)*Inner_Ring_Last_Out);

   return (int)Inner_Ring_Out;
}

float Outer_Ring_P = 0,Outer_Ring_D = 0;  
float Outer_Ring_Out = 0,Outer_Ring_Last_Out = 0;
int Error_Last_Outer,Error_Current_Outer;
int Outer_Ring_PID(int expect_val,int err)   //�⻷�������ߵ�������һ��ת���Ŀ���ٶ�ֵ
{
   float A = 0.9;  // ��ͨ�˲�ϵ��
   int ek = 0,ek1 = 0;
   Error_Current_Outer=err-expect_val;
   ek=Error_Current_Outer;
   ek1=Error_Current_Outer-Error_Last_Outer;
   Error_Last_Outer=Error_Current_Outer;
   Outer_Ring_Last_Out = Outer_Ring_Out;  // ������һ�����
   Outer_Ring_Out = Outer_Ring_P * ek + Outer_Ring_D * ek1;        //λ��ʽPD����
   Outer_Ring_Out = (int)(A*Outer_Ring_Out + (1-A)*Outer_Ring_Last_Out);

   return (int)Outer_Ring_Out;
}

void pid_init(void)
{
    //�ٶȻ�
    kp_out = 0;
    ki_out = 0;
    kd_out = 0;
    motor.l_speed_out_last = 0;
    motor.l_speed_out = 0;
    motor.dutyL = 0;
    error.beforeL = 0;
    error.currentL = 0;
    error.previousL = 0;
    error.integrationL = 0;
    error.derivationL = 0;

    motor.r_speed_out_last = 0;
    motor.r_speed_out = 0;
    motor.dutyR = 0;
    error.beforeR = 0;
    error.currentR = 0;
    error.previousR = 0;
    error.integrationR = 0;
    error.derivationR = 0;
    
    //���⻷
    Outer_Ring_Out = 0;
    Outer_Ring_Last_Out = 0;
    Inner_Ring_Out = 0;
    Inner_Ring_Last_Out = 0;
}

void motor_speed_get(void)
{
    motor.speedTL = slow_start_speed + motor.speed_diff;//������0��Ҫ����ת���ٶȲ�motor.speed_diffҪС��0��ʹ�������ٶȴ��������ٶ�
	motor.speedTR = slow_start_speed - motor.speed_diff;
}

void motor_control(void)
{
    motor_speed_get();
    Speed_Loop();
}
