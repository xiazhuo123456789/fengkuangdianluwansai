/*
 * Parameters.h
 *
 *  Created on: 2026��1��18��
 *      Author: ���
 */

#ifndef CODE_PARAMETERS_H_
#define CODE_PARAMETERS_H_

#include "zf_common_headfile.h"

extern int Path_Switch;//·���л�

void All_Init(void);
void Parameters_Init(void);

#endif /* CODE_PARAMETERS_H_ */
