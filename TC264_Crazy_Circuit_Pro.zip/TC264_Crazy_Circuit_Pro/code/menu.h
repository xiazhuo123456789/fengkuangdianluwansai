/*
 * menu.h
 *
 *  Created on: 2026��1��18��
 *      Author: Administrator
 */

#ifndef CODE_MENU_H_
#define CODE_MENU_H_

#include "zf_common_headfile.h"

#define BUZZER_PIN              (P33_10)
#define LED_1_PIN               (P20_9)
#define LED_2_PIN               (P20_8)
#define LED_3_PIN               (P21_5)

typedef struct
{
	int run_status;
	int end;
	int protect;
	int element_num;
	int element_run;
	
}STATUS;//3

extern STATUS status;
extern int image_solve_fps;

void buzzer_on(void);
void buzzer_off(void);
void buzzer_init(void);
void buzzer_turn(void);

void image_line_show(void);
void battery_voltage_show(void);
void menu(void);
void Menu_Logic_Run(void);
void LED_init(void);
void LED_on(int LED_number);
void LED_off(void);

#endif /* CODE_MENU_H_ */
