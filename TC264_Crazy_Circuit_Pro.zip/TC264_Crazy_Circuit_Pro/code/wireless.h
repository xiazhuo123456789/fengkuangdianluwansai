/*
 * wireless.h
 *
 *  Created on: 2026��1��22��
 *      Author: ���
 */

#ifndef CODE_WIRELESS_H_
#define CODE_WIRELESS_H_

#include "zf_common_headfile.h"

extern uint8_t Wireless_init_flag;

void Vofa_Show(void);
void Vofa_Adjust_Parameter(void);

#endif /* CODE_WIRELESS_H_ */
