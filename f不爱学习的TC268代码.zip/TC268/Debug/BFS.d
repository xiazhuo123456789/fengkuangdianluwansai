BFS.o :	../code/BFS.c
../code/BFS.c :
BFS.o :	..\code\BFS.h
..\code\BFS.h :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_headfile.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_headfile.h" :
BFS.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
BFS.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
BFS.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
BFS.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
BFS.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
BFS.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h" :
BFS.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
BFS.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_typedef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_typedef.h" :
BFS.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_clock.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_clock.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_debug.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_debug.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_interrupt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_interrupt.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_fifo.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_fifo.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_font.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_font.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_function.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_function.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\user\isr_config.h"
"D:\\AURIX Development Studio\\TC268\\user\isr_config.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_adc.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_adc.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_delay.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_delay.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_dma.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_dma.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_exti.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_exti.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_encoder.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_encoder.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_exti.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_exti.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_flash.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_flash.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_gpio.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_gpio.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_pit.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_pit.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_pwm.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_pwm.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_soft_iic.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_soft_iic.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_spi.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_spi.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_soft_spi.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_soft_spi.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_uart.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_uart.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_timer.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_timer.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_absolute_encoder.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_absolute_encoder.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ble6a20.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ble6a20.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_bluetooth_ch9141.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_bluetooth_ch9141.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_gnss.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_gnss.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_camera.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_camera.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_uart.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_uart.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_type.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_type.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_dl1a.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_dl1a.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_dl1b.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_dl1b.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_icm20602.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_icm20602.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660ra.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660ra.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rb.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rb.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rc.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rc.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rx.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rx.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu963ra.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu963ra.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips114.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips114.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips200.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips200.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips200pro.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips200pro.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_key.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_key.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_menc15a.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_menc15a.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_mpu6050.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_mpu6050.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_mt9v03x_double.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_mt9v03x_double.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_oled.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_oled.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ov7725.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ov7725.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_scc8660.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_scc8660.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_tft180.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_tft180.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_tsl1401.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_tsl1401.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_uart_receiver.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_uart_receiver.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_virtual_oscilloscope.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_virtual_oscilloscope.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wifi_uart.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wifi_uart.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wifi_spi.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wifi_spi.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wireless_uart.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wireless_uart.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_components\seekfree_assistant.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_components\seekfree_assistant.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_components\seekfree_assistant_interface.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_components\seekfree_assistant_interface.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\swj.h"
"D:\\AURIX Development Studio\\TC268\\code\swj.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_headfile.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_headfile.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\init.h"
"D:\\AURIX Development Studio\\TC268\\code\init.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\key.h"
"D:\\AURIX Development Studio\\TC268\\code\key.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\utils.h"
"D:\\AURIX Development Studio\\TC268\\code\utils.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\image.h"
"D:\\AURIX Development Studio\\TC268\\code\image.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\motor.h"
"D:\\AURIX Development Studio\\TC268\\code\motor.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\encoder.h"
"D:\\AURIX Development Studio\\TC268\\code\encoder.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\control.h"
"D:\\AURIX Development Studio\\TC268\\code\control.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\gyroscope.h"
"D:\\AURIX Development Studio\\TC268\\code\gyroscope.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\base.h"
"D:\\AURIX Development Studio\\TC268\\code\base.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\keyy.h"
"D:\\AURIX Development Studio\\TC268\\code\keyy.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\encoderr.h"
"D:\\AURIX Development Studio\\TC268\\code\encoderr.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\pidd.h"
"D:\\AURIX Development Studio\\TC268\\code\pidd.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\imagee.h"
"D:\\AURIX Development Studio\\TC268\\code\imagee.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\line.h"
"D:\\AURIX Development Studio\\TC268\\code\line.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\point.h"
"D:\\AURIX Development Studio\\TC268\\code\point.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\node.h"
"D:\\AURIX Development Studio\\TC268\\code\node.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\imurb.h"
"D:\\AURIX Development Studio\\TC268\\code\imurb.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\draw.h"
"D:\\AURIX Development Studio\\TC268\\code\draw.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\error.h"
"D:\\AURIX Development Studio\\TC268\\code\error.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\PROC.h"
"D:\\AURIX Development Studio\\TC268\\code\PROC.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\Control_Proc.h"
"D:\\AURIX Development Studio\\TC268\\code\Control_Proc.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\Pid_Proc.h"
"D:\\AURIX Development Studio\\TC268\\code\Pid_Proc.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\R.h"
"D:\\AURIX Development Studio\\TC268\\code\R.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\usart.h"
"D:\\AURIX Development Studio\\TC268\\code\usart.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\user\cpu0_main.h"
"D:\\AURIX Development Studio\\TC268\\user\cpu0_main.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\Debugvofa.h"
"D:\\AURIX Development Studio\\TC268\\code\Debugvofa.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\Debugmainvofa.h"
"D:\\AURIX Development Studio\\TC268\\code\Debugmainvofa.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\ff.h"
"D:\\AURIX Development Studio\\TC268\\code\ff.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\Wifispi.h"
"D:\\AURIX Development Studio\\TC268\\code\Wifispi.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\BFS.h"
"D:\\AURIX Development Studio\\TC268\\code\BFS.h" :
BFS.o :	"D:\\AURIX Development Studio\\TC268\\code\Filter.h"
"D:\\AURIX Development Studio\\TC268\\code\Filter.h" :
