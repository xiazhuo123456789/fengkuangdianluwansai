DebugWifiSpi.o :	../code/DebugWifiSpi.c
../code/DebugWifiSpi.c :
