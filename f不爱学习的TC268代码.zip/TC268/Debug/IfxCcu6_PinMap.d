IfxCcu6_PinMap.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_PinMap/IfxCcu6_PinMap.c :
IfxCcu6_PinMap.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_PinMap\IfxCcu6_PinMap.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_PinMap\IfxCcu6_PinMap.h :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxCcu6_PinMap.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
IfxCcu6_PinMap.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
