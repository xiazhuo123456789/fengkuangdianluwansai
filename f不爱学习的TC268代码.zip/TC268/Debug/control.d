control.o :	../code/control.c
../code/control.c :
control.o :	..\code\control.h
..\code\control.h :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_headfile.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_headfile.h" :
control.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
control.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
control.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
control.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
control.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
control.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h" :
control.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
control.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_typedef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_typedef.h" :
control.o :	"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"D:\AURIX Development Studio\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_clock.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_clock.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_debug.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_debug.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_interrupt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_interrupt.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_fifo.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_fifo.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_font.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_font.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_function.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_function.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\user\isr_config.h"
"D:\\AURIX Development Studio\\TC268\\user\isr_config.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_adc.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_adc.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_delay.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_delay.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_dma.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_dma.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_exti.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_exti.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_encoder.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_encoder.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_exti.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_exti.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_flash.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_flash.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_gpio.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_gpio.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_pit.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_pit.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_pwm.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_pwm.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_soft_iic.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_soft_iic.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_spi.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_spi.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_soft_spi.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_soft_spi.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_uart.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_uart.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_timer.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_timer.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_absolute_encoder.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_absolute_encoder.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ble6a20.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ble6a20.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_bluetooth_ch9141.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_bluetooth_ch9141.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_gnss.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_gnss.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_camera.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_camera.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_uart.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_driver\zf_driver_uart.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_type.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_type.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_dl1a.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_dl1a.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_dl1b.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_dl1b.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_icm20602.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_icm20602.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660ra.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660ra.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rb.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rb.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rc.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rc.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rx.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu660rx.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu963ra.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_imu963ra.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips114.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips114.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips200.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips200.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips200pro.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ips200pro.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_key.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_key.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_menc15a.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_menc15a.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_mpu6050.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_mpu6050.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_mt9v03x_double.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_mt9v03x_double.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_oled.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_oled.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ov7725.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_ov7725.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_scc8660.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_scc8660.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_tft180.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_tft180.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_tsl1401.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_tsl1401.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_uart_receiver.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_uart_receiver.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_virtual_oscilloscope.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_virtual_oscilloscope.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wifi_uart.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wifi_uart.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wifi_spi.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wifi_spi.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wireless_uart.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_device\zf_device_wireless_uart.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_components\seekfree_assistant.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_components\seekfree_assistant.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_components\seekfree_assistant_interface.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_components\seekfree_assistant_interface.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\swj.h"
"D:\\AURIX Development Studio\\TC268\\code\swj.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_headfile.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\zf_common\zf_common_headfile.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\init.h"
"D:\\AURIX Development Studio\\TC268\\code\init.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\key.h"
"D:\\AURIX Development Studio\\TC268\\code\key.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\utils.h"
"D:\\AURIX Development Studio\\TC268\\code\utils.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\image.h"
"D:\\AURIX Development Studio\\TC268\\code\image.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\motor.h"
"D:\\AURIX Development Studio\\TC268\\code\motor.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\encoder.h"
"D:\\AURIX Development Studio\\TC268\\code\encoder.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\control.h"
"D:\\AURIX Development Studio\\TC268\\code\control.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\gyroscope.h"
"D:\\AURIX Development Studio\\TC268\\code\gyroscope.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\base.h"
"D:\\AURIX Development Studio\\TC268\\code\base.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\keyy.h"
"D:\\AURIX Development Studio\\TC268\\code\keyy.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\encoderr.h"
"D:\\AURIX Development Studio\\TC268\\code\encoderr.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\pidd.h"
"D:\\AURIX Development Studio\\TC268\\code\pidd.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\imagee.h"
"D:\\AURIX Development Studio\\TC268\\code\imagee.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\line.h"
"D:\\AURIX Development Studio\\TC268\\code\line.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\point.h"
"D:\\AURIX Development Studio\\TC268\\code\point.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\node.h"
"D:\\AURIX Development Studio\\TC268\\code\node.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\imurb.h"
"D:\\AURIX Development Studio\\TC268\\code\imurb.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\draw.h"
"D:\\AURIX Development Studio\\TC268\\code\draw.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\error.h"
"D:\\AURIX Development Studio\\TC268\\code\error.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\PROC.h"
"D:\\AURIX Development Studio\\TC268\\code\PROC.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\Control_Proc.h"
"D:\\AURIX Development Studio\\TC268\\code\Control_Proc.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\Pid_Proc.h"
"D:\\AURIX Development Studio\\TC268\\code\Pid_Proc.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\R.h"
"D:\\AURIX Development Studio\\TC268\\code\R.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\usart.h"
"D:\\AURIX Development Studio\\TC268\\code\usart.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\user\cpu0_main.h"
"D:\\AURIX Development Studio\\TC268\\user\cpu0_main.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"D:\\AURIX Development Studio\\TC268\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\Debugvofa.h"
"D:\\AURIX Development Studio\\TC268\\code\Debugvofa.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\Debugmainvofa.h"
"D:\\AURIX Development Studio\\TC268\\code\Debugmainvofa.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\ff.h"
"D:\\AURIX Development Studio\\TC268\\code\ff.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\Wifispi.h"
"D:\\AURIX Development Studio\\TC268\\code\Wifispi.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\BFS.h"
"D:\\AURIX Development Studio\\TC268\\code\BFS.h" :
control.o :	"D:\\AURIX Development Studio\\TC268\\code\Filter.h"
"D:\\AURIX Development Studio\\TC268\\code\Filter.h" :
