#ifndef CODE_BFS_H_
#define CODE_BFS_H_

#include "zf_common_headfile.h"
float FF_Speed_Map(float Target_encoder);
float FF_Speed_Calc(float Target_encoder_L, float Target_encoder_R);
int bfs_check(int row, int col, int target_count, uint8 (*src_image)[COL]);
#endif
