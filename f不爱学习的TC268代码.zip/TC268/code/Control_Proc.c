#include "Control_Proc.h"

volatile float Speed_Base;

volatile float Turn_Speed_rad = 1;
volatile  float Speed_L , Speed_R , Speed_Turn , Speed_Img_Turn;


//#define
#define SPEED_FILTER_ALPHA 0.8f
#define TURN_SPEED_FILTER_ALPHA 0.75f

/*******************************************λ��1ms�ж�����ٶ�control***************************************************/
static float Actual_L_Filtered = 0.0f;
static float Actual_R_Filtered = 0.0f;



//��ǰ��λΪ������������
void Control_Speed_Proc(float Target_L_Speed , float Target_R_Speed , float v)
{
    static uint8_t ms1 = 0;   ++ms1;


    if(ms1 >= 1)
    {
        ms1 = 0;

        int Actual_L = Encoder_L_Get();
        int Actual_R = Encoder_R_Get();
        //ips114_show_float(100, 30, Actual_R, 5, 5);
        //һ�׵�ͨ�˲�
        //Actual_L_Filtered = SPEED_FILTER_ALPHA * Actual_L_Filtered + (1.0f - SPEED_FILTER_ALPHA) * Actual_L;

       //Actual_R_Filtered = SPEED_FILTER_ALPHA * Actual_R_Filtered + (1.0f - SPEED_FILTER_ALPHA) * Actual_R;

        //����ƽ���˲�

        float Actual_L_Filtered_Moving = Moving_Average_Filter((float)Actual_L ,0);
        float Actual_R_Filtered_Moving = Moving_Average_Filter((float)Actual_R ,1);

        //һ�׵�ͨ�˲�
        Actual_L_Filtered = SPEED_FILTER_ALPHA * Actual_L_Filtered + (1.0f - SPEED_FILTER_ALPHA) * Actual_L_Filtered_Moving;

        Actual_R_Filtered = SPEED_FILTER_ALPHA * Actual_R_Filtered + (1.0f - SPEED_FILTER_ALPHA) * Actual_R_Filtered_Moving;

        //Calc_FB
        float FB_PWM_L = (float)Pid_Speed_R_Proc((float)Target_L_Speed,(float)Actual_L_Filtered, &PID_Speed_L);
        float FB_PWM_R = (float)Pid_Speed_R_Proc((float)Target_R_Speed,(float)Actual_R_Filtered, &PID_Speed_R);

        //Calc_FF
        float FF_PWM_L = Calc_FF_PWM(Target_L_Speed ,v) * 0.8;
        float FF_PWM_R = Calc_FF_PWM(Target_R_Speed ,v) * 0.81;

        //SET_PWM
        float PWM_L = FF_PWM_L + (float)FB_PWM_L;
        float PWM_R = FF_PWM_R + (float)FB_PWM_R;

        motor_proc(PWM_L, PWM_R);
        Debug_Speed_Proc_vofa(Actual_L_Filtered, Actual_R_Filtered);
        //Debug_Speed_Proc_vofa(PWM_L, PWM_R);


    }
}

/***********************************λ����ѭ�����ÿһ֡��imgλ�û�����******************************************/
//�˴���gyroz��5ms�ж����Gyroz_Proc��ȡ����
void Control_Img_Location_Proc(float Img_Err , float gyroz)
{


        float Speed_Img_Turn = Pid_Img_Location_Proc((float)Img_Err, (float)gyroz, &PID_Img_Location);

        Speed_L = Speed_Base + Speed_Img_Turn;
        Speed_R = Speed_Base - Speed_Img_Turn;

        Debug_Location_Proc_vofa();

}
/***************************λ��1ms�ж���Ľ��ٶȻ����ƣ�Ҫע��ŵ����ȼ��͵��жϵ���*******************************/
//Target_Turn_Speed
//��������Ϊ3ms
//��ǰ��λΪGyro_angle
static float Actual_Turn_Filtered = 0.0f;
void Control_Turn_Speed_Proc(float Target_Turn_Speed,float v_base_cm)
{


    float Actual_Gyroz = Gyroz_rad;
    //��ͨ�˲�
    Actual_Turn_Filtered = TURN_SPEED_FILTER_ALPHA * Actual_Turn_Filtered +
                           (1.0f - TURN_SPEED_FILTER_ALPHA) * Actual_Gyroz;
    Debug_Turn_Speed_Proc_vofa(Actual_Turn_Filtered);
    //FB
    Speed_Turn = Pid_Turn_Speed_Proc(Target_Turn_Speed, Actual_Turn_Filtered , &PID_Turn_Speed);

    //FF
    float FF_v_l_encoder,FF_v_r_encoder;
    Calc_FF_Encoder(Target_Turn_Speed , v_base_cm ,&FF_v_l_encoder, &FF_v_r_encoder);


    Speed_L = FF_v_l_encoder * 0.9 + Speed_Turn;//+ Speed_Turn
    Speed_R = FF_v_r_encoder * 0.9 - Speed_Turn;// - Speed_Turn

    //Debug_Data_4 = a;

}
/*********************************************R������*****************************************************/

void Control_R_Proc(float Target_Turn_Speed,float v_base_cm)
{

    Control_Turn_Speed_Proc(Target_Turn_Speed,v_base_cm);

}

void Set_Speed_Base(float new_base) {

    Speed_Base = new_base;

}
