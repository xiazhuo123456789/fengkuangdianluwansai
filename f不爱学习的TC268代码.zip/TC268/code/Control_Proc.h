#ifndef CODE_CONTROL_PROC_H_
#define CODE_CONTROL_PROC_H__

#include "zf_common_headfile.h"


//extern
extern volatile float Speed_L;
extern volatile float Speed_R;
extern volatile float Speed_Turn;
extern volatile float Turn_Speed_rad;

extern volatile float Speed_Base;
extern int extern_basespeed;



//����
void Control_Speed_Proc(float Target_L_Speed , float Target_R_Speed , float battery_voltage);
void Control_Turn_Speed_Proc(float Target_Turn_Speed, float v_base_cm);
void Control_Img_Location_Proc(float Img_Err , float gyroz);
void Control_R_Proc(float Target_Turn_Speed ,float v_base_cm);
void Set_Speed_Base(float new_base);


#endif /* CODE_KEY_H_ */
