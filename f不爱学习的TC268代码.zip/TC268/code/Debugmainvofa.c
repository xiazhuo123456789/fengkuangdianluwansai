#include "Debugmainvofa.h"

void Debug_vofa_main(void)
{
     /********************send****************/

    /********************receive****************/

}
