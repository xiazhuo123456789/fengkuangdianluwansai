#include "Debugvofa.h"
//*******************************************Debug****************************************
//����
volatile float Debug_Data_1 = 0;
volatile float Debug_Data_2 = 0;
volatile float Debug_Data_3 = 0;
volatile float Debug_Data_4 = 0;
volatile float Debug_Data_5 = 0;
volatile float Debug_Data_6 = 0;
volatile float Debug_Data_7 = 0;
volatile float Debug_Data_8 = 0;
volatile float Debug_Data_9 = 0;
//useful
volatile float Debug_Speed_L_A = 0;
volatile float Debug_Speed_R_A = 0;
volatile float Debug_Speed_T = 0;
volatile float Debug_TSpeed_A = 0;
volatile float Debug_TSpeed_T = 0;
volatile float Debug_Location_Err = 0;
volatile float Debug_Location_T = 0;
volatile int debug_data_ready;
volatile int debug_speed_ready;
volatile int debug_turn_speed_ready;
volatile int debug_location_ready;

#define SPEEDVOFA_ENABLE 1
#define TURNSPEEDVOFA_ENABLE 0
#define LOCATIONVOFA_ENABLE 0
///****************************************vofa----send*********************************************/
    /******************************************vofa----main*********************************************/
void Debug_Speed_main_vofa(float Speed_Target)
{
    if(SPEEDVOFA_ENABLE)
    {
        if (debug_speed_ready) { debug_speed_ready = 0;

             wireless_uart_printf("%.2f,%.2f,%.2f\r\n", Speed_Target, Debug_Speed_L_A , Debug_Speed_R_A);

            }
    }


}

void Debug_Trun_Speed_main_vofa(float Turn_Speed_Target)
{
    if(TURNSPEEDVOFA_ENABLE)
    {
        if (debug_turn_speed_ready) { debug_turn_speed_ready = 0;

             wireless_uart_printf("%.2f,%.2f,%.2f\r\n", Turn_Speed_Target*10.0f, Debug_TSpeed_A*10.0f , Debug_TSpeed_A*10.0f);

            }
    }


}

void Debug_Location_main_vofa(float Debug_Location_Target)
{
    if(LOCATIONVOFA_ENABLE)
    {
        if (debug_location_ready) { debug_location_ready = 0;

            wireless_uart_printf("%.2f,%.2f,%.2f\r\n", Debug_Location_Target, Img_Err , Img_Err);

           }

    }

}
    /******************************************vofa----pidproc***********************************************/
void Debug_Speed_Proc_vofa(float AL, float AR)
{
    if(SPEEDVOFA_ENABLE)
    {
        debug_speed_ready = 1;
        Debug_Speed_L_A = AL;
        Debug_Speed_R_A = AR;
    }

}
void Debug_Turn_Speed_Proc_vofa(float AZ)
{
    if(TURNSPEEDVOFA_ENABLE)
    {
        debug_turn_speed_ready = 1;
        Debug_TSpeed_A = AZ;
    }

}
void Debug_Location_Proc_vofa(void)
{
    if(LOCATIONVOFA_ENABLE)
    {
        debug_location_ready = 1;
        Debug_TSpeed_A = Img_Err;
    }

}
///****************************************vofa----receive*********************************************/
/**
 * @brief  �����ߴ��ڽ���һ�����������ַ�����ʽ��
 * @param  received_val  [out] ��Ž������ĸ�����
 * @return 1 ��ʾ���յ��µ���Ч���ݣ�0 ��ʾ�������ݻ����ʧ��
 */
uint8 vofa_receive_float(float *received_val)
{
    uint8 rx_buf[32];
    uint32 rx_len = wireless_uart_read_buffer(rx_buf, sizeof(rx_buf) - 1);

    if (rx_len == 0)
        return 0;

    rx_buf[rx_len] = '\0';                       // ȷ���ַ�������
    float tmp;
    if (sscanf((const char *)rx_buf, "%f", &tmp) == 1)
    {
        *received_val = tmp;
        return 1;
    }
    return 0;                                    // ����ʧ��
}
