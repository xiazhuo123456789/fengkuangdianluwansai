#ifndef CODE_DEBUGVOFA_H_
#define CODE_DEBUGVOFA_H_

#include "zf_common_headfile.h"

//**********************Debug--vofa***************************
extern volatile float Debug_Data_1;
extern volatile float Debug_Data_2;
extern volatile float Debug_Data_3;
extern volatile float Debug_Data_4;
extern volatile float Debug_Data_5;
extern volatile float Debug_Data_6;
extern volatile float Debug_Data_7;
extern volatile float Debug_Data_8;
extern volatile float Debug_Data_9;

extern volatile float Debug_Speed_L_A;
extern volatile float Debug_Speed_R_A;
extern volatile float Debug_Speed_T;
extern volatile float Debug_TSpeed_A;
extern volatile float Debug_TSpeed_T;
extern volatile float Debug_Location_Err;
extern volatile float Debug_Location_T;
extern volatile int debug_data_ready;
extern volatile int debug_speed_ready;
extern volatile int debug_turn_speed_ready;
extern volatile int debug_location_ready;


/********************************************hanshu******************************************************/
//send
void Debug_Speed_main_vofa(float Speed_Target);
void Debug_Trun_Speed_main_vofa(float Turn_Speed_Target);
void Debug_Location_main_vofa(float Debug_Location_T);

void Debug_Speed_Proc_vofa(float AL, float AR);
void Debug_Turn_Speed_Proc_vofa(float AZ);
void Debug_Location_Proc_vofa(void);

//receive
uint8 vofa_receive_float(float *received_val);
#endif
