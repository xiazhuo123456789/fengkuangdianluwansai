#ifndef CODE_FILTER_H_
#define CODE_FILTER_H_

#include "zf_common_headfile.h"

float Moving_Average_Filter(float new_val, uint8 wheel);
#endif /* CODE_KEY_H_ */
