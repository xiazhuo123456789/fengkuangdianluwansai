#include "PROC.h"
int volatile fuyaflag = 0;
int volatile PID_R_flag = 0;
int volatile PID_Location_flag = 0;
float volatile battery_voltage = 0.0f;
int volatile battery_flag = 1;
void Proc(void){


    //image_binarize_724(mt9v03x_image_1);   // ��ֵ��
    image_binarize(mt9v03x_image_1);
   // remove_large_noise_blobs();
    find_lrm_line_ceshi(bin_image);
    //global_line_fit1(ROW - 1, 0, 8.0f, 0);
    Node_State_Machine_RL_ceshi(bin_image);
    calc_image_error_ceshi();

    if(1)//PID_Location_flag
    {
        Control_Img_Location_Proc(Img_Err , imu660rb_gyro_z);
    }
}
