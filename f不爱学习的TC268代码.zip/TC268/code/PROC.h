#ifndef CODE_PROC_H_
#define CODE_PROC_H_

#include "zf_common_headfile.h"

void Proc(void);
extern volatile int fuyaflag;
extern volatile int  PID_R_flag;
extern volatile int  PID_Location_flag;
extern float volatile battery_voltage;
extern int volatile battery_flag;
#endif
