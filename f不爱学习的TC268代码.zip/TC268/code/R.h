#ifndef CODE_R_H_
#define CODE_R_H_

#include "zf_common_headfile.h"
float Set_Speed_Base_cm(float speed_cm_s, int period_ms);
float Calc_distance_from_row(int row);
float Calc_radius_from_XY(float X_cm, float Y_cm);
float Calc_omega_from_R_and_v(float R_cm, float v_cm_s);
float Calc_Vision_Lag_Compensation(int fps , float Current_speed_cm);

float Get_Target_Turn_Speed(int row, float base_speed_cm ,int left_or_right ,float x_distance);
#endif
