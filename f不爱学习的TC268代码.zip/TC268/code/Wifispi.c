#include "Wifispi.h"
void Display_Image(void)
{
    seekfree_assistant_camera_information_config(SEEKFREE_ASSISTANT_MT9V03X, bin_image[0], COL, ROW);
    seekfree_assistant_camera_send();
}
void Display_point_LR(void)
{
    GetBoundaryLink_LR_Point(25 , 110);
    generate_square(Line_L[point_lx],point_lx,1);
    generate_square(Line_R[point_rx],point_rx,2);
    seekfree_assistant_camera_boundary_config(XY_BOUNDARY, 80, square1_x, square2_x, NULL, square1_y, square2_y, NULL);
}
void Display_Linelmr(void)
{
    seekfree_assistant_camera_boundary_config(X_BOUNDARY, ROW, Line_L, Line_M, Line_R, NULL, NULL ,NULL);
}
