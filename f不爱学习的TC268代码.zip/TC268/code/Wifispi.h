#ifndef CODE_WIFISPI_H_
#define CODE_WIFISPI_H_

#include "zf_common_headfile.h"
void Display_Linelmr(void);
void Display_Image(void);
void Display_point_LR(void);
#endif
