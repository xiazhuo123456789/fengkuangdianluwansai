#include "base.h"

float limitt(float value, float min, float max)//��С�����޷�
{
    if (value > max) return max;
    if (value < min) return min;
    return value;
}
uint8_t limitt_uint8(uint8_t value, uint8_t min, uint8_t max)//��С�����޷�
{
    if (value > max) return max;
    if (value < min) return min;
    return value;
}
