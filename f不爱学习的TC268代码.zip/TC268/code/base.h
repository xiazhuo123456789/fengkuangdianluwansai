#ifndef CODE_BASE_H_
#define CODE_BASE_H_

#include "zf_common_headfile.h"

float limitt(float value, float min, float max);
uint8_t limitt_uint8(uint8_t value, uint8_t min, uint8_t max);


#endif /* CODE_MOTOR_H_ */
