#include "control.h"

Steer_Pid steer_pid;

void pid_param_init(void)
{
    steer_pid.kp  = 55;
    steer_pid.gkd = 30;
}

int base_speed = 1000;
float l_speed_output = 0;
float r_speed_output = 0;
float steer_pwm_out = 0;
volatile uint8 fuya_flag;

static uint8 time_2ms;
static uint8 time_5ms;

void control_proc(void)
{
    int actual_speed;

    if (run_flag == 1)
    {
        actual_speed = base_speed;

        if(++time_2ms >= 2)
        {
            time_2ms = 0;

            steer_pwm_out = steer_pid_calc(image_err, imu660rb_gyro_z, &steer_pid);
            steer_pwm_out = limit_float(steer_pwm_out, steer_pwm_duty_max, steer_pwm_duty_min);
        }

        if(++time_5ms >= 5)
        {
            time_5ms = 0;

            l_speed_output = actual_speed + steer_pwm_out;
            r_speed_output = actual_speed - steer_pwm_out;

            motor_proc(l_speed_output, r_speed_output);
        }
    }
    else if(run_flag == 0)
    {
        motor_proc(0, 0);
    }
}

void fuya_proc(void)
{
    if(fuya_flag)
    {
        set_fuya_pwm(FUYA_PWM_DUTY);
    }
    else
    {
        set_fuya_pwm(0);
    }
}

void run_time_proc(void)
{
    static uint16 cnt_10ms = 0;
    static uint16 timer_1s = 0;

    if (start_flag)
    {
//        if (turn_verify_flag == 2)
//        {
//            run_flag = 0;
//            fuya_flag = 0;
//            start_flag = 0;
//            timer_1s = 0;
//            cnt_10ms = 0;
//            return;
//        }

        cnt_10ms++;

        if (cnt_10ms >= 100)
        {
            cnt_10ms = 0;
            timer_1s++;

            if(timer_1s == 1)
            {
                fuya_flag = 1;
            }
            else if(timer_1s == 2)
            {
                run_flag = 1;
            }
            else if(timer_1s == RUN_TIME)
            {
                run_flag = 0;
            }
            else if(timer_1s == (RUN_TIME + 1))
            {
                fuya_flag = 0;
                start_flag = 0;

                timer_1s = 0;
                cnt_10ms = 0;
            }
        }
    }
}

float steer_pid_calc(float image_error, float gyro, Steer_Pid *pid)
{
    float steer_value;

    steer_value = (image_error * pid->kp) - (gyro * pid->gkd) / 100;

    return steer_value;
}
