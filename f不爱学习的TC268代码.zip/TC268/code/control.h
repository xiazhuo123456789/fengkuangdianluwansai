
#ifndef CODE_CONTROL_H_
#define CODE_CONTROL_H_

#include "zf_common_headfile.h"

typedef struct
{
    float kp;
    float gkd;
    float last_error;
} Steer_Pid;

#define steer_pwm_duty_max  6000
#define steer_pwm_duty_min -6000

extern int base_speed;
extern float l_speed_output;
extern float r_speed_output;
extern float steer_pwm_out;
extern Steer_Pid steer_pid;
extern volatile uint8 fuya_flag;

void pid_param_init(void);
void control_proc(void);
void fuya_proc(void);
void run_time_proc(void);
float steer_pid_calc(float image_error, float gyro, Steer_Pid *pid);

#endif /* CODE_CONTROL_H_ */
