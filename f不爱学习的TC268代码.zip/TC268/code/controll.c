#include "controll.h"
#define BASEPWM 1100
#define PWMTMAX 5000
#define PWMTMIN -5000
#define PWMMAX 6000
#define PWMMIN -6000
int basepwm = 1000;

static int ms2 =0;
static int ms5 =0;
static float PWML = 0;
static float PWMR = 0;
static float PWMT = 0;
void SetPWM_proc(void)
{
    ms2++;
    ms5++;
    if(ms2 >= 2)
    {
        ms2 = 0;
        PWMT = PidT_Proc(Img_Err,imu660rb_gyro_z,&PIDTurn);
        //�޷�PWMT
        //limitt(PWMT,PWMTMIN,PWMTMAX);


    }
    if(ms5 >= 5)
    {
        ms5 = 0;
        PWML = basepwm + PWMT;
        PWMR = basepwm - PWMT;
        //�޷�PWMLR
        //limitt(PWML,PWMMIN,PWMMAX);
        //limitt(PWMR,PWMMIN,PWMMAX);


        if(All_distance_cm >=10.5)

        {
            motorr_proc(0,0);
        }
        else
        {motorr_proc(PWML,PWMR);}
    }

}
