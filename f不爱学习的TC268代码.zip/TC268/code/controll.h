
#ifndef CODE_CONTROLL_H_
#define CODE_CONTROLL_H_

#include "zf_common_headfile.h"
extern int basepwm;

void SetPWM_proc(void);
#endif
