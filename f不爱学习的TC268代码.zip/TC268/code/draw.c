#include "draw.h"
void draw_square(int x,int y)
{

        // ǿ�а�������������Ļ�ڣ�����
        if(x < 10) x = 10;
        if(x > 125) x = 125;   // ��֤ x+10 ������ 135
        if(y < 10) y = 10;
        if(y > 230) y = 230;   // ��֤ y+10 ������ 240

        int x1 = x - 10;
        int x2 = x + 10;
        int y_top = y - 10;
        int y_bot = y + 10;

        // ��ʽǿת uint16����������
        ips114_draw_line((uint16)x1, (uint16)y_top, (uint16)x2, (uint16)y_top, RGB565_RED);
        ips114_draw_line((uint16)x1, (uint16)y_bot, (uint16)x2, (uint16)y_bot, RGB565_RED);
        ips114_draw_line((uint16)x1, (uint16)y_top, (uint16)x1, (uint16)y_bot, RGB565_RED);
        ips114_draw_line((uint16)x2, (uint16)y_top, (uint16)x2, (uint16)y_bot, RGB565_RED);


}

void draw_LineL(void)
{
    for(int i =ROW; i >= 1 ; i--)
    {
        ips114_draw_point (Line_L[i], i, RGB565_BLUE);
    }

}
void draw_LineR(void)
{
    for(int i =ROW; i >= 1 ; i--)
    {
        ips114_draw_point (Line_R[i], i, RGB565_RED);
    }

}
void draw_LineM(void)
{
    for(int i =ROW; i >= 1 ; i--)
    {
        ips114_draw_point (Line_M[i], i, RGB565_GREEN);
    }

}
int square_points[80];
uint8 square1_x[80];
uint8 square1_y[80];
uint8 square2_x[80];
uint8 square2_y[80];

void generate_square(int x, int y, int type)
{
    int d = 10;
    int n = 0;

    if(type == 1)
    {
        n = 0;
        for(int i = -d; i <= d; i++){ square1_x[n] = x+i; square1_y[n++] = y-d; }
        for(int i = -d+1; i <= d; i++){ square1_x[n] = x+d; square1_y[n++] = y+i; }
        for(int i = d-1; i >= -d; i--){ square1_x[n] = x+i; square1_y[n++] = y+d; }
        for(int i = d-1; i >= -d+1; i--){ square1_x[n] = x-d; square1_y[n++] = y+i; }
    }
    else if(type == 2)
    {
        n = 0;
        for(int i = -d; i <= d; i++){ square2_x[n] = x+i; square2_y[n++] = y-d; }
        for(int i = -d+1; i <= d; i++){ square2_x[n] = x+d; square2_y[n++] = y+i; }
        for(int i = d-1; i >= -d; i--){ square2_x[n] = x+i; square2_y[n++] = y+d; }
        for(int i = d-1; i >= -d+1; i--){ square2_x[n] = x-d; square2_y[n++] = y+i; }
    }
}
