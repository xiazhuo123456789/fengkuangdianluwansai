
#ifndef CODE_DRAW_H_
#define CODE_DRAW_H_

#include "zf_common_headfile.h"
void draw_square(int x,int y);
void draw_LineL(void);
extern int square_points[80];
extern int square_points_l[160];
extern int square_points_r[160];
extern uint8 square1_x[80];
extern uint8 square1_y[80];
extern uint8 square2_x[80];
extern uint8 square2_y[80];

void generate_square(int x, int y,int w);
#endif /* CODE_KEY_H_ */
