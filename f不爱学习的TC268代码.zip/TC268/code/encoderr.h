#ifndef CODE_ENCODERR_H_
#define CODE_ENCODERR_H_

#include "zf_common_headfile.h"
#define DELTA_T             0.005f

#define M           36000.0f
extern int l_encoderr;
extern int r_encoderr;
extern float l_speed;
extern float r_speed;
extern float car_speed;

extern float l_encoder_cm;
extern float r_encoder_cm;
extern float All_distance_cm;
extern float L_distance_cm;
extern float R_distance_cm;
float encoderr_proc(void);
void Encoder_proc(void);


/*******����*********/
int Encoder_L_Get(void);
int Encoder_R_Get(void);
#endif
