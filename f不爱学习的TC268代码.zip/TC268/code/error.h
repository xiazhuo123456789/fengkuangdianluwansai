#ifndef CODE_ERROR_H_
#define CODE_ERROR_H_

#include "zf_common_headfile.h"
extern float Img_Err;
void jisuan_error_proc(void);

#endif
