#include "ff.h"
#define WHEEL_TRACK_CM       20.0f   // �־࣬����ʵ�ʲ����޸�
#define ENCODER_PULSE_PER_CM 290.0f  // ÿ���ױ�����������
#define SPEED_LOOP_MS        3.0f    // �ٶȻ�����(ms)
#define WHEEL_TRACK_CM       11.8f
/*********************************�ٶȻ�ǰ��******************************************/
//�����Ч��ѹ
//���뵱ǰ��ѹ��pwm
//�����Ч��ѹ
//����vofa����
float Calc_Equivalent_Voltage(float pwm , float v)
{
    float equivalent_voltage = pwm * v;
    return equivalent_voltage;
}



//�ӵ�Ч��ѹ�л�ԭ��PWM��ֱ��������motorproc
//���룺��Ч��ѹ����ǰ��ѹ
//�����pwm
float Calc_PWM_From_Equivalent_Voltage(float equivalent_voltage, float v)
{
    float pwm = equivalent_voltage / v;
    return pwm;
}

float Calc_FF_PWM(float encoder_target , float v)
{
    //�����Ч��ѹ
    float equivalent_voltage = Calc_EquivalentVoltage_from_Encoder(encoder_target) * 100.0f;
    //����pwm
    float pwm = Calc_PWM_From_Equivalent_Voltage(equivalent_voltage,v);
    return pwm;
}
/*********************************���ٶȻ�ǰ��******************************************/
float Calc_FF_Encoder(float turn_speed_target_rad ,float v_base ,float *v_l_encoder, float *v_r_encoder)
{

    float v_l_cm = v_base + turn_speed_target_rad * (WHEEL_TRACK_CM * 0.5);
    float v_r_cm = v_base - turn_speed_target_rad * (WHEEL_TRACK_CM * 0.5);
    *v_l_encoder = Set_Speed_Base_cm(v_l_cm,1);
    *v_r_encoder = Set_Speed_Base_cm(v_r_cm,1);
}

//��ȡ���������ֵӳ��ĵ�Ч��ѹ
float Calc_EquivalentVoltage_from_Encoder(float encoder)
{
    if (encoder <= 40.14f)
    {
        return 201.01f;
    }
    else if (encoder <= 61.63f)
    {
        // ���� [40.14, 61.63] -> U: 201.01 ~ 222.82
        return 201.01f + (encoder - 40.14f) * (222.82f - 201.01f) / (61.63f - 40.14f);
    }
    else if (encoder <= 76.04f)
    {
        // [61.63, 76.04] -> U: 222.82 ~ 247.44
        return 222.82f + (encoder - 61.63f) * (247.44f - 222.82f) / (76.04f - 61.63f);
    }
    else if (encoder <= 91.25f)
    {
        // [76.04, 91.25] -> U: 247.44 ~ 266.95
        return 247.44f + (encoder - 76.04f) * (266.95f - 247.44f) / (91.25f - 76.04f);
    }
    else if (encoder <= 108.58f)
    {
        // [91.25, 108.58] -> U: 266.95 ~ 291.74
        return 266.95f + (encoder - 91.25f) * (291.74f - 266.95f) / (108.58f - 91.25f);
    }
    else if (encoder <= 121.77f)
    {
        // [108.58, 121.77] -> U: 291.74 ~ 313.18
        return 291.74f + (encoder - 108.58f) * (313.18f - 291.74f) / (121.77f - 108.58f);
    }
    else if (encoder <= 147.18f)
    {
        // [121.77, 147.18] -> U: 313.18 ~ 335.55
        return 313.18f + (encoder - 121.77f) * (335.55f - 313.18f) / (147.18f - 121.77f);
    }
    else if (encoder <= 148.71f)
    {
        // [147.18, 148.71] -> U: 335.55 ~ 358.78
        return 335.55f + (encoder - 147.18f) * (358.78f - 335.55f) / (148.71f - 147.18f);
    }
    else if (encoder <= 163.34f)
    {
        // [148.71, 163.34] -> U: 358.78 ~ 381.50
        return 358.78f + (encoder - 148.71f) * (381.50f - 358.78f) / (163.34f - 148.71f);
    }
    else if (encoder <= 176.49f)
    {
        // [163.34, 176.49] -> U: 381.50 ~ 402.35
        return 381.50f + (encoder - 163.34f) * (402.35f - 381.50f) / (176.49f - 163.34f);
    }
    else if (encoder <= 188.36f)
    {
        // [176.49, 188.36] -> U: 402.35 ~ 425.04
        return 402.35f + (encoder - 176.49f) * (425.04f - 402.35f) / (188.36f - 176.49f);
    }
    else if (encoder <= 205.52f)
    {
        // [188.36, 205.52] -> U: 425.04 ~ 448.82
        return 425.04f + (encoder - 188.36f) * (448.82f - 425.04f) / (205.52f - 188.36f);
    }
    else if (encoder <= 215.54f)
    {
        // [205.52, 215.54] -> U: 448.82 ~ 470.52
        return 448.82f + (encoder - 205.52f) * (470.52f - 448.82f) / (215.54f - 205.52f);
    }
    else if (encoder <= 234.50f)
    {
        // [215.54, 234.50] -> U: 470.52 ~ 494.10
        return 470.52f + (encoder - 215.54f) * (494.10f - 470.52f) / (234.50f - 215.54f);
    }
    else if (encoder <= 238.66f)
    {
        // [234.50, 238.66] -> U: 494.10 ~ 508.81
        return 494.10f + (encoder - 234.50f) * (508.81f - 494.10f) / (238.66f - 234.50f);
    }
    else if (encoder <= 241.39f)
    {
        // [238.66, 241.39] -> U: 508.81 ~ 532.21
        return 508.81f + (encoder - 238.66f) * (532.21f - 508.81f) / (241.39f - 238.66f);
    }
    else if (encoder <= 259.30f)
    {
        // [241.39, 259.30] -> U: 532.21 ~ 551.28
        return 532.21f + (encoder - 241.39f) * (551.28f - 532.21f) / (259.30f - 241.39f);
    }
    else
    {
        return 551.28f;   // ������������ֵ��ǯλ�����U
    }
}
