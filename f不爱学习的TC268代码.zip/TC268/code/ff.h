#ifndef CODE_FF_H_
#define CODE_FF_H_

#include "zf_common_headfile.h"
float Calc_Equivalent_Voltage(float pwm , float battery_v);
float Calc_EquivalentVoltage_from_Encoder(float encoder);
float Calc_PWM_From_Equivalent_Voltage(float equivalent_voltage, float battery_voltage);
float Calc_FF_PWM(float encoder_target , float battery_voltage);
float Calc_FF_Encoder(float turn_speed_target_rad ,float v_base ,float *v_l_encoder, float *v_r_encoder);
#endif
