/*
 * image.h
 *
 *  Created on: 2025��11��15��
 *      Author: zheng
 */

#ifndef CODE_IMAGE_H_
#define CODE_IMAGE_H_

#include "zf_common_headfile.h"

#define PATH_SELECT         1

#define COL                 188
#define ROW                 120

#define BLACK               0
#define WHITE               255

#define CROP_X              0
#define CROP_Y              0

#define THRESH_MIN          100
#define THRESH_MAX          200

#define BLOCK_FAR_START     0
#define BLOCK_FAR_END       40
#define BLOCK_MID_START     40
#define BLOCK_MID_END       80
#define BLOCK_NEAR_START    80
#define BLOCK_NEAR_END      120

#define RECT_LEFT           10
#define RECT_RIGHT          178
#define RECT_TOP            10
#define RECT_BOTTOM         110

// �ڵ�״̬
typedef enum
{
    NODE_NONE = 0,      // �޽ڵ�
    NODE_DETECTED,      // ��⵽�ڵ�
    NODE_TURNING        // ����ת��
} NodeState;

// ת����
typedef enum
{
    TURN_NONE = 0,      // �޲���
    TURN_LEFT,          // ��ת
    TURN_RIGHT,         // ��ת
    GO_STRAIGHT         // ֱ��
} TurnDir;

// ·����Ϣ
typedef struct
{
    uint8 count;        // ·������
    uint8 top_exist;    // �Ϸ���·
    uint8 bottom_exist; // �·���·
    uint8 left_exist;   // �����·
    uint8 right_exist;  // �Ҳ���·
} PathInfo;

extern NodeState node_state;
extern TurnDir turn_dir;
extern PathInfo path_info;

extern float image_err;
extern uint8 bin_image[ROW][COL];
extern uint8 orig_image[ROW][COL];
extern uint8 l_border[ROW];
extern uint8 r_border[ROW];
extern uint8 mid_line[ROW];
extern const TurnDir path[];
extern const uint8 path_len;
extern uint8 node_count;
extern uint8 node_reset;
extern float std_yaw;
extern float yaw_before_turn;
extern float yaw_after_turn;
extern TurnDir actual_turn_dir;
extern uint8 turn_verify_flag;
extern uint8 plan_warn_flag;
extern volatile int imgstop_flag;
extern int black_flag;
extern int white_flag;

void image_crop(uint8 (*mt9v03x_image)[MT9V03X_1_W]);
uint8 block_otsu(uint8 *image, uint16 col, uint16 row_start, uint16 row_end);
void image_binarize(uint8 (*src_image)[COL]);
void search_line(void);
void change_line(uint8 x1, uint8 y1, uint8 x2, uint8 y2);
void find_guaidian(uint8 start, uint8 end);
uint8 find_line_bottom(uint8 col, uint8 (*bin_image)[COL]);
uint8 find_rect_path(uint8 (*bin_image)[COL]);
TurnDir corner_turn(void);
TurnDir plan_turn(void);
void node_proc(uint8 (*bin_image)[COL]);
void reset_all(void);
void calc_image_error(void);
void calc_image_error_ceshi(void);
void draw_rect(void);
void image_proc(void);

#endif /* CODE_IMAGE_H_ */
