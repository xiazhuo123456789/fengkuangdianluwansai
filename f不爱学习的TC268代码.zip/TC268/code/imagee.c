#include "imagee.h"
#include "string.h"
static uint8_t bin_cnt = 0;
static uint8_t threshold;
//��ֵ�ֿ鶨��
static uint8 threshold_far = 128;
static uint8 threshold_mid = 128;
static uint8 threshold_near = 128;

uint8 bin[ROW][COL];
uint8 lvbo_image[ROW][COL];
uint8 Otsu(uint8 *image, uint16 col, uint16 row_start, uint16 row_end)
{
    uint32 histogram[256] = {0}; // �Ҷ�ֱ��ͼ
    uint32 pixel_count = 0;      // ��������
    uint32 pixel_sum = 0;        // �Ҷ��ܺ�

    // ͳ�ƻҶ�ֱ��ͼ
    for (uint16 row = row_start; row < row_end; row++)
    {
        for (uint16 col_idx = 0; col_idx < col; col_idx++)
        {
            uint8 gray = image[row * col + col_idx];
            histogram[gray]++;
            pixel_count++;
            pixel_sum += gray;
        }
    }

    // �ҵ���Ч�Ҷȷ�Χ
    uint8 min_gray = 0, max_gray = 255;
    for (min_gray = 0; min_gray < 256 && histogram[min_gray] == 0; min_gray++)
        ;
    for (max_gray = 255; max_gray > min_gray && histogram[max_gray] == 0; max_gray--)
        ;

    // �߽��������
    if (max_gray == min_gray)
        return max_gray;
    if (min_gray + 1 == max_gray)
        return min_gray;

    // ���������ֵ
    float max_variance = 0.0f;
    uint8 best_threshold = min_gray;

    uint32 background_count = 0;
    uint32 background_sum = 0;

    for (uint8 threshold = min_gray; threshold < max_gray; threshold++)
    {
        // �ۼƱ�������
        background_count += histogram[threshold];
        background_sum += histogram[threshold] * threshold;

        // ����ǰ������
        uint32 foreground_count = pixel_count - background_count;
        if (foreground_count == 0)
            continue;

        uint32 foreground_sum = pixel_sum - background_sum;

        // ���㱳����ǰ����ƽ���Ҷ�
        float background_mean = (float)background_sum / background_count;
        float foreground_mean = (float)foreground_sum / foreground_count;

        // ������䷽��
        float variance = (float)background_count * foreground_count *
                         (background_mean - foreground_mean) *
                         (background_mean - foreground_mean);

        // ��¼��󷽲��Ӧ����ֵ
        if (variance > max_variance)
        {
            max_variance = variance;
            best_threshold = threshold;
        }
    }

    return best_threshold;
}

void binarization(uint8 (*image)[COL])
{
    ++bin_cnt;
    if(bin_cnt>=20)
    {
        bin_cnt = 0;
        //��������
        threshold_far = Otsu(image[0], COL, BLOCK_FAR_START, BLOCK_FAR_END);
        threshold_mid = Otsu(image[0], COL, BLOCK_MID_START, BLOCK_MID_END);
        threshold_near= Otsu(image[0], COL, BLOCK_NEAR_START,BLOCK_NEAR_END);
        //��ֵ�޷�
        if (threshold_far < THRESH_MIN)
            threshold_far = THRESH_MIN;
        if (threshold_far > THRESH_MAX)
            threshold_far = THRESH_MAX;

        if (threshold_mid < THRESH_MIN)
            threshold_mid = THRESH_MIN;
        if (threshold_mid > THRESH_MAX)
            threshold_mid = THRESH_MAX;

        if (threshold_near < THRESH_MIN)
            threshold_near = THRESH_MIN;
        if (threshold_near > THRESH_MAX)
            threshold_near = THRESH_MAX;

        //����������ֵ
        for (uint16 row = 0; row < ROW; row++)
        {
            if (row < BLOCK_FAR_END)
            {
                threshold = threshold_far;
            }
            else if (row < BLOCK_MID_END)
            {
                threshold = threshold_mid;
            }
            else
            {
                threshold = threshold_near;
            }
          //��ֵ������
            for (uint16 col = 0; col < COL; col++)
            {
                 if (image[row][col] > threshold)
                 {
                   bin[row][col] = WHITE;
                 }
                 else
                 {
                   bin[row][col] = BLACK;
                 }
            }
        }
    }
}
uint8_t l_image[ROW][COL];

// 4���� �������
static const int dx[] = {-1, 1, 0, 0};
static const int dy[] = {0, 0, -1, 1};

static uint8_t qx[4096];
static uint8_t qy[4096];
static uint8_t visited[(ROW * COL + 7) / 8];
static uint8_t max_mask[(ROW * COL + 7) / 8];

// ����֡�����
static int last_cx = COL / 2;
static int last_cy = ROW / 2;
#define WEIGHT 0.7f

// ���޸����궨����ȷд��
#define MARK(i,j)      visited[(i)*COL + (j) >> 3] |= 1 << (((i)*COL + (j)) & 7)
#define IS_MARKED(i,j) (visited[(i)*COL + (j) >> 3] & (1 << (((i)*COL + (j)) & 7)))
#define MARK_MAX(i,j)  max_mask[(i)*COL + (j) >> 3] |= 1 << (((i)*COL + (j)) & 7)
#define IN_MAX(i,j)    (max_mask[(i)*COL + (j) >> 3] & (1 << (((i)*COL + (j)) & 7)))

void lvbo(uint8_t (*image)[COL])
{
    int total_bytes = (ROW * COL + 7) / 8;
    int i, j;

    // ��ձ��
    for (i = 0; i < total_bytes; i++)
    {
        visited[i] = 0;
        max_mask[i] = 0;
    }

    int max_area = 0;
    int best_i = 0, best_j = 0;

    // ===================== һ�α����������ͨ�� =====================
    for (i = 0; i < ROW; i++)
    {
        for (j = 0; j < COL; j++)
        {
            if (image[i][j] == WHITE && !IS_MARKED(i, j))
            {
                int front = 0, rear = 0;
                qx[rear] = i;
                qy[rear] = j;
                rear++;
                MARK(i, j);

                int area = 1;
                int sum_x = i;
                int sum_y = j;

                while (front < rear && rear < 4095)
                {
                    int x = qx[front];
                    int y = qy[front];
                    front++;

                    for (int k = 0; k < 4; k++)
                    {
                        int nx = x + dx[k];
                        int ny = y + dy[k];
                        if (nx >= 0 && nx < ROW && ny >= 0 && ny < COL)
                        {
                            if (image[nx][ny] == WHITE && !IS_MARKED(nx, ny))
                            {
                                MARK(nx, ny);
                                qx[rear] = nx;
                                qy[rear] = ny;
                                rear++;
                                area++;
                                sum_x += nx;
                                sum_y += ny;
                            }
                        }
                    }
                }

                // �������ĵ�
                int cx = sum_x / area;
                int cy = sum_y / area;

                // ³����ѡ�񣺾������� + �������
                int dist_sq = (cx - last_cx)*(cx - last_cx) + (cy - last_cy)*(cy - last_cy);
                if ((area > max_area && dist_sq < 225) || area > max_area + 15)
                {
                    max_area = area;
                    best_i = i;
                    best_j = j;

                    // ƽ�����ĵ�
                    last_cx = (int)(last_cx * WEIGHT + cx * (1 - WEIGHT));
                    last_cy = (int)(last_cy * WEIGHT + cy * (1 - WEIGHT));
                }
            }
        }
    }

    // û���ҵ�Ŀ��
    if (max_area == 0)
    {
        for (i = 0; i < ROW; i++)
            for (j = 0; j < COL; j++)
                l_image[i][j] = BLACK;
        return;
    }

    // ===================== ����Ⱦ���� =====================
    for (i = 0; i < total_bytes; i++) visited[i] = 0;
    int front = 0, rear = 0;
    qx[rear] = best_i;
    qy[rear] = best_j;
    rear++;
    MARK(best_i, best_j);
    MARK_MAX(best_i, best_j);

    while (front < rear && rear < 4095)
    {
        int x = qx[front];
        int y = qy[front];
        front++;

        for (int k = 0; k < 4; k++)
        {
            int nx = x + dx[k];
            int ny = y + dy[k];
            if (nx >= 0 && nx < ROW && ny >= 0 && ny < COL)
            {
                if (image[nx][ny] == WHITE && !IS_MARKED(nx, ny))
                {
                    MARK(nx, ny);
                    MARK_MAX(nx, ny);
                    qx[rear] = nx;
                    qy[rear] = ny;
                    rear++;
                }
            }
        }
    }

    // ===================== �������ͼ�� =====================
    for (i = 0; i < ROW; i++)
    {
        for (j = 0; j < COL; j++)
        {
            l_image[i][j] = IN_MAX(i, j) ? WHITE : BLACK;
        }
    }
}
uint8 pengzhang_img[ROW][COL];

void pengzhang(uint8_t (*image)[COL])
{
    int i, j;

    // �����������أ���Ե����������ֹԽ�磩
    for (i = 0; i < ROW - 1; i++)
    {
        for (j = 0; j < COL - 1; j++)
        {
            // ===================== ����߼� =====================
            // ��Χ 8 ������ ֻҪ�� 1 ����ɫ �� ��ǰ���ɰ�ɫ
            if(
                image[i-1][j-1] == WHITE ||    // ����
                image[i-1][j]   == WHITE ||    // ��
                image[i-1][j+1] == WHITE ||    // ����
                image[i][j-1]   == WHITE ||    // ��
                image[i][j+1]   == WHITE ||    // ��
                image[i+1][j-1] == WHITE ||    // ����
                image[i+1][j]   == WHITE ||    // ��
                image[i+1][j+1] == WHITE       // ����
            )
            {
                pengzhang_img[i][j] = WHITE;
            }
            // ��Χȫ�Ǻ�ɫ �� ������ɫ
            else
            {
                pengzhang_img[i][j] = BLACK;
            }
        }
    }
}
/**
 * @brief  ��̬ѧ�˲����޳��������ɫ�����
 * @note   �ڶ�ֵ��֮��������֮ǰ����
 *         ֻ����ϸ���������߽磬Ĩ������ɫ��������
 */
void remove_large_noise_blobs(void)
{
    const int MAX_LINE_WIDTH  = 30;   // ��������ı߽���ȣ����أ�
    const int MAX_BLOB_HEIGHT = 40;   // ��������İ׿�߶ȣ����أ�

    static uint8_t row_white_run[ROW][2]; // [0]=��ʼ��, [1]=������
    static uint8_t blob_height[ROW];      // ��ǰ�жε������߶�

    for (int row = 0; row < ROW; row++) {
        int col = 0;
        while (col < COL) {
            // �Ұ�ɫ�ε���ʼ
            if (bin_image[row][col] != WHITE) {
                col++;
                continue;
            }
            int start = col;
            // �Ұ�ɫ�εĽ���
            while (col < COL && bin_image[row][col] == WHITE) {
                col++;
            }
            int end = col - 1;
            int width = end - start + 1;

            // ---- ����1�������ж� ----
            if (width > MAX_LINE_WIDTH) {
                // ̫�����������Ǳ߽磬ֱ��Ϳ��
                for (int c = start; c <= end; c++) {
                    bin_image[row][c] = BLACK;
                }
                continue;
            }

            // ---- ����2�����������ж� ----
            // ����Ƿ�����һ�����ص��İ�ɫ��
            int overlap = 0;
            if (row > 0) {
                for (int prev_col = 0; prev_col < COL; prev_col++) {
                    if (bin_image[row-1][prev_col] == WHITE) {
                        if (prev_col >= start && prev_col <= end) {
                            overlap = 1;
                            break;
                        }
                    }
                }
            }
            if (overlap) {
                blob_height[row] = blob_height[row-1] + 1;
            } else {
                blob_height[row] = 1;
            }

            // ����ۻ��߶ȳ�����ֵ��˵����һ��Ƭ�׿飬Ϳ��
            if (blob_height[row] > MAX_BLOB_HEIGHT) {
                for (int c = start; c <= end; c++) {
                    bin_image[row][c] = BLACK;
                }
                // ͬʱ����׷��Ϳ�ڣ���Ϊǰ�����û����ǣ�
                for (int r = row - 1; r >= 0 && bin_image[r][start] == WHITE; r--) {
                    for (int c = start; c <= end; c++) {
                        bin_image[r][c] = BLACK;
                    }
                }
            }
        }
    }
}
void pengzhang2(uint8_t (*image)[COL])
{
    int i, j;

    // ����ͼ�� 0 ��ʼ����
    for (i = 0; i < ROW; i++)
    {
        for (j = 0; j < COL; j++)
        {
            // Ĭ�Ϻ�ɫ
            pengzhang_img[i][j] = BLACK;

            // ��� 8 �����򣨴�Խ�籣��������������
            uint8 has_white = 0;

            // ��
            if(i > 0 && image[i-1][j] == WHITE) has_white = 1;
            // ��
            if(i < ROW-1 && image[i+1][j] == WHITE) has_white = 1;
            // ��
            if(j > 0 && image[i][j-1] == WHITE) has_white = 1;
            // ��
            if(j < COL-1 && image[i][j+1] == WHITE) has_white = 1;

            // ����
            if(i > 0 && j > 0 && image[i-1][j-1] == WHITE) has_white = 1;
            // ����
            if(i > 0 && j < COL-1 && image[i-1][j+1] == WHITE) has_white = 1;
            // ����
            if(i < ROW-1 && j > 0 && image[i+1][j-1] == WHITE) has_white = 1;
            // ����
            if(i < ROW-1 && j < COL-1 && image[i+1][j+1] == WHITE) has_white = 1;

            // ֻҪ��Χ�а�ɫ �� ���ͳɰ�ɫ
            if(has_white)
            {
                pengzhang_img[i][j] = WHITE;
            }
            else
            {
                pengzhang_img[i][j] = BLACK;
            }
        }
    }
}
// ������������ֱ��ͼ����λ��
static uint8_t hist_median(const uint32_t hist[256], int total) {
    uint32_t cum = 0;
    uint32_t half = total / 2;
    for (int i = 0; i < 256; i++) {
        cum += hist[i];
        if (cum >= half) return (uint8_t)i;
    }
    return 128;
}

// �����������޷�
static uint8_t clamp_int(int val, int lo, int hi) {
    if (val < lo) return (uint8_t)lo;
    if (val > hi) return (uint8_t)hi;
    return (uint8_t)val;
}

void image_binarize_724(uint8 (*src_image)[COL])
{
    // ====================== ��̬״̬ ======================
    static float smooth_thresh_near = 180.0f;
    static float smooth_thresh_mid  = 180.0f;
    static float smooth_thresh_far  = 180.0f;
    static uint8_t init_done = 0;

    // ====================== �������� ======================
    const int offset = 40;
    const float alpha = 0.90f;
    const int min_thresh = 160;
    const int max_thresh = 210;
    const int edge_margin = 30;      // �� ��Ե���ȣ����أ�
    const int edge_bias = 15;        // �� ��Ե��ֵƫ��������Сֵ��10~20֮�䣩

    // ====================== ��һ������������� ======================
    const int near_start = 80, near_end = 119;
    const int mid_start  = 40, mid_end  = 79;
    const int far_start  = 0,  far_end  = 39;

    const int step_row = 2;
    const int step_col = 4;

    uint32_t hist_near[256] = {0};
    uint32_t hist_mid[256]  = {0};
    uint32_t hist_far[256]  = {0};
    int cnt_near = 0, cnt_mid = 0, cnt_far = 0;

    // ��������
    for (int r = near_start; r <= near_end; r += step_row) {
        for (int c = 0; c < COL; c += step_col) {
            uint8_t gray = src_image[r][c];
            hist_near[gray]++;
            cnt_near++;
        }
    }
    // �в�����
    for (int r = mid_start; r <= mid_end; r += step_row) {
        for (int c = 0; c < COL; c += step_col) {
            uint8_t gray = src_image[r][c];
            hist_mid[gray]++;
            cnt_mid++;
        }
    }
    // Զ������
    for (int r = far_start; r <= far_end; r += step_row) {
        for (int c = 0; c < COL; c += step_col) {
            uint8_t gray = src_image[r][c];
            hist_far[gray]++;
            cnt_far++;
        }
    }

    // ���������λ��
    uint8_t median_near = hist_median(hist_near, cnt_near);
    uint8_t median_mid  = hist_median(hist_mid,  cnt_mid);
    uint8_t median_far  = hist_median(hist_far,  cnt_far);

    // ����ԭʼ��ֵ���޷�
    int raw_near = (int)median_near - offset;
    int raw_mid  = (int)median_mid  - offset;
    int raw_far  = (int)median_far  - offset;

    uint8_t thresh_near = clamp_int(raw_near, min_thresh, max_thresh);
    uint8_t thresh_mid  = clamp_int(raw_mid,  min_thresh, max_thresh);
    uint8_t thresh_far  = clamp_int(raw_far,  min_thresh, max_thresh);

    // ====================== �ڶ�����֡��ƽ�� ======================
    if (!init_done) {
        smooth_thresh_near = (float)thresh_near;
        smooth_thresh_mid  = (float)thresh_mid;
        smooth_thresh_far  = (float)thresh_far;
        init_done = 1;
    }
    smooth_thresh_near = alpha * smooth_thresh_near + (1.0f - alpha) * (float)thresh_near;
    smooth_thresh_mid  = alpha * smooth_thresh_mid  + (1.0f - alpha) * (float)thresh_mid;
    smooth_thresh_far  = alpha * smooth_thresh_far  + (1.0f - alpha) * (float)thresh_far;

    // ====================== ����������ֵ�����м����Բ�ֵ + ��Եƫ�ã� ======================
    uint8_t *src_ptr = (uint8_t *)src_image;
    uint8_t *dst_ptr = (uint8_t *)bin_image;
    int white_cnt = 0, black_cnt = 0;

    for (uint16_t row = 0; row < ROW; row++)
    {
        // ���㵱ǰ�л�����ֵ
        uint8_t base_thresh;
        if (row >= 80) {
            base_thresh = (uint8_t)(smooth_thresh_near + 0.5f);
        } else if (row >= 40) {
            float t = (float)(row - 40) / 40.0f;
            base_thresh = (uint8_t)(smooth_thresh_mid * (1.0f - t) + smooth_thresh_near * t + 0.5f);
        } else {
            float t = (float)row / 40.0f;
            base_thresh = (uint8_t)(smooth_thresh_far * (1.0f - t) + smooth_thresh_mid * t + 0.5f);
        }

        uint8_t *row_src = src_ptr + row * COL;
        uint8_t *row_dst = dst_ptr + row * COL;
        uint32_t row_batch = COL >> 3;   // 23
        for (uint32_t j = 0; j < row_batch; j++) {
            uint8_t p;
            // �� ���㵱ǰ8���ؿ���ÿ�����ص�ʵ����ֵ����Ե���ͣ�
            #define PROCESS_PIXEL_EDGE() do { \
                int col = (int)(row_src - (src_ptr + row * COL)); \
                uint8_t thresh = base_thresh; \
                if (col < edge_margin || col >= COL - edge_margin) { \
                    thresh = (uint8_t)(base_thresh - edge_bias); \
                } \
                p = *row_src++; \
                *row_dst++ = (p > thresh) ? WHITE : BLACK; \
                if (p > thresh) white_cnt++; else black_cnt++; \
            } while(0)
            PROCESS_PIXEL_EDGE(); PROCESS_PIXEL_EDGE(); PROCESS_PIXEL_EDGE(); PROCESS_PIXEL_EDGE();
            PROCESS_PIXEL_EDGE(); PROCESS_PIXEL_EDGE(); PROCESS_PIXEL_EDGE(); PROCESS_PIXEL_EDGE();
            #undef PROCESS_PIXEL_EDGE
        }
        // ʣ����
        uint32_t remain = COL & 0x07;
        while (remain--) {
            int col = (int)(row_src - (src_ptr + row * COL));
            uint8_t thresh = base_thresh;
            if (col < edge_margin || col >= COL - edge_margin) {
                thresh = (uint8_t)(base_thresh - edge_bias);
            }
            uint8_t p = *row_src++;
            *row_dst++ = (p > thresh) ? WHITE : BLACK;
            if (p > thresh) white_cnt++; else black_cnt++;
        }
    }

    // ====================== ���Ĳ���ͣ������ ======================
    static int white_flag = 0, black_flag = 0;
    if (white_cnt > 12000) white_flag++; else white_flag = 0;
    if (black_cnt > 23000) black_flag++; else black_flag = 0;
    if (white_flag >= 3 || black_flag >= 3) {
        boolean int_state = IfxCpu_disableInterrupts();
        imgstop_flag = 1;
        IfxCpu_restoreInterrupts(int_state);
    }
}
