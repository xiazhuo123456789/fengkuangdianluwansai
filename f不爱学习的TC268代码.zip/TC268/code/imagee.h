#ifndef CODE_IMAGEE_H_
#define CODE_IMAGEE_H_

#include "zf_common_headfile.h"
#include <stdint.h>
#define COL                 188
#define ROW                 120

//��ɫ
#define BLACK 0
#define WHITE 255
//��ֵ�޷�
#define Threshold_MAX 200
#define Threshold_MIN 100
//extern
extern uint8 bin[ROW][COL];
extern uint8 lvbo_image[ROW][COL];
extern uint8_t l_image[ROW][COL];
extern uint8 pengzhang_img[ROW][COL];
void pengzhang2(uint8_t (*image)[COL]);
void pengzhang(uint8_t (*image)[COL]);
void lvbo(uint8_t (*image)[COL]);
uint8 Otsu(uint8 *image, uint16 col, uint16 row_start, uint16 row_end);
void binarization(uint8 (*image)[COL]);
uint32 bfs_find_area(uint8 (*src)[COL], uint16 r, uint16 c, uint8 label);
void image_binarize_filter(uint8 (*src_image)[COL]);
void image_binarize_ceshi(uint8 (*src_image)[COL]);
void remove_large_noise_blobs(void);
void image_binarize_724(uint8 (*src_image)[COL]);
#endif
