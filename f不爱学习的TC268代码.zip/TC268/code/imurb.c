#include "imurb.h"
//Gyroz
float Gyro_offset =0;
float Gyro_offset_3ms =0;
float Gyroz_angle =0;
float Gyroz_rad =0;

//Yaw
float Yaw_rad = 0;
float Yaw_angle= 20;

void Gyro_Offset_Init(void)
{
    Gyro_offset =0;

    for (uint16_t i = 0; i < 100; i++)
    {

        Gyro_offset += imu660rb_gyro_z;
        system_delay_ms(5);
    }

    Gyro_offset /= 100;

}
void Gyro_Offset_Init_3ms(void)
{
    Gyro_offset_3ms =0;

    for (uint16_t i = 0; i < 300; i++)
    {

        Gyro_offset_3ms += imu660rb_gyro_z;
        system_delay_ms(3);
    }

    Gyro_offset_3ms /= 300;

}
void Get_gyroz(void)
{
    imu660rb_get_gyro();
    //���ٶ�--�Ƕ���
    //Gyroz_angle = ((float)imu660rb_gyro_z - Gyro_offset) / 14.3f ;
    //���ٶ�--������
    Gyroz_rad = ((float)imu660rb_gyro_z - Gyro_offset) * PI / 180 / 14.3;
   // Debug_Turn_Speed_Proc_vofa(Gyroz_rad);
    //ips114_show_float(100, 30, Gyroz_rad, 5, 5);

}
void Get_gyroz_3ms(void)
{
    imu660rb_get_gyro();
    //���ٶ�--�Ƕ���
    //Gyroz_angle = ((float)imu660rb_gyro_z - Gyro_offset) / 14.3f ;
    //���ٶ�--������
    Gyroz_rad = ((float)imu660rb_gyro_z - Gyro_offset_3ms) * PI / 180 / 14.3;


    //Debug_Turn_Speed_Proc_vofa(Gyroz_rad);
    //Debug_Turn_Speed_Proc_vofa(imu660rb_gyro_z);
                  //  ips114_show_float(120, 50, 10, 3, 2);


}

static void IMU_Handle_0(void)
{
    Yaw_rad +=(Gyroz_rad * 0.005);
}

static void IMU_Handle_0_3ms(void)
{
    Yaw_rad +=(Gyroz_rad * 0.003);
}
float rad2angle(float rad)
{
    // ��ʽ���Ƕ� = ���� �� 180 / ��
    return rad * 180.0f / 3.1415926535898f;
}
void Get_Yaw(void)
{
    // Z��������С����ֵ������
    if (Gyroz_rad >= 0.008f || Gyroz_rad <= -0.008f)
    {
        IMU_Handle_0();

        Yaw_angle = rad2angle(Yaw_rad);

    }
}
void Get_Yaw_3ms(void)
{
    // Z��������С����ֵ������
    if (Gyroz_rad >= 0.015f || Gyroz_rad <= -0.015f)
    {
        IMU_Handle_0_3ms();

        Yaw_angle = rad2angle(Yaw_rad);

    }
}
void Gyro_init(void)
{
    imu660rb_init();
    Gyro_Offset_Init();
}
void Gyro_init_3ms(void)
{
    imu660rb_init();
    Gyro_Offset_Init_3ms();
}

void Gyro_proc(void)
{//debug_data_ready =1;

    Get_gyroz();
    Get_Yaw();
}
void Gyro_proc_3ms(void)
{
    Get_gyroz_3ms();
    Get_Yaw_3ms();


}
