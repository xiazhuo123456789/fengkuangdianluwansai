
#ifndef CODE_IMURB_H_
#define CODE_IMURB_H_

#include "zf_common_headfile.h"
void IMU_gyro_Offset_Init(void);
void Get_gyroz(void);
void Get_Yaw(void);
void Gyro_init(void);
void Gyro_proc(void);

void Gyro_Offset_Init_3ms(void);
void Gyro_init_3ms(void);
void Get_gyroz_3ms(void);
void Gyro_proc_3ms(void);
extern float Yaw_rad;
extern float Yaw_angle;

extern float Gyroz_rad;
extern float Gyroz_angle;

#endif /* CODE_KEY_H_ */
