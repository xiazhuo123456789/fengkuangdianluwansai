#ifndef CODE_INIT_H_
#define CODE_INIT_H_

#include "zf_common_headfile.h"

#define FUYA_PWM_PERCENT        40
#define FUYA_PWM_DUTY           ((FUYA_PWM_PERCENT * PWM_DUTY_MAX) / 100)

#define RUN_TIME                15

#define DEBUG_MODE              0

#define WIRELESS_UART_ENABLE    ((DEBUG_MODE == 1) || (DEBUG_MODE / 10 == 1) || (DEBUG_MODE % 10 == 1))
#define BLE6A20_ENABLE          ((DEBUG_MODE == 2) || (DEBUG_MODE / 10 == 2) || (DEBUG_MODE % 10 == 2))
#define WIFI_SPI_ENABLE         ((DEBUG_MODE == 3) || (DEBUG_MODE / 10 == 3) || (DEBUG_MODE % 10 == 3))

#define WIFI_SSID_TEST          "fishp"
#define WIFI_PASSWORD_TEST      "11111111"
#define TCP_TARGET_IP           "10.127.86.1"
#define TCP_TARGET_PORT         "8086"
#define WIFI_LOCAL_PORT         "6666"

#define KEY1                    (P20_6)
#define KEY2                    (P20_7)
#define KEY3                    (P11_2)
#define KEY4                    (P11_3)

#define BUZZER_PIN              (P33_10)

#define FUYA_PWM                (ATOM1_CH0_P21_2)
#define PWM_4              (ATOM0_CH0_P21_2)
#define FREQ               (50)

#define MOTOR_DIR_L             (P11_9)
#define MOTOR_PWM_L             (ATOM3_CH5_P11_10)
#define MOTOR_DIR_R             (P11_11)
#define MOTOR_PWM_R             (ATOM2_CH7_P11_12)

#define ENCODER_L               (TIM4_ENCODER)
#define ENCODER_PULSE_L         (TIM4_ENCODER_CH1_P02_8)
#define ENCODER_DIR_L           (TIM4_ENCODER_CH2_P00_9)
#define ENCODER_R               (TIM6_ENCODER)
#define ENCODER_PULSE_R         (TIM6_ENCODER_CH1_P20_3)
#define ENCODER_DIR_R           (TIM6_ENCODER_CH2_P20_0)

void peripheral_init(void);

#endif /* CODE_INIT_H_ */
