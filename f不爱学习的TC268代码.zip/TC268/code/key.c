#include "key.h"

uint8 key_val, key_down, key_up, key_old;
uint8 start_flag;

void key_proc(void)
{
    key_val = key_read();
    key_down = key_val & (key_val ^ key_old);
    key_up  = ~key_val & (key_val ^ key_old);
    key_old = key_val;

    switch (key_down)
    {
        case 1:
            reset_all();
        break;
        case 2:
            reset_all();
        break;
        case 3:
            reset_all();
        break;
        case 4:
            if (++start_flag >= 2)
            {
                start_flag = 0;
            }
        break;
    }
}

uint8 key_read(void)
{
    uint8 temp = 0;

    if (gpio_get_level(KEY1) == 0) temp = 1;
    if (gpio_get_level(KEY2) == 0) temp = 2;
    if (gpio_get_level(KEY3) == 0) temp = 3;
    if (gpio_get_level(KEY4) == 0) temp = 4;

    return temp;
}
