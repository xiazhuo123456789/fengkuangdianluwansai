#include "keyy.h"

uint8 keyy_read(void)
{
    uint8 num = 0;

    if (gpio_get_level(KEY1) == 0) num = 1;
    if (gpio_get_level(KEY2) == 0) num = 2;
    if (gpio_get_level(KEY3) == 0) num = 3;
    if (gpio_get_level(KEY4) == 0) num = 4;

    return num;
}

int keyy_proc(void)
{
    int key_num = keyy_read();
    int key_numm;
    if(key_num == 1)
    {
        key_numm =1;
    }
    else if(key_num == 2)
    {
        key_numm=2;
    }
    else if(key_num == 3)
    {
        key_numm=3;
    }
    else if(key_num == 4)
    {
        key_numm=4;
    }
    return key_numm;
}
