#ifndef CODE_KEYY_H_
#define CODE_KEYY_H_

#include "zf_common_headfile.h"
uint8 keyy_read(void);
extern uint8 start_flag;

#endif /* CODE_KEY_H_ */
