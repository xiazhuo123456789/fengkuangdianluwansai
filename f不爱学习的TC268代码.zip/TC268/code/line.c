#include "line.h"
uint8_t Line_L[MT9V03X_1_H] = {0};
uint8_t Line_R[MT9V03X_1_H] = {0};
uint8_t Line_LL[MT9V03X_1_H] = {0};
uint8_t Line_RR[MT9V03X_1_H] = {0};
uint8_t Line_M[MT9V03X_1_H] = {0};
uint8_t Line_MM[MT9V03X_1_H] = {0};
uint8_t Line_MMM[MT9V03X_1_H] = {0};
static int point_row = 0;
// 传入图像数组：uint8 (*src_image)[COL]
void find_lrm_line(uint8 (*src_image)[COL])
{
    uint8_t l_flag, r_flag;

    // 初始化边线数组,赋初值
    memset(Line_L, 0, sizeof(Line_L));
    memset(Line_R, COL - 1, sizeof(Line_R));
    memset(Line_M, COL / 2, sizeof(Line_M));

    // 从近到远逐行处理
    for (int row = ROW - 1; row >= 0; row--)
    {
        l_flag = 0;
        r_flag = 0;

        // ===== 左边界检测 =====
        for (uint8 col = 0; col <= COL - 2; col++)
        {
            // 使用传入的图像 src_image
            if (src_image[row][col] == BLACK && src_image[row][col + 1] == WHITE)
            {
                l_flag = 1;
                Line_L[row] = col;
                break;
            }
        }
        if (!l_flag)
        {
            Line_L[row] = 0;
        }

        // ===== 右边界检测 =====
        for (uint8 col = COL - 1; col >= 2; col--)
        {
            // 使用传入的图像 src_image
            if (src_image[row][col] == BLACK && src_image[row][col - 1] == WHITE)
            {
                r_flag = 1;
                Line_R[row] = col;
                break;
            }
        }
        if (!r_flag)
        {
            Line_R[row] = COL - 1;
        }

        // ===== 中心线 =====
        Line_M[row] = (Line_L[row] + Line_R[row]) / 2;
    }
}
void find_lrm_line_ceshi(uint8 (*src_image)[COL])
{
    uint8_t *row_ptr;           // 指向当前行首的指针
    uint8_t *p;                 // 扫描指针
    uint8_t *row_end;           // 行尾后一位指针（COL列）
    uint8_t *left_limit;        // 左扫描终点
    uint8_t *right_limit;       // 右扫描终点

    // 初始化边线数组
    memset(Line_L, 0, sizeof(Line_L));
    memset(Line_R, COL - 1, sizeof(Line_R));
    memset(Line_M, COL / 2, sizeof(Line_M));

    // 从近到远逐行处理（ROW-1 到 0）
    for (int row = ROW - 1; row >= 0; row--)
    {
        // 当前行的起始地址
        row_ptr   = (uint8_t *)&src_image[row][0];
        row_end   = row_ptr + COL;
        left_limit = row_end - 1;   // 最多扫到 COL-2
        right_limit = row_ptr + 1;  // 最少扫到列 1（COL>=2）

        // --- 左边界检测 ---
        p = row_ptr;
        while (p < left_limit)
        {
            // 检查 p 为黑 且 p+1 为白
            if ((*p == BLACK) && (*(p + 1) == WHITE))
            {
                Line_L[row] = (uint8)(p - row_ptr);
                break;
            }
            p++;
        }
        // 如果未找到，Line_L[row] 保持 memset 赋的 0（符合原逻辑）

        // --- 右边界检测 ---
        p = row_end - 1;            // 从最右列开始
        while (p > right_limit)
        {
            // 检查 p 为黑 且 p-1 为白（即右边界的黑‑白跳变）
            if ((*p == BLACK) && (*(p - 1) == WHITE))
            {
                Line_R[row] = (uint8)(p - row_ptr);
                break;
            }
            p--;
        }
        // 如果未找到，Line_R[row] 保持 memset 赋的 COL-1

        // --- 中心线 ---
        Line_M[row] = (Line_L[row] + Line_R[row]) / 2;
    }
}
/**
 * @brief  在图像的某一列上竖直扫描边界模式：黑-黑-白-白
 * @param  col     要扫描的列
 * @param  start   起始行号（包含）
 * @param  end     结束行号（包含）
 * @param  step    扫描方向：+1 为从上往下（行号增大），-1 为从下往上（行号减小）
 * @param  found_row  如果找到，存储第一个白点所在的行号
 * @return 1 表示找到，0 表示未找到
 */
int scan_vertical_boundary(int col, int start, int end, int step, int *found_row)
{
    // 确保扫描范围不越界
    if (col < 0 || col >= COL) return 0;
    if (start < 0) start = 0;
    if (end >= ROW) end = ROW - 1;

    // 确定扫描方向
    int i = start;
    int continue_cond; // 用于判断是否继续循环
    if (step > 0) {
        continue_cond = (i <= end - 3); // 需要连续4个像素，所以最多到 end-3
    } else {
        continue_cond = (i >= end + 3);
    }

    for (; ; i += step) {
        if (step > 0) {
            if (i > end - 3) break;
        } else {
            if (i < end + 3) break;
        }

        // 读取连续四个像素
        uint8 p0 = bin_image[i][col];
        uint8 p1 = bin_image[i + step][col];
        uint8 p2 = bin_image[i + 2*step][col];
        uint8 p3 = bin_image[i + 3*step][col];

        if (p0 == BLACK && p1 == BLACK && p2 == WHITE && p3 == WHITE) {
            *found_row = (step > 0) ? (i + 2) : (i - 2); // 第一个白点的行号
            return 1;
        }
    }
    return 0;
}
/**
 * @brief  竖向扫线函数：检测指定列上从两端向中间是否各只有一条边界
 * @param  start      起始行号（近端或远端，函数自动标准化为较大值）
 * @param  end        结束行号
 * @param  col        要扫描的列
 * @param  src_image  二值图像数组
 * @return 1：该列两端各恰好一个“黑-黑-白-白”边界，0：不符合条件
 */
int scan_vertical_line(int start, int end, int col, uint8 (*src_image)[COL])
{
    // 标准化：确保 start > end，即 start 为行号大的（近端），end 为行号小的（远端）
    if (start < end) {
        int temp = start;
        start = end;
        end = temp;
    }

    // 边界保护
    if (col < 0 || col >= COL) return 0;
    if (start >= ROW) start = ROW - 1;
    if (end < 0) end = 0;

    // 指向该列首地址的指针，消除二维索引的乘法运算
    uint8 *col_ptr = &src_image[0][col];

    int xian1 = 0;  // 从 start 向 end 扫描找到的边界数
    int xian2 = 0;  // 从 end 向 start 扫描找到的边界数

    // ===== 第一次：从 start 向 end（行号递减）扫描 =====
    for (int i = start; i >= end + 3; i--)   // 需要连续4个像素，所以至少留出3行空间
    {
        // 直接通过指针读取相邻四个像素
        if (col_ptr[i]   == BLACK &&
            col_ptr[i-1] == BLACK &&
            col_ptr[i-2] == WHITE &&
            col_ptr[i-3] == WHITE)
        {
            xian1++;
            if (xian1 > 1)   // 找到第二个边界，直接失败
                return 0;
            i -= 2;          // 跳过本次边界，避免重复计数同一段白
        }
    }

    // ===== 第二次：从 end 向 start（行号递增）扫描 =====
    for (int i = end; i <= start - 3; i++)
    {
        if (col_ptr[i]   == BLACK &&
            col_ptr[i+1] == BLACK &&
            col_ptr[i+2] == WHITE &&
            col_ptr[i+3] == WHITE)
        {
            xian2++;
            if (xian2 > 1)
                return 0;
            i += 2;          // 跳过本次边界
        }
    }

    // 两端各恰好一个边界
    return (xian1 == 1 && xian2 == 1) ? 1 : 0;
}
/********************************************无用********************************************************/
void find_lrm_lineMM(uint8 (*src_image)[COL])
{
    uint8_t l_flag, r_flag;

    // 初始化边线数组,赋初值
    memset(Line_LL, 0, sizeof(Line_LL));
    memset(Line_RR, COL - 1, sizeof(Line_RR));
    memset(Line_MM, COL / 2, sizeof(Line_MM));

    // 从近到远逐行处理
    for (int row = ROW - 1; row >= 0; row--)
    {
        l_flag = 0;
        r_flag = 0;

        // ===== 左边界检测 =====
        for (uint8 col = 0; col <= COL - 2; col++)
        {
            // 使用传入的图像 src_image
            if (src_image[row][col] == BLACK && src_image[row][col + 1] == WHITE)
            {
                l_flag = 1;
                Line_LL[row] = col;
                break;
            }
        }
        if (!l_flag)
        {
            Line_LL[row] = 0;
        }

        // ===== 右边界检测 =====
        for (uint8 col = COL - 1; col >= 2; col--)
        {
            // 使用传入的图像 src_image
            if (src_image[row][col] == BLACK && src_image[row][col - 1] == WHITE)
            {
                r_flag = 1;
                Line_RR[row] = col;
                break;
            }
        }
        if (!r_flag)
        {
            Line_RR[row] = COL - 1;
        }

        // ===== 中心线 =====
        Line_MM[row] = (Line_LL[row] + Line_RR[row]) / 2;
    }
}
void find_lrm_line1(void)
{
    uint8_t l_flag, r_flag;  // 完全保留原版标志位
    uint8_t seed_col;
    int8_t c;

    // ==================== 初始化（和原版完全一样）====================
    memset(Line_L, 0, sizeof(Line_L));
    memset(Line_R, COL - 1, sizeof(Line_R));
    memset(Line_M, COL / 2, sizeof(Line_M));

    // 初始种子 = 画面中心
    seed_col = COL / 2;

    // ==================== 从近到远逐行处理（和原版完全一样）====================
    for(int row = ROW-1; row >= 0 ; row--)
    {
        l_flag = 0;
        r_flag = 0;

        // ==================== 种子法：从当前种子列向左右生长 ====================
        // 只有种子点在赛道上，才进行生长
        if(bin_image[row][seed_col] == WHITE)
        {
            // -------- 向左生长找左边界 --------
            uint8_t left_bound = seed_col;
            for(c = seed_col; c >= 0; c--)
            {
                if(bin_image[row][c] == WHITE)
                {
                    left_bound = c;
                    l_flag = 1;  // 标记找到左边界
                }
                else break;
            }

            // -------- 向右生长找右边界 --------
            uint8_t right_bound = seed_col;
            for(c = seed_col; c < COL; c++)
            {
                if(bin_image[row][c] == WHITE)
                {
                    right_bound = c;
                    r_flag = 1;  // 标记找到右边界
                }
                else break;
            }

            // 赋值找到的边界
            Line_L[row] = left_bound;
            Line_R[row] = right_bound;
        }

        // ==================== 【原版核心规则：找不到就强制置最左/最右】====================
        if (!l_flag)
        {
            Line_L[row] = 0;        // 左边界 = 最左
        }
        if (!r_flag)
        {
            Line_R[row] = COL - 1;  // 右边界 = 最右
        }

        // ==================== 计算中心线（和原版一样）====================
        Line_M[row] = (Line_L[row] + Line_R[row]) / 2;

        // ==================== 更新下一行种子（种子法核心）====================
        seed_col = Line_M[row];
    }
}

// 真正的种子生长法巡线
void find_lrm_line2(void)
{
    uint8_t seed_row, seed_col;     // 种子起点坐标
    uint8_t left, right;
    int8_t c;

    // 初始化数组
    memset(Line_L, 0, sizeof(Line_L));
    memset(Line_R, COL-1, sizeof(Line_R));
    memset(Line_M, COL/2, sizeof(Line_M));

    // ===================== 1. 找种子点（最下方行中间位置）=====================
    seed_row = ROW - 1;  // 最近一行作为种子行
    seed_col = COL / 2;  // 中间作为种子列

    // 如果中间不是白色，向右找一个白色点作为种子
    while(seed_col < COL && bin_image[seed_row][seed_col] != WHITE)
    {
        seed_col++;
    }
    // 如果还找不到，向左找
    if(seed_col >= COL)
    {
        seed_col = COL/2;
        while(seed_col > 0 && bin_image[seed_row][seed_col] != WHITE)
        {
            seed_col--;
        }
    }

    // ===================== 2. 从种子行开始，向上逐行生长（核心！种子法）=====================
    // 从种子行向上遍历所有行
    for(int row = seed_row; row >= 0; row--)
    {
        // 如果当前行种子点不是赛道，直接继承上一行的边界（防丢线）
        if(bin_image[row][seed_col] != WHITE)
        {
            if(row < ROW-1)
            {
                Line_L[row] = Line_L[row+1];
                Line_R[row] = Line_R[row+1];
                Line_M[row] = (Line_L[row] + Line_R[row])/2;
                continue;
            }
            else break;
        }

        // ========== 从种子列 向左生长 找左边界 ==========
        left = seed_col;
        for(c = seed_col; c >= 0; c--)
        {
            if(bin_image[row][c] == WHITE) left = c;
            else break;  // 遇到黑色背景停止生长
        }

        // ========== 从种子列 向右生长 找右边界 ==========
        right = seed_col;
        for(c = seed_col; c < COL; c++)
        {
            if(bin_image[row][c] == WHITE) right = c;
            else break;  // 遇到黑色背景停止生长
        }

        // 保存当前行的左右边界
        Line_L[row] = left;
        Line_R[row] = right;
        Line_M[row] = (left + right) / 2;

        // 更新下一行的种子列（用当前行中心线）
        seed_col = Line_M[row];
    }
}/*函数作用
 * 将y1~y2区间的Line全偏置到绘制的直线中
 */
void line_offset(uint8 x1, uint8 y1, uint8 x2, uint8 y2)
{
    uint8 i, a1, a2, temp;
        uint8 hx;

    limitt_uint8(x1,0,COL-1);
    limitt_uint8(y1,0,ROW-1);
    limitt_uint8(x2,0,COL-1);
    limitt_uint8(y2,0,ROW-1);
    a1 = y1;
    a2 = y2;

    if (a1 > a2)
    {
        temp = a1;
        a1 = a2;
        a2 = temp;
    }

    for (i = a1; i <= a2; i++)
    {
        hx = (i - y1) * (x2 - x1) / (y2 - y1) + x1;

        if (hx >= COL)
            hx = COL - 1;
        else if (hx <= 0)
            hx = 0;

        Line_L[i] = hx;
        Line_R[i] = hx;
        Line_M[i] = hx;
    }
}

void line_2_left(uint8 (*bin_image)[COL])
{
    point_row = point_l;
    if(point_l != 0)
    {
        line_offset(0 , point_row , 0 , 0 );
    }
    else
    {

        uint8 tb = find_line_bottom(0, bin_image);

       if (tb != 0)
       {
           line_offset(0, tb, 0, 0);
       }
    }

}
void line_2_left1(uint8 (*bin_image)[COL])
{
    point_row = point_lx;
    if(point_lx != 0)
    {
        line_offset(0 , (uint8)point_row , 0 , 0 );
    }
    else
    {

        uint8 tb = find_line_bottom(0, bin_image);

       if (tb != 0)
       {
           line_offset(0, tb, 0, 0);
       }
    }

}
void line_2_right(uint8 (*bin_image)[COL])
{
    point_row = point_r;
    if(point_r != 0)
    {
        line_offset((uint8)(COL - 1), (uint8)point_row, (uint8)(COL - 1), 0);;
    }
    else
    {
        uint8 tb = find_line_bottom(COL - 2, bin_image);

         if (tb != 0)
         {
             line_offset(COL - 1, tb, COL - 1, 0);
         }
    }
}
void line_2_right1(uint8 (*bin_image)[COL])
{
    point_row = point_rx;
    if(point_rx != 0)
    {
        line_offset((uint8)(COL - 1), (uint8)point_row, (uint8)(COL - 1), 0);;
    }
    else
    {
        uint8 tb = find_line_bottom(COL - 2, bin_image);

         if (tb != 0)
         {
             line_offset(COL - 1, tb, COL - 1, 0);
         }
    }
}
void fit_mid_line_least_square(void)
{
    int n = MT9V03X_1_H;
    float sum_x = 0, sum_y = 0;
    float sum_xy = 0, sum_x2 = 0;

    // 1. 累加计算
    for (int x = 0; x < n; x++)
    {
        float y = Line_M[x];
        sum_x  += x;
        sum_y  += y;
        sum_xy += x * y;
        sum_x2 += x * x;
    }

    // 2. 最小二乘公式求 k、b
    float denominator = n * sum_x2 - sum_x * sum_x;
    float k, b;

    if (denominator == 0)
    {
        k = 0;
        b = COL / 2;
    }
    else
    {
        k = (n * sum_xy - sum_x * sum_y) / denominator;
        b = (sum_y * sum_x2 - sum_x * sum_xy) / denominator;
    }

    // 3. 生成拟合后的中线 → Line_MM
    for (int x = 0; x < n; x++)
    {
        float y_fit = k * x + b;

        // 安全限幅（防止超出图像范围）
        if (y_fit < 0)
            y_fit = 0;
        if (y_fit >= COL)
            y_fit = COL - 1;

        Line_MM[x] = (uint8_t)y_fit;
    }
}


void Weighted_Line_Fit(uint8_t *Line_M, uint8_t *Line_MM, uint8_t *Line_MMM, int len)
{
    for (int i = 0; i < len; i++)
    {
        uint8_t q1 = 3;
        uint8_t q2 = 7;
        // 加权平均：M*0.4 + MM*0.6
        // 用 uint16_t 防止溢出
        if(Line_MM[i] == (COL-1)/2 && Line_M[i] != (COL-1)/2 && abs(Line_MM[i] - Line_M[i] ) >= 40)
        {
            q1 = 6;
            q2 = 4;
        }
        uint16_t val = (uint16_t)Line_M[i] * q1 + (uint16_t)Line_MM[i] * q2;
        Line_MMM[i] = val / 10;  // 等价于 0.4 + 0.6
    }
}
int LineM_average(int start , int end)
{
    uint8_t t;
    int all=0;
    if(start > end)
    {
        t = start;
        start = end;
        end = t;
    }

    for(int i = start; i <= end ;i++)
    {
        all += Line_M[i];

    }
    return (all / (end - start+1));

}
#define LOCAL_RADIUS 5   // 拐点上下各偏置的行数

/**
 * @brief  局部偏置中线：在拐点附近局部修正中线，引导车向弯道内侧靠拢
 * @note   边界安全，不会越界。用于 Go 元素中检测到拐点时。
 */
void local_line_offset(int corner_row)
{
    if (corner_row < 0 || corner_row >= ROW) return;

    // 根据拐点位置确定目标列方向
    int target_col;
    if (point_lx != 0 && point_rx == 0) {
        // 左拐点，向左偏
        target_col = 10;
    } else if (point_rx != 0 && point_lx == 0) {
        // 右拐点，向右偏
        target_col = COL - 10;
    } else {
        // 左右都有或都没有，保持中线不变
        return;
    }

    int row_start = corner_row - LOCAL_RADIUS;
    int row_end   = corner_row + LOCAL_RADIUS;
    if (row_start < 0) row_start = 0;
    if (row_end >= ROW) row_end = ROW - 1;

    for (int r = row_start; r <= row_end; r++) {
        float weight = 1.0f - (float)abs(r - corner_row) / (float)(LOCAL_RADIUS + 1);
        float new_mid = (float)Line_M[r] * (1.0f - weight) + (float)target_col * weight;
        if (new_mid < 0) new_mid = 0;
        if (new_mid >= COL) new_mid = COL - 1;
        Line_M[r] = (uint8)new_mid;
    }
}
/**
 * @brief  在拐点附近用最小二乘法拟合中线，并更新局部中线（Line_L/R/M）
 * @param  corner_row  拐点所在行号
 * @param  radius      上下扩展的行数（窗口半高）
 * @note   拟合直线 x = a * y + b，其中 y 是行号，x 是列坐标
 *         若窗口内有效点数不足 3 个，则不修改，保留原中线
 */
void local_line_fit(int corner_row, int radius)
{
    // 1. 确定窗口范围，并做边界保护
    int row_start = corner_row - radius;
    int row_end   = corner_row + radius;
    if (row_start < 0)        row_start = 0;
    if (row_end   >= ROW)     row_end   = ROW - 1;

    // 2. 收集有效数据点（行号 y，中线列 x）
    float sum_y = 0.0f, sum_x = 0.0f, sum_xy = 0.0f, sum_yy = 0.0f;
    int n = 0;  // 有效点数

    for (int r = row_start; r <= row_end; r++) {
        int x = Line_M[r];  // 直接取当前中线的列
        // 如果中线值无效（例如图像边界），可根据需要过滤；这里假设 Line_M 始终有效
        sum_y  += (float)r;
        sum_x  += (float)x;
        sum_xy += (float)r * x;
        sum_yy += (float)r * r;
        n++;
    }

    // 3. 最小二乘拟合直线 x = a * y + b
    //    若点数不足，直接放弃
    if (n < 3) return;

    float denom = (float)n * sum_yy - sum_y * sum_y;
    if (fabsf(denom) < 1e-6f) return;  // 分母接近0，拟合失败

    float a = ((float)n * sum_xy - sum_y * sum_x) / denom;  // 斜率
    float b = (sum_x - a * sum_y) / (float)n;               // 截距

    // 4. 用拟合直线更新局部窗口内的中线（以及左右边线，保持一致性）
    for (int r = row_start; r <= row_end; r++) {
        int fit_x = (int)(a * (float)r + b + 0.5f);   // 四舍五入取整

        // 边界保护
        if (fit_x < 0)        fit_x = 0;
        if (fit_x >= COL)     fit_x = COL - 1;

        Line_L[r] = (uint8)fit_x;
        Line_R[r] = (uint8)fit_x;
        Line_M[r] = (uint8)fit_x;
    }
}
/**
 * @brief  全局最小二乘拟合左右边界，生成平滑中线
 * @param  row_start  起始行（近端，行号大）
 * @param  row_end    结束行（远端，行号小）
 * @note   对 [row_end, row_start] 范围内的左右边界点分别做直线拟合，
 *         然后用拟合后的左右边界重新计算中线 Line_M。
 *         如果某侧有效边界点少于 3 个，该侧保持原 Line_M 不变。
 */
void global_line_fit(int row_start, int row_end)
{
    // 标准化：确保 row_start > row_end
    if (row_start < row_end) {
        int t = row_start;
        row_start = row_end;
        row_end = t;
    }
    if (row_start >= ROW) row_start = ROW - 1;
    if (row_end < 0) row_end = 0;

    // ========== 左边界拟合：x_L = aL * y + bL ==========
    float sum_y = 0, sum_x = 0, sum_xy = 0, sum_yy = 0;
    int nL = 0;
    for (int r = row_end; r <= row_start; r++) {
        int x = Line_L[r];
        if (x == 0) continue;  // 跳过无效左边界（假设0表示未找到）
        sum_y  += (float)r;
        sum_x  += (float)x;
        sum_xy += (float)r * x;
        sum_yy += (float)r * r;
        nL++;
    }

    float aL = 0, bL = 0;
    int left_valid = 0;
    if (nL >= 3) {
        float denom = (float)nL * sum_yy - sum_y * sum_y;
        if (fabsf(denom) > 1e-6f) {
            aL = ((float)nL * sum_xy - sum_y * sum_x) / denom;
            bL = (sum_x - aL * sum_y) / (float)nL;
            left_valid = 1;
        }
    }

    // ========== 右边界拟合：x_R = aR * y + bR ==========
    sum_y = 0; sum_x = 0; sum_xy = 0; sum_yy = 0;
    int nR = 0;
    for (int r = row_end; r <= row_start; r++) {
        int x = Line_R[r];
        if (x == COL - 1) continue;  // 跳过无效右边界
        sum_y  += (float)r;
        sum_x  += (float)x;
        sum_xy += (float)r * x;
        sum_yy += (float)r * r;
        nR++;
    }

    float aR = 0, bR = 0;
    int right_valid = 0;
    if (nR >= 3) {
        float denom = (float)nR * sum_yy - sum_y * sum_y;
        if (fabsf(denom) > 1e-6f) {
            aR = ((float)nR * sum_xy - sum_y * sum_x) / denom;
            bR = (sum_x - aR * sum_y) / (float)nR;
            right_valid = 1;
        }
    }

    // ========== 用拟合结果更新中线 ==========
    for (int r = row_end; r <= row_start; r++) {
        int fit_L = left_valid  ? (int)(aL * r + bL + 0.5f) : Line_L[r];
        int fit_R = right_valid ? (int)(aR * r + bR + 0.5f) : Line_R[r];

        // 边界保护
        if (fit_L < 0) fit_L = 0;
        if (fit_L >= COL) fit_L = COL - 1;
        if (fit_R < 0) fit_R = 0;
        if (fit_R >= COL) fit_R = COL - 1;

        Line_L[r] = (uint8)fit_L;
        Line_R[r] = (uint8)fit_R;
        Line_M[r] = (uint8)((fit_L + fit_R) / 2);
    }
}
/**
 * @brief  全局最小二乘拟合中线，强制起点为图像底部中心
 * @param  row_start  起始行（近端，通常为 ROW-1）
 * @param  row_end    结束行（远端，通常为 0）
 * @note   拟合直线 x = a * y + b，强制经过 (ROW-1, COL/2)
 *         在 [row_end, row_start] 范围内更新 Line_M（及 Line_L/R）
 */
void global_line_fit_with_fixed_start(int row_start, int row_end)
{
    // 标准化：确保 row_start > row_end
    if (row_start < row_end) {
        int t = row_start;
        row_start = row_end;
        row_end = t;
    }
    if (row_start >= ROW) row_start = ROW - 1;
    if (row_end < 0) row_end = 0;

    // 固定起点：图像底部中心
    const float y0 = (float)(ROW - 1);
    const float x0 = (float)(COL / 2);

    // ========== 用 Line_M 收集有效点，做带约束的最小二乘 ==========
    // 约束：直线必须经过 (y0, x0)，即 x = a * (y - y0) + x0
    // 只需求解斜率 a

    float sum_xy = 0.0f, sum_yy = 0.0f;
    int n = 0;

    for (int r = row_end; r <= row_start; r++) {
        int x = Line_M[r];
        // 跳过无效点（可根据实际情况调整过滤条件）
        if (x == 0 || x == COL - 1) continue;

        float dy = (float)r - y0;
        float dx = (float)x - x0;

        sum_xy += dy * dx;
        sum_yy += dy * dy;
        n++;
    }

    // 至少需要 3 个有效点（加上固定起点共 4 个自由度）
    if (n < 3) return;

    float a = (fabsf(sum_yy) > 1e-6f) ? (sum_xy / sum_yy) : 0.0f;

    // ========== 用拟合结果更新中线 ==========
    for (int r = row_end; r <= row_start; r++) {
        int fit_x = (int)(a * ((float)r - y0) + x0 + 0.5f);

        // 边界保护
        if (fit_x < 0)   fit_x = 0;
        if (fit_x >= COL) fit_x = COL - 1;

        Line_L[r] = (uint8)fit_x;
        Line_R[r] = (uint8)fit_x;
        Line_M[r] = (uint8)fit_x;
    }
}
/**
 * @brief  全局最小二乘拟合 + 混合覆盖（平滑覆盖，跳变钳位）
 * @param  row_start   起始行（近端，通常为 ROW-1）
 * @param  row_end     结束行（远端，通常为 0）
 * @param  max_delta   允许的最大偏差（像素），超过此值做钳位而非覆盖
 * @note   强制拟合直线经过 (ROW-1, COL/2)
 *         有效点（非0且非COL-1）参与拟合
 *         拟合后用混合策略更新 Line_L/R/M
 */
void global_line_fit_mixed(int row_start, int row_end, float max_delta)
{
    // 标准化：确保 row_start > row_end
    if (row_start < row_end) {
        int t = row_start;
        row_start = row_end;
        row_end = t;
    }
    if (row_start >= ROW) row_start = ROW - 1;
    if (row_end < 0) row_end = 0;

    // 固定起点：图像底部中心
    const float y0 = (float)(ROW - 1);
    const float x0 = (float)(COL / 2);

    // ========== 最小二乘求斜率 a ==========
    float sum_xy = 0.0f, sum_yy = 0.0f;
    int n = 0;

    for (int r = row_end; r <= row_start; r++) {
        int x = Line_M[r];
        // 跳过无效点
        if (x == 0 || x == COL - 1) continue;

        float dy = (float)r - y0;
        float dx = (float)x - x0;

        sum_xy += dy * dx;
        sum_yy += dy * dy;
        n++;
    }

    // 至少需要 3 个有效点
    if (n < 3) return;

    float a = (fabsf(sum_yy) > 1e-6f) ? (sum_xy / sum_yy) : 0.0f;

    // ========== 混合策略更新中线 ==========
    for (int r = row_end; r <= row_start; r++) {
        int fit_x = (int)(a * ((float)r - y0) + x0 + 0.5f);

        // 边界保护
        if (fit_x < 0)   fit_x = 0;
        if (fit_x >= COL) fit_x = COL - 1;

        int orig_x = Line_M[r];

        // 跳过无效点
        if (orig_x == 0 || orig_x == COL - 1) continue;

        float delta = (float)(orig_x - fit_x);

        int new_x;
        if (fabsf(delta) <= max_delta) {
            // 偏差小 → 用拟合值直接覆盖
            new_x = fit_x;
        } else {
            // 偏差大 → 向拟合方向拉回 max_delta 个像素
            if (delta > 0) {
                new_x = orig_x - (int)max_delta;
                if (new_x < fit_x) new_x = fit_x;
            } else {
                new_x = orig_x + (int)max_delta;
                if (new_x > fit_x) new_x = fit_x;
            }
        }

        // 边界保护
        if (new_x < 0)   new_x = 0;
        if (new_x >= COL) new_x = COL - 1;

        Line_L[r] = (uint8)new_x;
        Line_R[r] = (uint8)new_x;
        Line_M[r] = (uint8)new_x;
    }

    // 强制保留底部中心点（起点约束）
    Line_L[ROW-1] = (uint8)x0;
    Line_R[ROW-1] = (uint8)x0;
    Line_M[ROW-1] = (uint8)x0;
}
/**
 * @brief  纯最小二乘中线拟合（无起点约束）
 * @param  row_start   起始行（近端，行号大）
 * @param  row_end     结束行（远端，行号小）
 * @param  max_delta   跳变阈值（像素），用于混合策略
 * @param  mode        0 = 全部用拟合值覆盖，1 = 混合策略（跳变钳位）
 * @note   对 Line_M 中有效的点（非0且非COL-1）做最小二乘拟合直线 x = a*y + b
 *         然后根据 mode 更新 Line_L/R/M
 */
void global_line_fit1(int row_start, int row_end, float max_delta, int mode)
{
    // 标准化：确保 row_start > row_end
    if (row_start < row_end) {
        int t = row_start;
        row_start = row_end;
        row_end = t;
    }
    if (row_start >= ROW) row_start = ROW - 1;
    if (row_end < 0) row_end = 0;

    // ========== 最小二乘求斜率 a 和截距 b ==========
    float sum_y = 0.0f, sum_x = 0.0f, sum_xy = 0.0f, sum_yy = 0.0f;
    int n = 0;

    for (int r = row_end; r <= row_start; r++) {
        int x = Line_M[r];
        // 跳过无效点（假设 0 和 COL-1 为未找到边界的标记）
        if (x == 0 || x == COL - 1) continue;

        sum_y  += (float)r;
        sum_x  += (float)x;
        sum_xy += (float)r * (float)x;
        sum_yy += (float)r * (float)r;
        n++;
    }

    // 至少需要 3 个有效点才能拟合
    if (n < 3) return;

    float denom = (float)n * sum_yy - sum_y * sum_y;
    if (fabsf(denom) < 1e-6f) return;

    float a = ((float)n * sum_xy - sum_y * sum_x) / denom;  // 斜率
    float b = (sum_x - a * sum_y) / (float)n;               // 截距

    // ========== 根据 mode 更新中线 ==========
    for (int r = row_end; r <= row_start; r++) {
        // 跳过无效行（不处理）
        if (Line_M[r] == 0 || Line_M[r] == COL - 1) continue;

        int fit_x = (int)(a * (float)r + b + 0.5f);  // 四舍五入
        if (fit_x < 0) fit_x = 0;
        if (fit_x >= COL) fit_x = COL - 1;

        int orig_x = Line_M[r];
        int new_x;

        if (mode == 0) {
            // 模式 0：全部用拟合值覆盖
            new_x = fit_x;
        } else {
            // 模式 1：混合策略
            float delta = (float)(orig_x - fit_x);
            if (fabsf(delta) <= max_delta) {
                new_x = fit_x;
            } else {
                // 向拟合方向拉回 max_delta 像素
                if (delta > 0) {
                    new_x = orig_x - (int)max_delta;
                    if (new_x < fit_x) new_x = fit_x;
                } else {
                    new_x = orig_x + (int)max_delta;
                    if (new_x > fit_x) new_x = fit_x;
                }
            }
        }

        // 边界保护
        if (new_x < 0) new_x = 0;
        if (new_x >= COL) new_x = COL - 1;

        Line_L[r] = (uint8)new_x;
        Line_R[r] = (uint8)new_x;
        Line_M[r] = (uint8)new_x;
    }
}
#define SAMPLE_PAIRS 20  // 采样点对数，可根据有效点总数调整

void global_line_fit_robust(int row_start, int row_end)
{
    // 标准化
    if (row_start < row_end) {
        int t = row_start;
        row_start = row_end;
        row_end = t;
    }
    if (row_start >= ROW) row_start = ROW - 1;
    if (row_end < 0) row_end = 0;

    // 收集有效点
    int valid_rows[ROW];
    int valid_x[ROW];
    int n = 0;
    for (int r = row_end; r <= row_start; r++) {
        int x = Line_M[r];
        if (x != 0 && x != COL - 1) {
            valid_rows[n] = r;
            valid_x[n] = x;
            n++;
        }
    }
    if (n < 3) return;

    // 用中位数估计斜率
    float slopes[SAMPLE_PAIRS];
    int m = 0;
    for (int k = 0; k < SAMPLE_PAIRS && m < SAMPLE_PAIRS; k++) {
        int i = (k * 7) % n;      // 伪随机采样
        int j = (k * 13 + 5) % n;
        if (i != j && valid_rows[i] != valid_rows[j]) {
            float dx = (float)(valid_rows[i] - valid_rows[j]);
            float dy = (float)(valid_x[i] - valid_x[j]);
            slopes[m++] = dy / dx;
        }
    }

    // 排序取中位数
    for (int i = 0; i < m - 1; i++)
        for (int j = i + 1; j < m; j++)
            if (slopes[i] > slopes[j]) {
                float t = slopes[i];
                slopes[i] = slopes[j];
                slopes[j] = t;
            }
    float a = slopes[m / 2];  // 中位数斜率

    // 用中位数斜率 + 所有点的中位数截距来确定直线
    float intercepts[SAMPLE_PAIRS];
    for (int k = 0; k < SAMPLE_PAIRS && k < n; k++) {
        int i = (k * 3) % n;
        intercepts[k] = (float)valid_x[i] - a * (float)valid_rows[i];
    }
    // 排序取中位数截距
    for (int i = 0; i < SAMPLE_PAIRS - 1; i++)
        for (int j = i + 1; j < SAMPLE_PAIRS; j++)
            if (intercepts[i] > intercepts[j]) {
                float t = intercepts[i];
                intercepts[i] = intercepts[j];
                intercepts[j] = t;
            }
    float b = intercepts[SAMPLE_PAIRS / 2];

    // 更新中线
    for (int r = row_end; r <= row_start; r++) {
        if (Line_M[r] == 0 || Line_M[r] == COL - 1) continue;
        int fit_x = (int)(a * (float)r + b + 0.5f);
        if (fit_x < 0) fit_x = 0;
        if (fit_x >= COL) fit_x = COL - 1;
        Line_L[r] = (uint8)fit_x;
        Line_R[r] = (uint8)fit_x;
        Line_M[r] = (uint8)fit_x;
    }
}
/**
 * @brief  鲁棒中线拟合：剔除60~110行内的离群点，拟合直线并更新中线
 * @note   使用中位数绝对偏差(MAD)剔除跳变点，剩余点做最小二乘拟合
 *         专治直道上的元器件干扰导致的局部中线抖动
 */
void robust_fit_midline_60_110(void)
{
    int start_row = 60, end_row = 110;
    int rows[51], vals[51];   // 最多51行
    int n = 0;

    // 1. 收集有效点
    for (int r = start_row; r <= end_row; r++) {
        int x = Line_M[r];
        if (x != 0 && x != COL - 1) {
            rows[n] = r;
            vals[n] = x;
            n++;
        }
    }
    if (n < 5) return;  // 至少5个有效点

    // 2. 计算 x 坐标的中位数
    int sorted[51];
    for (int i = 0; i < n; i++) sorted[i] = vals[i];
    // 冒泡排序（数据量小，足够快）
    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++)
            if (sorted[i] > sorted[j]) {
                int t = sorted[i];
                sorted[i] = sorted[j];
                sorted[j] = t;
            }
    float median = (n % 2) ? (float)sorted[n/2]
                            : (sorted[n/2 - 1] + sorted[n/2]) * 0.5f;

    // 3. 计算 MAD (中位数绝对偏差)
    float abs_dev[51];
    for (int i = 0; i < n; i++) abs_dev[i] = fabsf((float)vals[i] - median);
    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++)
            if (abs_dev[i] > abs_dev[j]) {
                float t = abs_dev[i];
                abs_dev[i] = abs_dev[j];
                abs_dev[j] = t;
            }
    float mad = (n % 2) ? abs_dev[n/2]
                         : (abs_dev[n/2 - 1] + abs_dev[n/2]) * 0.5f;
    if (mad < 1.0f) mad = 1.0f;  // 防止除零

    // 4. 剔除离群点：偏离中位数超过 2.5 * MAD 的点
    float sum_y = 0, sum_x = 0, sum_xy = 0, sum_yy = 0;
    int n_good = 0;
    for (int i = 0; i < n; i++) {
        if (fabsf((float)vals[i] - median) <= 2.5f * mad) {
            int r = rows[i];
            int x = vals[i];
            sum_y  += (float)r;
            sum_x  += (float)x;
            sum_xy += (float)r * x;
            sum_yy += (float)r * r;
            n_good++;
        }
    }
    if (n_good < 3) return;  // 正常点太少，放弃拟合

    // 5. 最小二乘拟合直线 x = a*y + b
    float denom = (float)n_good * sum_yy - sum_y * sum_y;
    if (fabsf(denom) < 1e-6f) return;
    float a = ((float)n_good * sum_xy - sum_y * sum_x) / denom;
    float b = (sum_x - a * sum_y) / (float)n_good;

    // 6. 更新60~110行中线（只更新有效行）
    for (int r = start_row; r <= end_row; r++) {
        if (Line_M[r] == 0 || Line_M[r] == COL - 1) continue;
        int fit_x = (int)(a * (float)r + b + 0.5f);
        if (fit_x < 0) fit_x = 0;
        if (fit_x >= COL) fit_x = COL - 1;
        Line_L[r] = (uint8)fit_x;
        Line_R[r] = (uint8)fit_x;
        Line_M[r] = (uint8)fit_x;
    }
}
