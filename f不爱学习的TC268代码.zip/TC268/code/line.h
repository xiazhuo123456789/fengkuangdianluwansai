
#ifndef CODE_LINE_H_
#define CODE_LINE_H_

#include "zf_common_headfile.h"
extern uint8_t Line_L[MT9V03X_1_H];
extern uint8_t Line_R[MT9V03X_1_H];
extern uint8_t Line_LL[MT9V03X_1_H];
extern uint8_t Line_RR[MT9V03X_1_H];
extern uint8_t Line_M[MT9V03X_1_H];
extern uint8_t Line_MM[MT9V03X_1_H];
extern uint8_t Line_MMM[MT9V03X_1_H];
//����
void find_lrm_line(uint8 (*src_image)[COL]);
void find_lrm_line_ceshi(uint8 (*src_image)[COL]);


/********************************************************************************************/
void find_lrm_lineMM(uint8 (*src_image)[COL]);
void find_lrm_line1(void);
void find_lrm_line2(void);
void line_offset(uint8 x1, uint8 y1, uint8 x2, uint8 y2);
void line_2_left(uint8 (*bin_image)[COL]);
void line_2_right(uint8 (*bin_image)[COL]);
void fit_mid_line_least_square(void);
void Weighted_Line_Fit(uint8_t *Line_M, uint8_t *Line_MM, uint8_t *Line_MMM, int len);
int LineM_average(int start , int end);
int scan_vertical_line(int start, int end, int col, uint8 (*src_image)[COL]);
void local_line_offset(int corner_row);
void local_line_fit(int corner_row, int radius);

void global_line_fit_with_fixed_start(int row_start, int row_end);
void global_line_fit_mixed(int row_start, int row_end, float max_delta);
void global_line_fit1(int row_start, int row_end, float max_delta, int mode);
void global_line_fit_robust(int row_start, int row_end);
void robust_fit_midline_60_110(void);
#endif
