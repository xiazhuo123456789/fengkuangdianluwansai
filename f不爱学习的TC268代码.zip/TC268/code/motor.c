/*
 * motor.c
 *
 *  Created on: 2025��11��15��
 *      Author: zheng
 */

#include "motor.h"

int pwm_l,pwm_r;

void motor_proc(int duty1, int duty2)
{
    duty1 = - duty1;
    duty2 = - duty2;
    if (duty1 > MOTOR_DUTY_LIMIT)
        duty1 = MOTOR_DUTY_LIMIT;
    else if (duty1 < -MOTOR_DUTY_LIMIT)
        duty1 = -MOTOR_DUTY_LIMIT;

    if (duty2 > MOTOR_DUTY_LIMIT)
        duty2 = MOTOR_DUTY_LIMIT;
    else if (duty2 < -MOTOR_DUTY_LIMIT)
        duty2 = -MOTOR_DUTY_LIMIT;

    if (duty1 >= 0)
    {
        gpio_set_level(MOTOR_DIR_L, GPIO_HIGH);
        pwm_set_duty(MOTOR_PWM_L, duty1);
    }
    else
    {
        gpio_set_level(MOTOR_DIR_L, GPIO_LOW);
        pwm_set_duty(MOTOR_PWM_L, (-duty1));
    }

    if (duty2 >= 0)
    {
        gpio_set_level(MOTOR_DIR_R, GPIO_HIGH);
        pwm_set_duty(MOTOR_PWM_R, duty2);
    }
    else
    {
        gpio_set_level(MOTOR_DIR_R, GPIO_LOW);
        pwm_set_duty(MOTOR_PWM_R, (-duty2));
    }

    pwm_l = duty1;
    pwm_r = duty2;
}

void set_fuya_pwm(int fuya)
{
    if (fuya >= 0)
    {
        pwm_set_duty(FUYA_PWM, fuya);
    }
    else
    {
        pwm_set_duty(FUYA_PWM, (-fuya));
    }
}
