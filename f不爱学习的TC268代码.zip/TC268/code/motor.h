#ifndef CODE_MOTOR_H_
#define CODE_MOTOR_H_

#include "zf_common_headfile.h"

#define MOTOR_DUTY_LIMIT    6500

void motor_proc(int duty1, int duty2);
void set_fuya_pwm(int fuya);

#endif /* CODE_MOTOR_H_ */

