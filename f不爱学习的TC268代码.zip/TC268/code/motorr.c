#include "motorr.h"

void motorr_proc(float dutyl, float dutyr)
{
    dutyr = -dutyr;
    limitt((float)dutyl, -(float)MOTOR_DUTY_MAX, (float)MOTOR_DUTY_MAX);
    limitt((float)dutyr, -(float)MOTOR_DUTY_MAX, (float)MOTOR_DUTY_MAX);
    if (dutyl >= 0)
        {
            gpio_set_level(MOTOR_DIR_L, GPIO_HIGH);
            pwm_set_duty(MOTOR_PWM_L, dutyl);
        }
    else
        {
            gpio_set_level(MOTOR_DIR_L, GPIO_LOW);
            pwm_set_duty(MOTOR_PWM_L, (-dutyl));
        }

    if (dutyr >= 0)
        {
            gpio_set_level(MOTOR_DIR_R, GPIO_LOW);
            pwm_set_duty(MOTOR_PWM_R, dutyr);
        }
    else
        {
            gpio_set_level(MOTOR_DIR_R, GPIO_HIGH);
            pwm_set_duty(MOTOR_PWM_R, (-dutyr));
        }
}
void fuyaa_proc(int fuya)
{
    pwm_set_duty((ATOM0_CH0_P21_2), fuya);
}
