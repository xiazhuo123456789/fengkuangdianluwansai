#ifndef CODE_MOTORR_H_
#define CODE_MOTORR_H_

#include "zf_common_headfile.h"
#define MOTOR_DUTY_MAX   6500

void motorr_proc(float dutyl, float dutyr);
void fuyaa_proc(int fuya);

#endif /* CODE_MOTOR_H_ */
