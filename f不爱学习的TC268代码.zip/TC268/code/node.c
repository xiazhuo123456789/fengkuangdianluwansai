#include "node.h"
#include "IfxCpu_Irq.h"
#include "controll.h"
#define Straight_Lock_Distance 25.0f
static int Node_State = Normal;
static int node_cnt = 0;
static int Turn_Dir = TurnNone;
static float Go_start;
static float YAW_target_angle;
static int point_flag;

static uint8_t point;
static float distance_cm = 0;
static float distance_cm_go = 0;
static int r_encoder;
static int l_encoder;


//********R������****
    //��һ�μ�⵽�յ㣬��һ�¹յ���
    static int PointL_first = 0;
    static int PointR_first = 0;



    //***************************MAP********************
//ʡ��yusai1111
static int Map[] = {Right,Right,Left,Go,Left,Go,Left,Go,Right,Right,Right,Right,Left,Left,Right,Go,Go,Right,Right,Right,Right,Right,Go,Go,Go,Right,Right,Right};
//{Go,Go,Go,Go,Go,Right,Go,Go,Go,Right,Go,Go,Go,Go,Go,Right};
    //yuRight,Left,Go,Left,Go,Left,Left,Left,Left,Left,Go,Right,Right,Right,Go,Go,Go,Right,Go,Go,Go,Right
//static int Map[] = {Go,Go,Right,Go,Go,Go,Go,Right,Go,Go,Go,Right};
//ʡ��yusai
//static int Map[] = {Right,Left,Go,Left,Go,Left,Left,Left,Left,Left,Go,Right,Right,Right,Go,Go,Go,Right,Go,Go,Go,Right};
//ʡ��������ͼ���Լ�д��
//static int Map[] = {Right,Right,Left,Go,Left,Go,Left,Left,Left,Left,Left,Go,Right,Right,Go,Go,Right,Right,Right,Right,Go,Right,Go,Right,Go,Right,Left,Left,Left,Left,Right,Right,Go,Right,Go,Go,Right,Right,Right,Right,Go,Go,Go,Right};
//ʡ��������ͼAI���Ž�
//static int Map[] = {Left,Go,Go,Go,Go,Go,Left,Go,Go,Left,Go,Left,Right,Go,Right,Right,Left,Left,Left,Left,Go,Left,Right,Go,Right,Right,Left,Go,Left,Right,Right,Go,Left,Left,Left,Go,Left,Go,Right,Left,Left};
    //***************************MAP********************
static int len = sizeof(Map) / sizeof(Map[0]);
//*************�л�mode
void R_mode(void)
{
    boolean int_state = IfxCpu_disableInterrupts();
    PID_Location_flag = 0;
    PID_R_flag = 1;
    IfxCpu_restoreInterrupts(int_state);
}

void Location_mode(void)
{
    boolean int_state = IfxCpu_disableInterrupts();
    PID_Location_flag = 1;
    PID_R_flag = 0;

    IfxCpu_restoreInterrupts(int_state);
}
void Node_State_Machine_RL_ceshi(uint8 (*bin_image)[COL])
{
    switch(Node_State)
    {
        case Normal:
        {
            debug_data_ready = 1;
            Debug_Data_5 = 0.0f;
            Debug_Data_4 = 0.0f;
            Location_mode();
            Turn_Speed_rad = 0;
            if(node_cnt >= len)
                break;

            GetBoundaryLink_LR_Point_beiyong(ROW-5, 40);

            if(point_lx != 0 || point_rx != 0)
            {
                boolean int_state = IfxCpu_disableInterrupts();
                PointL_first = point_lx;
                PointR_first = point_rx;
                IfxCpu_restoreInterrupts(int_state);

                Turn_Dir = Map[node_cnt];
                node_cnt++;

                if(Turn_Dir == Go)
                {
                    Location_mode();
                    Go_start = All_distance_cm;
                    int row;
                    if(PointL_first != 0)
                     row = PointL_first;
                    else
                     row = PointR_first;

                    distance_cm_go = Calc_distance_from_row(row);
                }
                else if(Turn_Dir == Left || Turn_Dir == Right)
                {
                    R_mode();
                    YAW_target_angle = Yaw_angle + ((Turn_Dir == Left) ? -65.0f : 65.0f);

                    float speed_cm = (float)Speed_Base_cm;
                    uint8_t row = (Turn_Dir == Left) ? PointL_first : PointR_first;

                    // �� ��������㵱ǰ�յ�ľ���
                    distance_cm = Calc_distance_from_row(row);

                    boolean int_state = IfxCpu_disableInterrupts();
                    Turn_Speed_rad = Get_Target_Turn_Speed(row, speed_cm, Turn_Dir, fabs(distance_cm));
                    IfxCpu_restoreInterrupts(int_state);
                }

                Node_State = Executing_decision;
            }
            break;
        }

        case Executing_decision:
        {
            //debug_data_ready = 1;

            GetBoundaryLink_LR_Point_beiyong(ROW-5, 40);
            if(Turn_Dir == Go)
            {

                point_flag = (point_lx != 0 || point_rx != 0) ? 1 : 0;

                float Go_delta_cm = All_distance_cm - Go_start;


                if( Go_delta_cm <= distance_cm_go +3 )
                {
                    if(point_flag == 1)
                    {
                        point = (point_lx >= point_rx) ? point_lx : point_rx;
                        //robust_fit_midline_60_110();
                        global_line_fit_robust(ROW - 1, 0);
                    }
                    else
                    {

                        //robust_fit_midline_60_110();
                        global_line_fit_robust(ROW - 1, 0);
                    }
                }
                else
                {
                    Go_start = 0;
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                }
            }
            else if(Turn_Dir == Left)
            {
                if(Yaw_angle <= YAW_target_angle)
                {
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                    Location_mode();
                    Turn_Speed_rad = 0;
                }
                else
                {
                    // �ӵڶ���״̬���ϲ��Ĳ����߼�
                    line_2_left1(bin_image);
                }
            }
            else if(Turn_Dir == Right)
            {
                if(Yaw_angle >= YAW_target_angle)
                {
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                    Location_mode();
                    Turn_Speed_rad = 0;
                }
                else
                {
                    // �ӵڶ���״̬���ϲ��Ĳ����߼�
                    line_2_right1(bin_image);
                }
            }
            break;
        }
    }
}
void Node_State_Machine_RL_ceshi1(uint8 (*bin_image)[COL])
{
    switch(Node_State)
    {
        case Normal:
        {
            debug_data_ready = 1;
            Debug_Data_5 = 0.0f;
            Debug_Data_4 = 0.0f;
            Location_mode();
            Turn_Speed_rad = 0;
            if(node_cnt >= len)
                break;

            GetBoundaryLink_LR_Point_beiyong(ROW, 45);

            if(point_lx != 0 || point_rx != 0)
            {
                boolean int_state = IfxCpu_disableInterrupts();
                PointL_first = point_lx;
                PointR_first = point_rx;
                IfxCpu_restoreInterrupts(int_state);

                Turn_Dir = Map[node_cnt];
                node_cnt++;

                if(Turn_Dir == Go)
                {
                    Location_mode();
                    Go_start = All_distance_cm;
                    int row;
                    if(PointL_first != 0)
                     row = PointL_first;
                    else
                     row = PointR_first;

                    distance_cm = Calc_distance_from_row(row);
                }
                else if(Turn_Dir == Left || Turn_Dir == Right)
                {
                    R_mode();
                    //YAW_target_angle = Yaw_angle + ((Turn_Dir == Left) ? -90.0f : 90.0f);
                    if(Turn_Dir == Left)
                    {
                        YAW_target_angle = L_distance_cm +8;

                    }
                    else if(Turn_Dir == Right)
                    {
                        YAW_target_angle = R_distance_cm +8;

                    }

                    float speed_cm = (float)Speed_Base_cm;
                    uint8_t row = (Turn_Dir == Left) ? PointL_first : PointR_first;

                    boolean int_state = IfxCpu_disableInterrupts();

                    Turn_Speed_rad = Get_Target_Turn_Speed(row, speed_cm, Turn_Dir,fabs(distance_cm));
                    IfxCpu_restoreInterrupts(int_state);
                }

                Node_State = Executing_decision;
            }
            break;
        }

        case Executing_decision:
        {
            //debug_data_ready = 1;

            GetBoundaryLink_LR_Point_beiyong(ROW-5, 25);
            if(Turn_Dir == Go)
            {

                point_flag = (point_lx != 0 || point_rx != 0) ? 1 : 0;

                float Go_delta_cm = All_distance_cm - Go_start;


                if(Go_delta_cm <= distance_cm+3)
                {
                    if(point_flag == 1)
                    {
                        point = (point_lx >= point_rx) ? point_lx : point_rx;
                        global_line_fit1(ROW - 1, 0, 8.0f, 0);
                    }
                    else
                    {
                        global_line_fit1(ROW - 1, 0, 8.0f, 0);
                    }
                }
                else
                {
                    Go_start = 0;
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                }
            }
            else if(Turn_Dir == Left)
            {
                if(L_distance_cm <= YAW_target_angle)
                {
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                    Location_mode();
                    Turn_Speed_rad = 0;
                }
                else
                {
                    // �ӵڶ���״̬���ϲ��Ĳ����߼�
                    line_2_left1(bin_image);
                }
            }
            else if(Turn_Dir == Right)
            {
                if(R_distance_cm >= YAW_target_angle)
                {
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                    Location_mode();
                    Turn_Speed_rad = 0;
                }
                else
                {
                    // �ӵڶ���״̬���ϲ��Ĳ����߼�
                    line_2_right1(bin_image);
                }
            }
            break;
        }
    }
}
//********************************************R��״̬��**************************************************//

//˼·��������flag:PID_Location_flag��PID_R_flag
//С������ѭ����ʱ����ֱ�ߣ�����PID_Location_flag
//С����⵽�յ��ʱ��(��ֱ��)��PID_R_flag

//xxx ����Ŀǰ����������״̬���ܻ���10ms�ӳ٣�100fps�µ��³�����1~4cm���ٽ��н��ٶȵ��أ�
    //����취����һ����͸��Ҳ�����Ǳ�ģ�����Normal��һ֡�ڵ���Executing_decision������Executing_decision���ٵ���Normal
void Node_State_Machine_R(uint8 (*bin_image)[COL])//�Ա�֡ͼ����нڵ���ߣ�ͼ��Ϊ��ֵ����ͼ��
{
    switch(Node_State)//֮ǰ���Ĵ���switch��case�����ñ�����
    {
        case Normal:
        {
            Location_mode();//Normal״ֻ̬��Ѱ�ҹյ㻹û�ҵ��յ㣬��L��
            Turn_Speed_rad = 0;
           if(node_cnt >= len)
           {
               break;
           }

           //Ѱ�ҹյ�
           GetBoundaryLink_LR_Point(100 , 25);

           //����ҵ�һ���յ�
           if(point_lx != 0 || point_rx != 0)
           {
               Node_State = Decision;
               Turn_Dir = Map[node_cnt];
               node_cnt++;
               //�л�R��


               boolean interrupt_state = IfxCpu_disableInterrupts();  // ��ȫ���жϣ����عر�ǰ���ж�״̬
               PointL_first = point_lx;//pointlx rx ��ȫ�ֱ�����GetBoundaryLink_LR_Point�Ĺյ�����
               PointR_first = point_rx;
               IfxCpu_restoreInterrupts(interrupt_state);              // �ָ��ж�

           }


           break;


        }
        case Decision:
        {

            if(Turn_Dir == Go)
            {
                //Yaw_Target = Yaw_All;
               Location_mode();
               Go_start = All_distance_cm;
            }
            if(Turn_Dir == Left)
            {
                //�л�R��
                R_mode();
                YAW_target_angle = Yaw_angle - 85.0f;
            }
            if(Turn_Dir == Right)
            {
                //�л�R��
                R_mode();
                YAW_target_angle = Yaw_angle + 85.0f;
            }
            Node_State = Executing_decision;
            break;
        }

        case Executing_decision:
        {
            //������ߵĻ������ҹյ㣬Ϊgo��׼����������right��left
            GetBoundaryLink_LR_Point_beiyong(ROW-5 , 40);

            point_flag = 0;
            point_flag = (point_lx != 0 || point_rx != 0) ? 1 : 0;

            if(Turn_Dir == Go)
            {
              float Go_delta_cm = All_distance_cm - Go_start;

              if(Go_delta_cm <= Straight_Lock_Distance)
              {

                if(point_flag == 1)
                {
                    point = (point_lx >= point_rx) ? point_lx : point_rx;

                    line_offset(COL / 2, point, COL / 2, 0);
                }
                else
                {
                    line_offset(COL / 2, ROW - 1, COL / 2, 0);
                }
              }

              else
               {
                  Go_start = 0;
                  Node_State =Normal;
                  Turn_Dir = TurnNone;

               }
            }
            if(Turn_Dir == Left)
            {
              //ת��ʱ�����˳�����
              if(Yaw_angle <= YAW_target_angle)
               {
                 Node_State =Normal;
                 Turn_Dir = TurnNone;

               }
               else
               {    R_mode();
                   boolean interrupt_state = IfxCpu_disableInterrupts();  // ��ȫ���жϣ����عر�ǰ���ж�״̬
                   Turn_Speed_rad = Get_Target_Turn_Speed(PointL_first, (float)Speed_Base_cm , Left,13);
                   IfxCpu_restoreInterrupts(interrupt_state);              // �ָ��ж�
               }

            }
            if(Turn_Dir == Right)
            {
              if(Yaw_angle >= YAW_target_angle)
              {
               Node_State =Normal;
               Turn_Dir = TurnNone;

              }
              else
              {   R_mode();
                  boolean interrupt_state = IfxCpu_disableInterrupts();  // ��ȫ���жϣ����عر�ǰ���ж�״̬
                  Turn_Speed_rad = Get_Target_Turn_Speed(PointR_first, (float)Speed_Base_cm , Right,13);
                  IfxCpu_restoreInterrupts(interrupt_state);              // �ָ��ж�
              }

            }
            break;
        }

    }
}
/****************************************����͸���״̬����������**********************************************/
void Node_State_Machine_R_ceshi(uint8 (*bin_image)[COL])
{


    switch(Node_State)
    {

        case Normal:
        {
            Location_mode();
            Turn_Speed_rad = 0;
            if(node_cnt >= len)
                break;

            GetBoundaryLink_LR_Point_beiyong(117 , 62);

            if(point_lx != 0 || point_rx != 0)
            {
                boolean int_state = IfxCpu_disableInterrupts();
                PointL_first = point_lx;
                PointR_first = point_rx;
                IfxCpu_restoreInterrupts(int_state);

                Turn_Dir = Map[node_cnt];
                node_cnt++;

                if(Turn_Dir == Go)
                {
                    Location_mode();
                    Go_start = All_distance_cm;
                }
                else if(Turn_Dir == Left || Turn_Dir == Right)
                {
                    R_mode();
                    YAW_target_angle = Yaw_angle + ((Turn_Dir == Left) ? -85.0f : 85.0f);

                    float speed_cm = (float)Speed_Base_cm;
                    uint8_t row = (Turn_Dir == Left) ? PointL_first : PointR_first;


                    boolean int_state = IfxCpu_disableInterrupts();
                    distance_cm = Calc_distance_from_row(row);
                    Turn_Speed_rad = Get_Target_Turn_Speed(row, speed_cm, Turn_Dir,13);
                    IfxCpu_restoreInterrupts(int_state);

                }

                Node_State = Executing_decision;
            }
            break;
        }

        case Executing_decision:
        {
            if(Turn_Dir == Go)
            {
                GetBoundaryLink_LR_Point_beiyong(117 , 62);
                point_flag = (point_lx != 0 || point_rx != 0) ? 1 : 0;

                float Go_delta_cm = All_distance_cm - Go_start;
                if(Go_delta_cm <= distance_cm+11)
                {
                    if(point_flag == 1)
                    {
                        point = (point_lx >= point_rx) ? point_lx : point_rx;
                        line_offset(COL / 2, point-5 ,COL / 2 , point+5);
                    }
                    else
                    {
                        line_offset(COL / 2, ROW - 1, COL / 2, 0);
                    }
                }
                else
                {
                    Go_start = 0;
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                }
            }
            else if(Turn_Dir == Left)
            {
                if(Yaw_angle <= YAW_target_angle)
                {
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                    Location_mode();
                    Turn_Speed_rad = 0;
                }
            }
            else if(Turn_Dir == Right)
            {
                if(Yaw_angle >= YAW_target_angle)
                {
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                    Location_mode();
                    Turn_Speed_rad = 0;
                }
            }
            break;
        }
    }
}
void Node_State_Machine_L(uint8 (*bin_image)[COL])
{
    switch(Node_State)
    {
        case Normal:
        {
            // ����Ƿ���δ������·��Ԫ��
            if(node_cnt >= len)
                break;

            // Ѱ�ҹյ�
            GetBoundaryLink_LR_Point_beiyong(ROW - 5, 35);

            // ����ҵ��յ㣬�����ڵ�ǰ֡����
            if(point_lx != 0 || point_rx != 0)
            {
                Turn_Dir = Map[node_cnt];
                node_cnt++;

                // ===== ����ִ��ԭ Decision ״̬���߼� =====
                if(Turn_Dir == Go)
                {
                    // ֱ�У���¼��㣬�����߼����� Executing_decision ��ִ��
                    Go_start = All_distance_cm;
                }
                else if(Turn_Dir == Left)
                {
                    // ��ת������Ŀ��Ƕ�
                    YAW_target_angle = Yaw_angle - 89.0f;
                }
                else if(Turn_Dir == Right)
                {
                    // ��ת������Ŀ��Ƕ�
                    YAW_target_angle = Yaw_angle + 89.0f;
                }
                // ===========================================

                // ֱ�ӽ���ִ��״̬������ Decision
                Node_State = Executing_decision;
            }
            break;
        }

        case Executing_decision:
        {
            GetBoundaryLink_LR_Point_beiyong(ROW - 5, 35);
            point_flag = (point_lx != 0 || point_rx != 0) ? 1 : 0;

            if(Turn_Dir == Go)
            {
                float Go_delta_cm = All_distance_cm - Go_start;
                if(Go_delta_cm <= 25)
                {
                    if(point_flag == 1)
                    {
                        point = (point_lx >= point_rx) ? point_lx : point_rx;
                        line_offset(COL / 2, point - 5, COL / 2, point + 5);
                    }
                    else
                    {
                        line_offset(COL / 2, ROW - 1, COL / 2, 0);
                    }
                }
                else
                {
                    Go_start = 0;
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                }
            }
            else if(Turn_Dir == Left)
            {
                if(Yaw_angle <= YAW_target_angle)
                {
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                }
                else
                {
                    line_2_left1(bin_image);
                }
            }
            else if(Turn_Dir == Right)
            {
                if(Yaw_angle >= YAW_target_angle)
                {
                    Node_State = Normal;
                    Turn_Dir = TurnNone;
                }
                else
                {
                    line_2_right1(bin_image);
                }
            }
            break;
        }
    }
}


/*************************��ѡ*************************/
/*
void Node_State_Machine1(uint8 (*bin_image)[COL])//�Ա�֡ͼ����нڵ���ߣ�ͼ��Ϊ��ֵ����ͼ��
{
    switch(Node_State)//֮ǰ���Ĵ���switch��case�����ñ�����
    {
        case Normal:
        {
            basepwm = norpwm;
           int len = sizeof(Map) / sizeof(Map[0]);
           if(node_cnt >= len)
           {
               break;
           }
           find_xpoint(ROW -5 , 20); //ROW��0~120����Ѱ��Χ��ROW-5��20���൱��ǰ2/3������20�����൱�ڵ�������point��ʱ��
                                    //Ѱ�ҵ�point������LineLR,����LineLRҲ����Ա�binͼ��ģ����������findpointҲ�������һ֡��
           if(point_lx != 0 || point_rx != 0)
           {
               Node_State = Decision;
               Turn_Dir = Map[node_cnt];
               node_cnt++;
           }
           else
           {

           }
           find_updown_point(60,125);

           if(point_upy && point_dy && (fabs(Img_Err) <= 2.0) && ((Node_State == Go) || (point_lx == 0 && point_rx == 0)))
           {
               int uppoint = LineM_average(5,30);
               int downpoint = LineM_average(ROW-3,ROW-20);
               line_offset(uppoint, 0, downpoint, ROW-2);

               basepwm = fastpwm;
               kp1 = kpp;
               gkd = gkdd;


           }
           else
           {
               basepwm = norpwm;
               kp1 = kpp;
               gkd = gkdd;
           }
           break;


        }
        case Decision:
        {

            if(Turn_Dir == Go)
            {
                //Yaw_Target = Yaw_All;

               Go_start = all_juli;
            }
            else if(Turn_Dir == Left)
            {
                YAW_Target = Yaw_angle - 75.0f;
            }
            else if(Turn_Dir == Right)
            {
                YAW_Target = Yaw_angle + 75.0f;
            }
            Node_State = Executing_decision;
            break;
        }

        case Executing_decision:
        {
            kp1 = kpp;
            find_xpoint(ROW - 2 , 35);
            find_updown_point(70,115);
            point_flag = 0;
            point_flag = (point_lx != 0 || point_rx != 0) ? 1 : 0;

            if(Turn_Dir == Go)
            {
              float Go_delta = all_juli - Go_start;

              if(Go_delta <= 0.20f)
              {

                if(point_flag == 1)
                {
                    point = (point_lx >= point_rx) ? point_lx : point_rx;
                    if(point_upy && point_dy)
                    {
                        int uppoint = LineM_average(5,30);
                        int downpoint = LineM_average(ROW-3,ROW-20);
                        line_offset(uppoint, 0, downpoint, ROW-2);

                    }
                    else
                    {
                        line_offset(COL / 2, point, COL / 2, 0);
                    }
                    line_offset(COL / 2, point, COL / 2, 0);
                }
                else
                {

                    if(point_upy && point_dy)
                    {
                      int uppoint = LineM_average(5,25);
                      int downpoint = LineM_average(ROW-3,ROW-20);
                      line_offset(uppoint, 0, downpoint, ROW-2);
                    }
                    else
                    line_offset(COL / 2, ROW - 1, COL / 2, 0);
                }
              }

              else
               {

                  Node_State =Normal;
                  Turn_Dir = TurnNone;

               }
            }
            else if(Turn_Dir == Left)
            {
                kp1 = kpp*1.3;
                gkd = gkdd*1.5;
              if(Yaw_angle <= YAW_Target)
               {
                 Node_State =Normal;
                 Turn_Dir = TurnNone;
               }
               else
               {
                  line_2_left(bin_image);
               }

            }
            else if(Turn_Dir == Right)
            {
                kp1 = kpp*1.3;
                gkd = gkdd*1.5;
              if(Yaw_angle >= YAW_Target)
              {
               Node_State =Normal;
               Turn_Dir = TurnNone;
              }
              else
              {
                  line_2_right(bin_image);
              }

            }
            break;
        }

    }
}
*/
/*
void Node_State_Machine(uint8 (*bin_image)[COL])//�Ա�֡ͼ����нڵ���ߣ�ͼ��Ϊ��ֵ����ͼ��
{
    switch(Node_State)//֮ǰ���Ĵ���switch��case�����ñ�����
    {
        case Normal:
        {

           if(node_cnt >= len)
           {
               break;
           }
           find_point(ROW - 3 , 35); //ROW��0~120����Ѱ��Χ��ROW-5��20���൱��ǰ2/3������20�����൱�ڵ�������point��ʱ��
                                    //Ѱ�ҵ�point������LineLR,����LineLRҲ����Ա�binͼ��ģ����������findpointҲ�������һ֡��
           if(point_l != 0 || point_r != 0)
           {
               Node_State = Decision;
               Turn_Dir = Map[node_cnt];
               node_cnt++;
           }

           break;


        }
        case Decision:
        {

            if(Turn_Dir == Go)
            {
                //Yaw_Target = Yaw_All;

               Go_start = all_juli;
            }
            if(Turn_Dir == Left)
            {
                YAW_Target = YAWW - 75.0f;
            }
            if(Turn_Dir == Right)
            {
                YAW_Target = YAWW + 75.0f;
            }
            Node_State = Executing_decision;
            break;
        }

        case Executing_decision:
        {
            find_point(ROW - 5 , 35);
            point_flag = 0;
            point_flag = (point_l != 0 || point_r != 0) ? 1 : 0;

            if(Turn_Dir == Go)
            {
              float Go_delta = all_juli - Go_start;

              if(Go_delta <= 0.18f)
              {

                if(point_flag == 1)
                {
                    point = (point_l >= point_r) ? point_l : point_r;

                    line_offset(COL / 2, point, COL / 2, 0);
                }
                else
                {
                    line_offset(COL / 2, ROW - 1, COL / 2, 0);
                }
              }

              else
               {
                  Go_start = 0;
                  Node_State =Normal;
                  Turn_Dir = TurnNone;

               }
            }
            if(Turn_Dir == Left)
            {
              if(YAWW <= YAW_Target)
               {
                 Node_State =Normal;
                 Turn_Dir = TurnNone;
               }
               else
               {
                  line_2_left(bin_image);
               }

            }
            if(Turn_Dir == Right)
            {
              if(YAWW >= YAW_Target)
              {
               Node_State =Normal;
               Turn_Dir = TurnNone;
              }
              else
              {
                  line_2_right(bin_image);
              }

            }
            break;
        }

    }
}
*/
