#ifndef CODE_NODE_H_
#define CODE_NODE_H_
#include "zf_common_headfile.h"


//����״̬
#define Normal 1
#define Decision 2
#define Executing_decision 3
//ת��״̬
#define Go 1
#define Left 2
#define Right 3
#define TurnNone 0



void Node_State_Machine(uint8 (*bin_image)[COL]);
void Node_State_Machine1(uint8 (*bin_image)[COL]);


void Node_State_Machine_L(uint8 (*bin_image)[COL]);

void Node_State_Machine_R(uint8 (*bin_image)[COL]);
void Node_State_Machine_R_ceshi(uint8 (*bin_image)[COL]);
void Node_State_Machine_RL_ceshi(uint8 (*bin_image)[COL]);
void Node_State_Machine_RL_ceshi1(uint8 (*bin_image)[COL]);
void R_mode(void);
void Location_mode(void);
#endif
