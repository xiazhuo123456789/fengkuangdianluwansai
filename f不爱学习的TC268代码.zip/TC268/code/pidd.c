#include "pidd.h"
#include "math.h"
PIDS PIDSL; //extern��.h��ӣ�Ȼ��ԭ����PIDSL��Ҫ��.c����
PIDS PIDSR;
PIDT PIDTurn;
float errInt;
void pid_canshu_init(void)
{
    /********����*********/
    PIDTurn.kp = 50;
    PIDTurn.kp2 = 0.2;
    PIDTurn.ki = 0;
    PIDTurn.gkd = 30;
    PIDTurn.errInt =0;
    /********************/
    PIDSL.kp = 5;
    PIDSL.ki = 0.3;
    PIDSL.kd = 0;

    PIDSR.kp = 3;
    PIDSR.ki = 0.15;
    PIDSL.kd = 0;
}

float PidT_Proc(float error , float gyroz, PIDT*pid)
{
    float pidout;

    if(fabs(error) <= 2.0)
    {
        errInt += error;
        if(errInt > 150) errInt = 150;
        if(errInt < -150) errInt = -150;
    }
    else
    {
        errInt = 0;
    }
    pidout = (error * pid->kp) +
            (errInt * pid->ki)+
            (fabs(error) * error * pid->kp2) -
            (gyroz * pid->gkd) / 100;


    return pidout;
}
float Pid_Speed_Proc(float Target , float Actual, PIDS*pid)
{
    //error
    pid->error =(float)(Target - Actual);
    pid->error_int += pid->error;
    pid->error_dt = pid->error - pid->last_error;
    //out
    pid->output = pid->kp * pid->error +
                  pid->ki * pid->error_int +
                  pid->kd * pid->error_dt;
    //lasterror
    pid->last_error = pid->error;

    //limit
    pid->output = limitt(pid->output, duty_min, duty_max);

    return pid->output;
}
