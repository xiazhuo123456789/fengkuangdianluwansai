#ifndef CODE_PIDD_H_
#define CODE_PIDD_H_

#include "zf_common_headfile.h"
#define duty_max         3000
#define duty_min        -3000



typedef struct
{
    float kp;
    float ki;
    float kd;
    float error;
    float last_error;
    float error_int;
    float output;
    float error_dt;
} PIDS;

typedef struct{
    float kp1;
    float kp;
    float kp2;
    float gkd;
    float ki;
    float errInt;
    float kd;
    float error;
    float last_error;
    float output;
}PIDT;
//������
extern PIDS PIDSL; //extern��.h��ӣ�Ȼ��ԭ����PIDSL��Ҫ��.c����
extern PIDS PIDSR;
extern PIDT PIDTurn;

//������
void pid_canshu_init(void);
float Pid_Speed_Proc(float Target , float Actual, PIDS*pid);
float PidT_Proc(float error , float gyroz, PIDT*pid);
#endif /* CODE_PIDD_H_ */
