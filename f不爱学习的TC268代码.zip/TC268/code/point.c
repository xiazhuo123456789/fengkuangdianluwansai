#include "point.h"
int point_l = 0;
int point_r = 0;
int point_m = 0;
int point_lx = 0;
int point_rx = 0;

int point_lxx = 0;
int point_rxx = 0;

int point_upy = 0;
int point_dy = 0;
#define YUZHI 58
#define YUZHIM 30
#define SCAN_WIDTH 13  // �ӱ�Ե����ɨ����������ɵ�����
int bfscnt = 200;
/*
 * @�������ã���������ͨ�ĵ�
 */
void GetBoundaryLink_LR_Point(int start, int end)
{
//***************************************��һ��***************************************************//
    // ��ʼ��
    point_lx = 0;
    point_rx = 0;
    point_lxx = 0;
    point_rxx = 0;
    // ��׼��ɨ�跽��ȷ�� start > end���ӽ���Զɨ
    if (start < end) {
        int t = start;
        start = end;
        end = t;
    }

    // �߽籣��
    if (start > ROW - 2 - 5) start = ROW - 2 - 5;  // ��Ҫ���� i �� i-1���ʲ��ܵ����һ��
    if (end < 6) end = 6;                          // ȷ�� i-1 >= 0

    // Ԥ����ɨ�賣��
    const int right_edge_col = COL - 2;                  // �ұ�Ե�����
    const int right_scan_start = COL - 3;                // ���ڲ�ɨ����ʼ��
    const int right_scan_end   = COL - 1 - SCAN_WIDTH;   // ���ڲ�ɨ���յ㣨>=���У�
    const int left_scan_start  = 3;                      // ���ڲ�ɨ����ʼ��
    const int left_scan_end    = SCAN_WIDTH;             // ���ڲ�ɨ���յ㣨<���У���ɨ�赽 SCAN_WIDTH-1 �У�

    // ��ɨ��ѭ��
    for (int i = start; i >= end; i--)
    {
        // ��ȡ��ǰ�к���һ�е�ָ��
        uint8 *row_cur = bin_image[i];
        uint8 *row_prev = bin_image[i - 1];

        // ========== ��߽��⣨����δ�ҵ��� ==========
        if (point_lxx == 0)
        {
            // ����Ե�������а�
            if (row_cur[0] == WHITE && row_prev[0] == WHITE)
            {
                // ����ɨ�裬һ�����ֺڵ�������
                uint8 *p = row_cur + left_scan_start;
                uint8 *q = row_prev + left_scan_start;
                int black_cnt = 0;

                // �ֶ�ѭ��չ����ÿ�μ�����У�cur��prev��������2
                int col = left_scan_start;
                for (; col < left_scan_end - 1; col += 2)
                {
                    if ((*p == BLACK) || (*(p+1) == BLACK) ||
                        (*q == BLACK) || (*(q+1) == BLACK))
                    {
                        black_cnt = 1;
                        break;
                    }
                    p += 2;
                    q += 2;
                }
                // ��������ʣ��ĵ��У���ɨ�����Ϊ����ʱ��
                if (black_cnt == 0 && col < left_scan_end)
                {
                    if ((*p == BLACK) || (*q == BLACK))
                    {
                        black_cnt = 1;
                    }
                }

                if (black_cnt == 0)
                {
                    point_lxx = i;
                }
            }
        }

        // ========== �ұ߽��⣨����δ�ҵ��� ==========
        if (point_rxx == 0)
        {
            if (row_cur[right_edge_col] == WHITE && row_prev[right_edge_col] == WHITE)
            {
                // ����ɨ�裬����������ָ��ݼ�
                uint8 *p = row_cur + right_scan_start;
                uint8 *q = row_prev + right_scan_start;
                int black_cnt = 0;

                int col = right_scan_start;
                for (; col > right_scan_end; col -= 2)
                {
                    if ((*p == BLACK) || (*(p-1) == BLACK) ||
                        (*q == BLACK) || (*(q-1) == BLACK))
                    {
                        black_cnt = 1;
                        break;
                    }
                    p -= 2;
                    q -= 2;
                }
                // ��������ʣ��ĵ���
                if (black_cnt == 0 && col == right_scan_end)
                {
                    if ((*p == BLACK) || (*q == BLACK))
                    {
                        black_cnt = 1;
                    }
                }

                if (black_cnt == 0)
                {
                    point_rxx = i;
                }
            }
        }

//***************************************��2��***************************************************//
        if (point_lxx != 0 || point_rxx != 0)
        {
            if(point_lxx != 0)
            {
                int scan_line_flag = scan_vertical_line(point_lxx+30, point_lxx-30, 10, bin_image);
                if(scan_line_flag == 1)
                {
                    //***��3��*************//
                    if(bfs_check(point_lxx, 10, bfscnt , bin_image) == 1)
                    {
                        point_lx = point_lxx;
                    }
                    else
                    {
                        point_lx = 0;
                    }
                }
                else if(scan_line_flag == 0)
                {
                    point_lxx = 0;
                }

            }
            if(point_rxx != 0)
            {
                int scan_line_flag = scan_vertical_line(point_rxx+30, point_rxx-30, 175,bin_image);
                if(scan_line_flag == 1)
                {
                    if(bfs_check(point_rxx, 170, bfscnt , bin_image) == 1)
                    {
                       point_rx = point_rxx;
                    }
                    else
                    {
                        point_rx = 0;
                    }
                }
                else if(scan_line_flag == 0)
                {
                    point_rxx = 0;
                }
            }
            if (point_lx != 0 && point_rx != 0)
            {
                break;
            }

        }

    }
}

void GetBoundaryLink_LR_Point_beiyong1(int start , int end)//start�ǽ�

{
    point_lx = 0;
    point_rx = 0;
    int blackcntR = 0;
    int blackcntL = 0;
    int t;
    if (start < end)
    {
        t = start;
        start = end;
        end = t;
    }
    if (start >= ROW - 1 - 5)  start = ROW - 1 - 5;
    if (end <= 5) end = 5;
    for(int i = start ; i >= end ; i--)//�ӽ���Զ���б���
    {
        if( (point_lx == 0)&&
            // ��һ���������� ��
            (bin_image[i][0] == WHITE))
        {
            blackcntL = 0;

            for(int j =10;j<35;j++)
            {
                int row1 = i;
                int row2 = i-1;

                if((bin_image[row1][j] == BLACK))
                {
                    blackcntL++;

                        break;

                }

            }
            if(blackcntL == 0)
            {
                point_lx = i;
            }
            else
            {
                point_lx = 0;
            }


        }
        if( (point_rx == 0)&&
                    // ��һ���������� ��
                    (bin_image[i][COL-2] ==WHITE))
              {
                    blackcntR = 0;

                    for(int j =COL-10;j>=COL-1-35;j--)
                    {
                        int row1 = i;
                        int row2 = i-1;

                        if((bin_image[row1][j] == BLACK))
                        {
                            blackcntR++;
                            break;
                        }

                    }
                    if(blackcntR == 0)
                    {
                        point_rx = i;
                    }
                    else
                    {
                        point_rx = 0;
                    }

              }
        if (point_lx != 0 && point_rx != 0)
        {
              return;
        }
    }


}
void GetBoundaryLink_LR_Point_beiyong(int start, int end)
{
    point_lx = 0;
    point_rx = 0;
    int t;

    // ��׼��ɨ�跽��ȷ�� start > end���ӽ���Զɨ
    if (start < end) {
        t = start;
        start = end;
        end = t;
    }

    // �߽籣��
    if (start >= ROW - 1 - 5)  start = ROW - 1 - 5;
    if (end <= 5) end = 5;

    // �׵�ͳ�Ʒ�Χ���ӱ�Ե���ڶ����У�
    const int scan_cols = 35;         // ͳ��35���ڵİ׵�
    const int white_threshold = 35;   // �׵�����������ֵ���ж�Ϊ�յ�

    for (int i = start; i >= end; i--)
    {
        // ========== ��յ��⣨����δ�ҵ��� ==========
        if (point_lx == 0)
        {
            int white_cnt = 0;
            for (int j = 0; j < scan_cols; j++) {
                if (bin_image[i][j] == WHITE) {
                    white_cnt++;
                }
            }
            if (white_cnt >= white_threshold) {
                point_lx = i;
            }
        }

        // ========== �ҹյ��⣨����δ�ҵ��� ==========
        if (point_rx == 0)
        {
            int white_cnt = 0;
            for (int j = COL - 2; j > COL - 2 - scan_cols; j--) {
                if (bin_image[i][j] == WHITE) {
                    white_cnt++;
                }
            }
            if (white_cnt >= white_threshold) {
                point_rx = i;
            }
        }

        // ������ҹյ㶼���ҵ�����ǰ�˳�
        if (point_lx != 0 && point_rx != 0) {
            return;
        }
    }
}
void GetBoundaryLink_LR_Point_ceshi(int start, int end)
{
//***************************************��һ��***************************************************//
    // ��ʼ��
    point_lx = 0;
    point_rx = 0;

    // ��׼��ɨ�跽��ȷ�� start > end���ӽ���Զɨ
    if (start < end) {
        int t = start;
        start = end;
        end = t;
    }

    // �߽籣��
    if (start > ROW - 2 - 5) start = ROW - 2 - 5;  // ��Ҫ���� i �� i-1���ʲ��ܵ����һ��
    if (end < 6) end = 6;                          // ȷ�� i-1 >= 0

    // Ԥ����ɨ�賣��
    const int right_edge_col = COL - 2;                  // �ұ�Ե�����
    const int right_scan_start = COL - 3;                // ���ڲ�ɨ����ʼ��
    const int right_scan_end   = COL - 1 - SCAN_WIDTH;   // ���ڲ�ɨ���յ㣨>=���У�
    const int left_scan_start  = 3;                      // ���ڲ�ɨ����ʼ��
    const int left_scan_end    = SCAN_WIDTH;             // ���ڲ�ɨ���յ㣨<���У���ɨ�赽 SCAN_WIDTH-1 �У�

    // ��ɨ��ѭ��
    for (int i = start; i >= end; i--)
    {
        // ��ȡ��ǰ�к���һ�е�ָ��
        uint8 *row_cur = bin_image[i];
        uint8 *row_prev = bin_image[i - 1];

        // ========== ��߽��⣨����δ�ҵ��� ==========
        if (point_lx == 0)
        {
            // ����Ե�������а�
            if (row_cur[0] == WHITE && row_prev[0] == WHITE)
            {
                // ����ɨ�裬һ�����ֺڵ�������
                uint8 *p = row_cur + left_scan_start;
                uint8 *q = row_prev + left_scan_start;
                int black_cnt = 0;

                // �ֶ�ѭ��չ����ÿ�μ�����У�cur��prev��������2
                int col = left_scan_start;
                for (; col < left_scan_end - 1; col += 2)
                {
                    if ((*p == BLACK) || (*(p+1) == BLACK) ||
                        (*q == BLACK) || (*(q+1) == BLACK))
                    {
                        black_cnt = 1;
                        break;
                    }
                    p += 2;
                    q += 2;
                }
                // ��������ʣ��ĵ��У���ɨ�����Ϊ����ʱ��
                if (black_cnt == 0 && col < left_scan_end)
                {
                    if ((*p == BLACK) || (*q == BLACK))
                    {
                        black_cnt = 1;
                    }
                }

                if (black_cnt == 0)
                {
                    point_lx = i;
                }
            }
        }

        // ========== �ұ߽��⣨����δ�ҵ��� ==========
        if (point_rx == 0)
        {
            if (row_cur[right_edge_col] == WHITE && row_prev[right_edge_col] == WHITE)
            {
                // ����ɨ�裬����������ָ��ݼ�
                uint8 *p = row_cur + right_scan_start;
                uint8 *q = row_prev + right_scan_start;
                int black_cnt = 0;

                int col = right_scan_start;
                for (; col > right_scan_end; col -= 2)
                {
                    if ((*p == BLACK) || (*(p-1) == BLACK) ||
                        (*q == BLACK) || (*(q-1) == BLACK))
                    {
                        black_cnt = 1;
                        break;
                    }
                    p -= 2;
                    q -= 2;
                }
                // ��������ʣ��ĵ���
                if (black_cnt == 0 && col == right_scan_end)
                {
                    if ((*p == BLACK) || (*q == BLACK))
                    {
                        black_cnt = 1;
                    }
                }

                if (black_cnt == 0)
                {
                    point_rx = i;
                }
            }
        }

//***************************************��2��***************************************************//
        if (point_lx != 0 || point_rx != 0)
        {
            if(point_lx != 0)
            {
                int scan_line_flag = scan_vertical_line(100, 20, 12, bin_image);
                if(scan_line_flag == 1)
                {

                }
                else if(scan_line_flag == 0)
                    break;
            }
            if(point_rx != 0)
            {
                int scan_line_flag = scan_vertical_line(100, 20, 175,bin_image);
                if(scan_line_flag == 1)
                {

                }
                else if(scan_line_flag == 0)
                    break;
            }


        }

    }
}


/********************************************************************************************************/
void GetBoundaryLink_LR_Point_ceshi2(int start, int end)
{
//***************************************��һ��***************************************************//
    // ��ʼ��
    point_lx = 0;
    point_rx = 0;
    point_lxx = 0;
    point_rxx = 0;
    // ��׼��ɨ�跽��ȷ�� start > end���ӽ���Զɨ
    if (start < end) {
        int t = start;
        start = end;
        end = t;
    }

    // �߽籣��
    if (start > ROW - 2 - 5) start = ROW - 2 - 5;  // ��Ҫ���� i �� i-1���ʲ��ܵ����һ��
    if (end < 6) end = 6;                          // ȷ�� i-1 >= 0

    // Ԥ����ɨ�賣��
    const int right_edge_col = COL - 2;                  // �ұ�Ե�����
    const int right_scan_start = COL - 3;                // ���ڲ�ɨ����ʼ��
    const int right_scan_end   = COL - 1 - SCAN_WIDTH;   // ���ڲ�ɨ���յ㣨>=���У�
    const int left_scan_start  = 3;                      // ���ڲ�ɨ����ʼ��
    const int left_scan_end    = SCAN_WIDTH;             // ���ڲ�ɨ���յ㣨<���У���ɨ�赽 SCAN_WIDTH-1 �У�

    // ��ɨ��ѭ��
    for (int i = start; i >= end; i--)
    {
        // ��ȡ��ǰ�к���һ�е�ָ��
        uint8 *row_cur = bin_image[i];
        uint8 *row_prev = bin_image[i - 1];

        // ========== ��߽��⣨����δ�ҵ��� ==========
        if (point_lxx == 0)
        {
            // ����Ե�������а�
            if (row_cur[0] == WHITE && row_prev[0] == WHITE)
            {
                // ����ɨ�裬һ�����ֺڵ�������
                uint8 *p = row_cur + left_scan_start;
                uint8 *q = row_prev + left_scan_start;
                int black_cnt = 0;

                // �ֶ�ѭ��չ����ÿ�μ�����У�cur��prev��������2
                int col = left_scan_start;
                for (; col < left_scan_end - 1; col += 2)
                {
                    if ((*p == BLACK) || (*(p+1) == BLACK) ||
                        (*q == BLACK) || (*(q+1) == BLACK))
                    {
                        black_cnt = 1;
                        break;
                    }
                    p += 2;
                    q += 2;
                }
                // ��������ʣ��ĵ��У���ɨ�����Ϊ����ʱ��
                if (black_cnt == 0 && col < left_scan_end)
                {
                    if ((*p == BLACK) || (*q == BLACK))
                    {
                        black_cnt = 1;
                    }
                }

                if (black_cnt == 0)
                {
                    point_lxx = i;
                }
            }
        }

        // ========== �ұ߽��⣨����δ�ҵ��� ==========
        if (point_rxx == 0)
        {
            if (row_cur[right_edge_col] == WHITE && row_prev[right_edge_col] == WHITE)
            {
                // ����ɨ�裬����������ָ��ݼ�
                uint8 *p = row_cur + right_scan_start;
                uint8 *q = row_prev + right_scan_start;
                int black_cnt = 0;

                int col = right_scan_start;
                for (; col > right_scan_end; col -= 2)
                {
                    if ((*p == BLACK) || (*(p-1) == BLACK) ||
                        (*q == BLACK) || (*(q-1) == BLACK))
                    {
                        black_cnt = 1;
                        break;
                    }
                    p -= 2;
                    q -= 2;
                }
                // ��������ʣ��ĵ���
                if (black_cnt == 0 && col == right_scan_end)
                {
                    if ((*p == BLACK) || (*q == BLACK))
                    {
                        black_cnt = 1;
                    }
                }

                if (black_cnt == 0)
                {
                    point_rxx = i;
                }
            }
        }

//***************************************��2��***************************************************//
        if (point_lxx != 0 || point_rxx != 0)
        {
            if(point_lxx != 0)
            {
                int scan_line_flag = scan_vertical_line(point_lxx+30, point_lxx-30, 60, bin_image);
                if(scan_line_flag == 1)
                {
                    point_lx = point_lxx;
                }
                else if(scan_line_flag == 0)
                    break;
            }
            if(point_rxx != 0)
            {
                int scan_line_flag = scan_vertical_line(point_rxx+30, point_rxx-30, 60 ,bin_image);
                if(scan_line_flag == 1)
                {
                    point_rx = point_rxx;
                }
                else if(scan_line_flag == 0)
                    break;
            }

        }

    }
}
/*
 * �������ã�Ѱ�����ұ��������ĵ�
 */
void GetLeftRightEdgeJumpPoint(int start , int end)//start�ǽ�
//���Ľ�������ҹյ㶼������ģ�Ҳ��ʵ�����кܶ�յ�
{
    point_lx = 0;
    point_rx = 0;
    int t;
    if (start < end)
    {
        t = start;
        start = end;
        end = t;
    }
    if (start >= ROW - 1 - 5)  start = ROW - 1 - 5;
    if (end <= 5) end = 5;
    for(int i = start ; i >= end ; i--)//�ӽ���Զ���б���
    {
        if( (point_lx == 0&&
            // ��һ���������� ��
            (abs(Line_L[i] - Line_L[i+1]) <= 4) &&
            (abs(Line_L[i+1] - Line_L[i+2]) <= 4) &&
            (abs(Line_L[i+2] - Line_L[i+3]) <= 4) &&
            // Զ ��
            (abs(Line_L[i] - Line_L[i-2]) >= YUZHI) &&
            (abs(Line_L[i] - Line_L[i-3]) >= YUZHI)
        ) || (point_lx == 0&&
            // �ڶ����������� ��
            (abs(Line_L[i] - Line_L[i+1]) <= 4) &&
            (abs(Line_L[i+1] - Line_L[i+2]) <= 4) &&
            (abs(Line_L[i+2] - Line_L[i+3]) <= 4) &&
            // Զ ��
            (abs(Line_L[i] - Line_L[i-4]) >= YUZHI) &&
            (abs(Line_L[i] - Line_L[i-5]) >= YUZHI)
        ) )
        {
            point_lx = i;
        }
        if( (point_rx == 0&&
                            // ��һ���������� ��
                            (abs(Line_R[i] - Line_R[i+1]) <= 4) &&
                            (abs(Line_R[i+1] - Line_R[i+2]) <= 4) &&
                            (abs(Line_R[i+2] - Line_R[i+3]) <= 4) &&
                            // Զ ��
                            (abs(Line_R[i] - Line_R[i-2]) >= YUZHI) &&
                            (abs(Line_R[i] - Line_R[i-3]) >= YUZHI)
                        ) || (point_rx == 0&&
                            // �ڶ����������� ��
                            (abs(Line_R[i] - Line_R[i+1]) <= 4) &&
                            (abs(Line_R[i+1] - Line_R[i+2]) <= 4) &&
                            (abs(Line_R[i+2] - Line_R[i+3]) <= 4) &&
                            // Զ ��
                            (abs(Line_R[i] - Line_R[i-4]) >= YUZHI) &&
                            (abs(Line_R[i] - Line_R[i-5]) >= YUZHI)
                        ) )
        {
            point_rx = i;
        }
        if (point_lx != 0 && point_rx != 0)
        {
              return;
        }
    }


}


void GetBoundaryLink_UD_Point(int start , int end)//start�ǽ�

{
    point_upy = 0;
    point_dy = 0;
    int blackcntD = 0;
    int blackcntUP = 0;
    int t;
    if (start > end)
    {
        t = start;
        start = end;
        end = t;
    }
    if (end >= 180)  end = 180;
    if (start <= 0) start = 0;
    for(uint8_t i = start ; i <= end ; i++)//�ӽ���Զ���б���
    {
        if( (point_upy == 0)&&
            // ��һ���������� ��
            (bin_image[3][i] == WHITE) &&
            (bin_image[3][i+1] == WHITE))
        {
            blackcntUP = 0;

            for(int j =3;j<=18;j++)
            {
                int col1 = i;
                int col2 = i+1;

                if((bin_image[j][col1] == BLACK) || (bin_image[j][col2] == BLACK))
                {
                    blackcntUP++;

                        break;

                }

            }
            if(blackcntUP == 0)
            {
                point_upy = i;
            }
            else
            {
                point_upy = 0;
            }


        }
        if( (point_dy == 0)&&
                    // ��һ���������� ��
                    (bin_image[ROW-1][i] ==WHITE) &&
                    (bin_image[ROW-1][i+1] == WHITE))
              {//
                blackcntD = 0;

                    for(int j =ROW-2; j >= ROW-15; j--)
                    {
                        int col1 = i;
                        int col2 = i+1;

                        if((bin_image[j][col1] == BLACK) || (bin_image[j][col2] == BLACK) )
                        {
                            blackcntD++;
                            break;
                        }

                    }
                    if(blackcntD == 0)
                    {
                        point_dy = i;
                    }
                    else
                    {
                        point_dy = 0;
                    }

              }//
        if (point_upy != 0 && point_dy != 0)
        {
              return;
        }
    }
}
/**********************************************ע��*******************************************************/

/*void GetMidEdgeJumpPoint(int start , int end)//start�ǽ�
//���Ľ�������ҹյ㶼������ģ�Ҳ��ʵ�����кܶ�յ�
{
    point_m = 0;

    int t;
    if (start < end)
    {
        t = start;
        start = end;
        end = t;
    }
    if (start >= ROW - 1 - 5)  start = ROW - 1 - 5;
    if (end <= 5) end = 5;
    for(int i = start ; i >= end ; i--)//�ӽ���Զ���б���
    {
        if( (point_m == 0&&
            // ��һ���������� ��
            (abs(Line_M[i] - Line_M[i+1]) <= 4) &&
            (abs(Line_M[i+1] - Line_M[i+2]) <= 4) &&
            (abs(Line_M[i+2] - Line_M[i+3]) <= 4) &&
            // Զ ��
            (abs(Line_M[i] - Line_M[i-2]) >= YUZHIM) &&
            (abs(Line_M[i] - Line_M[i-3]) >= YUZHIM)
        ) || (point_m == 0&&
            // �ڶ����������� ��
            (abs(Line_M[i] - Line_M[i+1]) <= 4) &&
            (abs(Line_M[i+1] - Line_M[i+2]) <= 4) &&
            (abs(Line_M[i+2] - Line_M[i+3]) <= 4) &&
            // Զ ��
            (abs(Line_M[i] - Line_M[i-4]) >= YUZHIM) &&
            (abs(Line_M[i] - Line_M[i-5]) >= YUZHIM)
        ) )
        {
            point_m = i;
        }

        if (point_m != 0 )
        {
              return;
        }
    }


}
 */

