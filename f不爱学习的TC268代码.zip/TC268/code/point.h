#ifndef CODE_POINT_H_
#define CODE_POINT_H_
#include "zf_common_headfile.h"

extern int point_l;
extern int point_r;
extern int point_m;
extern int point_lx;
extern int point_rx ;
extern int point_upy;
extern int point_dy ;
//����
//��ǰ����
void GetBoundaryLink_LR_Point(int start , int end);
void GetBoundaryLink_LR_Point_beiyong(int start , int end);
void GetBoundaryLink_LR_Point_beiyong1(int start , int end);
void GetBoundaryLink_LR_Point_ceshi(int start, int end);
void GetBoundaryLink_LR_Point_ceshi2(int start, int end);
//�ο�
void GetLeftRightEdgeJumpPoint(int start , int end);
void GetMidEdgeJumpPoint(int start , int end);
void GetBoundaryLink_UD_Point(int start , int end);

#endif
