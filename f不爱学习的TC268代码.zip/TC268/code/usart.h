#ifndef CODE_USART_H_
#define CODE_USART_H_

#include "zf_common_headfile.h"
void wireless_uart_printf(const char *format, ...);
void wireless_uart_printf_safe(const char *format, ...);
void wireless_uart_printf_main(const char *format, ...);
#endif
