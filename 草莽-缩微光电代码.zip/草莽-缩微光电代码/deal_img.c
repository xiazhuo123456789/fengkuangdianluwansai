/**
 * @file    deal_img.c
 * @brief   图像处理模块源文件 - 缩微光电智能车
 * @details 实现完整的图像处理流水线：
 *          1. 图像预处理：灰度直方图统计 → 大津法二值化 → 腐蚀去噪
 *          2. 虚线补线：白点迁移、断点补线
 *          3. 边界搜索：八邻域法巡线，提取左右边界
 *          4. 边缘特征：提取四方向丢失特征，判断赛道类型
 *          5. 中线绘制：根据赛道类型选择直线/曲线中线
 *          6. 元素处理：环岛、十字路口、停车线、断路
 */
#include "deal_img.h"

/*============================================================================
 *                         全局变量定义
 *============================================================================*/

/*----- 赛道类型标志 -----*/
enum ImgFlag IF = straightlineS;   // 当前帧赛道类型（初始化为短直道）
enum ImgFlag IF_L = straightlineS; // 上一帧赛道类型

/*----- 元素识别控制 -----*/
volatile Elements_Mode elements_Mode = NO;           // 元素识别开关
volatile Elements_Lock elements_Lock[10] = {Empty_}; // 元素锁定队列
volatile Annulus_Mode Annulus_mode = Differential;   // 环岛巡线模式
int elements_index = 0;                              // 元素锁定队列索引

/*----- 停车线相关 -----*/
uint8 stopline_flag = 0;     // 停车线识别标志（1=已识别过）
uint8 stop_num = 0;          // 停车线检测计数

/*----- 环岛相关 -----*/
uint8 Annulus_flag = 0;      // 环岛状态机（0=未识别, 1=识别到, 2=正在驶入, 3=正在驶离）
float Annulus_Zero = 0;      // 进入环岛时的偏航角基准
float Annulus_Yaw = 0;       // 环岛内累计偏航角
int Annulus_Curvature[5] = {10,10,10,10,10}; // 环岛曲率参数（控制转弯幅度）
int Annulus_num = 0;         // 通过的环岛计数

/*----- 图像处理状态 -----*/
uint8 dealimg_finish_flag = 0; // 图像处理完成标志
int deal_runing = 0;          // 图像处理运行标志（防止重入）
int dealimg_time = 0;         // 图像处理耗时

/*----- 断路相关 -----*/
uint8 disappear_flag = 0;    // 断路状态机（0=未识别, 1=纯黑区, 2=调整角度, 3=找到白线）
int disappear_num = 0;       // 已通过的断路区计数
int disappear_total = 3;     // 断路区总数限制
int Disappear_angle_L[3];    // 左行各断路区目标角度
int Disappear_angle_R[3];    // 右行各断路区目标角度
float Start_angle = 0;       // 发车时偏航角
float Disappear_Zero = 0;    // 断路起始偏航角
float Disappear_Yaw = 0;     // 断路累计偏航角
float Disappear_Length = 0;  // 断路行驶里程
float Disappear_Position = 0;// 断路起始位置里程
int Disappear_Dir_L[3][3] = {{0}}; // 左行断路方向参数
int Disappear_Dir_R[3][3] = {{0}}; // 右行断路方向参数
volatile RUN_Dir run_dir = Right;  // 行驶方向（左行/右行）

/*----- 曲率 -----*/
int Curvature = 10;          // 当前曲率值

/*============================================================================
 *                    全局变量定义 - 二值化与阈值
 *============================================================================*/

uint16_t histogram[256];       // 灰度直方图（256个灰度级的像素计数）
uint8_t previousThreshold = 0; // 上一帧阈值（用于平滑）
uint8_t nowThreshold = 0;     // 当前帧OSTU阈值
int minGrayscale = 40;        // 灰度最小值下限（防止过暗图像干扰）
int maxGrayscale = 160;       // 灰度最大值上限（防止过亮图像干扰）
int minGray = 0;              // 当前帧实际最小灰度
int maxGray = 0;              // 当前帧实际最大灰度
uint8_t minThreshold = 70;    // 阈值下限保护
uint8_t maxThreshold = 160;   // 阈值上限保护

/* 分区域阈值偏移量（近/中/远三段不同阈值，适应不同距离曝光差异）
 * 近景：加阈值（图像较亮，需要更高阈值区分黑白）
 * 远景：减阈值（图像较暗，需要更低阈值保留白点）*/
uint8 img_threshold_group[3]; // [0]=近景 [1]=中景 [2]=远景 实际阈值
uint8 close_Threshold = 0;    // 近景阈值偏移量
uint8 far_Threshold = 0;      // 远景阈值偏移量
uint8 mid_Threshold = 0;      // 中景阈值偏移量

uint16 EXP_TIME = 255;        // 曝光时间（微秒）
int UD_OFFSET_DEF = 0;        // 上下偏移补偿

/*============================================================================
 *                    全局变量定义 - 图像数据
 *============================================================================*/

uint8 imgGray[IMG_H][IMG_W];  // 原始灰度图像
uint8 imgTran[IMG_H][IMG_W];  // 虚线补线方向标记图（记录黑点周围白点方向）
uint8 img2wifi[IMG_H][IMG_W]; // WiFi图传图像
uint8 imgOSTU[YM][XM];        // 二值化处理后的主图像（主处理对象）

/* 白点统计 */
uint8 white_num_row[YM];      // 每行白点数量
uint8 white_num_col[XM];      // 每列白点数量
uint8 white_row_max[2], white_row_min[2]; // 行白点最大/最小 [0]=数量 [1]=行号
uint8 white_col_max[2], white_col_min[2]; // 列白点最大/最小 [0]=数量 [1]=列号

/* 中线 */
uint8 mid_line[YM] = {XM/2};  // 中线X坐标（每行一个值，初始化为图像中心）
uint8 Make_up_num[YM] = {0};  // 虚线补线标记数组

/*============================================================================
 *                    全局变量定义 - 起点与终点
 *============================================================================*/

/* 巡线起点（底部黑白跳变点中点）*/
uint8 start_center_last = XM/2; // 上一帧起点X（用于平滑）
uint8 start_center = XM/2;     // 起点X（兼容旧代码）
uint8 start_point_l = 0;       // 左边界起点X
uint8 start_point_r = XX;      // 右边界起点X
uint8 start_center_y = 0;      // 起点Y行号
uint8 start_center_x = XM/2;   // 起点X坐标

/* 巡线终点（中线顶部端点）*/
uint8 end_center = XM/2;       // 终点X（兼容）
uint8 end_center_x = XM/2;     // 终点X坐标
uint8 end_center_y = Deal_Top; // 终点Y坐标

/*============================================================================
 *                    全局变量定义 - 边缘丢失特征
 *============================================================================*/

/* 四方向丢失像素总数 */
uint8 l_lost_tip = 0;  // 左侧丢失像素数
uint8 r_lost_tip = 0;  // 右侧丢失像素数
uint8 t_lost_tip = 0;  // 顶部丢失像素数
uint8 b_lost_tip = 0;  // 底部丢失像素数

/* 四方向丢失区域数量（0/1/2）*/
uint8 b_lost_num = 0;  // 底部丢失区域数
uint8 t_lost_num = 0;  // 顶部丢失区域数
uint8 l_lost_num = 0;  // 左侧丢失区域数
uint8 r_lost_num = 0;  // 右侧丢失区域数

/* 状态标志 */
uint8 Stop_line = 0;       // 中线绘制高度
uint8 dis_Solidline = 0;   // 实线标志（1=无丢失，实线直道）

/* 丢失区域中心坐标 */
uint16 b_center[3] = {0};  // 底部丢失中心X
uint16 l_center[3] = {0};  // 左侧丢失中心Y
uint16 r_center[3] = {0};  // 右侧丢失中心Y
uint16 t_center[3] = {0};  // 顶部丢失中心X

/* 处理区域尺寸（动态可调）*/
int Deal_W = XX;  // 处理区域宽度
int Deal_H = YY;  // 处理区域高度

/* 图像处理耗时 */
float start_time = 0;
float end_time = 0;
float deal_time = 0;

/* 里程与环岛 */
extern float Length;              // 车辆行驶总里程（由其他模块提供）
float Out_Annulus_Length = 0;    // 驶出环岛时的里程记录
float Stopline_Position = 0;    // 停车线位置里程
float Stopline_Judge = 300;     // 停车线判断距离阈值（cm）
float Stop_Length = 0;          // 停车线相关里程

/*============================================================================
 *              全局变量定义 - 虚线补线方向标记系统
 *============================================================================*/
/*
 * 虚线补线方向编码原理：
 *   每个黑点标记其周围白点的方向，用4位二进制表示：
 *     bit0(1) = 上方有白点 (Goto_U)
 *     bit1(2) = 下方有白点 (Goto_D)
 *     bit2(4) = 左方有白点 (Goto_L)
 *     bit3(8) = 右方有白点 (Goto_R)
 *
 *   组合值 = 各方向编码之和，表示该黑点被哪些方向的白点包围：
 *     UD(3)   = 上下有白点（竖直虚线断点）
 *     LR(12)  = 左右有白点（水平虚线断点）
 *     DLR(14) = 下左右有白点（聚点，环岛/十字特征）
 *     ULR(13) = 上左右有白点（聚点，环岛/十字特征）
 *     UDLR(15)= 四方都有白点（十字交叉点）
 *
 * EXTERN_sum[组合值]  = 该组合值的总出现次数
 * EXTERN_ROW[组合值][行] = 该组合值在每行的出现次数
 */
int EXTERN_sum[16] = {0};     // 各方向组合的总出现次数
int EXTERN_ROW[16][YM] = {{0}}; // 各方向组合在每行的出现次数

/* 方向编码常量 */
int Goto_U = 1;    // 上方有白点
int Goto_D = 2;    // 下方有白点
int Goto_L = 4;    // 左方有白点
int Goto_R = 8;    // 右方有白点

/* 组合方向编码常量 */
int UD = 3;        // 上下（竖直断点）
int UL = 5;        // 上左
int UR = 9;        // 上右
int DL = 6;        // 下左
int DR = 10;       // 下右
int LR = 12;       // 左右（水平断点）
int UDL = 7;       // 上下左
int UDR = 11;      // 上下右
int ULR = 13;      // 上左右（聚点，环岛特征）
int DLR = 14;      // 下左右（聚点，环岛特征）
int UDLR = 15;     // 上下左右（十字交叉点）

/* 左右边界白点迁移计数 */
int EXTERN_L = 0;  // 左边界迁移白点数
int EXTERN_R = 0;  // 右边界迁移白点数

/*============================================================================
 *              全局变量定义 - 标定参数表（像素-实际距离换算）
 *============================================================================*/
/*
 * 以下三个数组是通过实际赛道标定得到的查找表，用于像素坐标与实际距离的换算。
 * 由于摄像头透视效果，图像中不同行对应的赛道宽度和实际距离不同：
 *   - 近处（底部行）：像素对应的实际距离小，赛道看起来宽
 *   - 远处（顶部行）：像素对应的实际距离大，赛道看起来窄
 *
 * white_width[i] = 第i行赛道白点的理论宽度（像素数）
 * Length_5cm[i]  = 第i行中5cm实际长度对应的像素数
 * k1[i]          = 第i行像素到实际距离的换算系数（25/white_width[i]）
 * k2[i]          = 第i行累计距离偏移量
 */

/* 每行赛道理论白点宽度（像素），从底部到顶部逐渐减小（透视收缩）*/
float white_width[YM] = {17,17,17,17,17,16,16,16,16,16,
                         16,16,16,15,15,15,15,14,14,14,
                         14,14,14,13,13,13,13,13,13,13,
                         12,12,12,12,12,11,11,11,11,10,
                         10,10,10,10,10,10,10,10,10, 9,
                          9, 9, 9, 9, 9, 8, 8, 8, 8, 8,
                          7, 7, 7, 7, 6, 6, 6, 6, 5, 5};

/* 每行5cm实际长度对应的像素数（用于判断虚线间距等）*/
float Length_5cm[YM] = {30,29,28,28,27,27,26,26,25,25,
                         25,25,25,25,24,24,24,23,23,23,
                         22,22,22,22,21,21,21,20,20,20,
                         19,19,19,18,18,18,17,17,16,16,
                         15,15,15,14,14,14,13,13,12,12,
                         11,11,11,11,11,10,10,10,9, 9,
                          9, 8, 8, 8, 8, 7, 7, 7, 7, 7};

/* 像素-距离换算系数1：k1[i] = 25 / white_width[i] */
float k1[YM] = { 25/17, 25/17, 25/17, 25/17, 25/17, 25/16, 25/16, 25/16, 25/16, 25/16,
                 25/16, 25/16, 25/16, 25/15, 25/15, 25/15, 25/15, 25/14, 25/14, 25/14,
                 25/14, 25/14, 25/14, 25/13, 25/13, 25/13, 25/13, 25/13, 25/13, 25/13,
                 25/12, 25/12, 25/12, 25/12, 25/12, 25/11, 25/11, 25/11, 25/11, 25/10,
                 25/10, 25/10, 25/10, 25/10, 25/10, 25/10, 25/10, 25/10, 25/10,  25/9,
                  25/9,  25/9,  25/9,  25/9,  25/9,  25/8,  25/8,  25/8,  25/8,  25/8,
                  25/7,  25/7,  25/7,  25/7,  25/6,  25/6,  25/6,  25/6,  25/5,  25/5};

/* 像素-距离换算系数2：累计距离偏移量（用于环岛曲率计算等）*/
float k2[YM] = { 0.00,  0.28,  0.57,  0.85,  1.14,  1.45,  1.71,  1.99,  2.28,  2.56,
                 2.85,  3.13,  3.42,  3.70,  3.99,  4.27,  4.56,  4.84,  5.13,  5.41,
                 5.70,  5.98,  6.27,  6.55,  6.84,  7.12,  7.41,  7.69,  7.98,  8.26,
                 8.55,  8.83,  9.12,  9.40,  9.69,  9.97, 10.26, 10.54, 10.83, 11.11,
                11.28, 11.57, 11.85, 12.14, 12.43, 12.71, 13.00, 13.28, 13.57, 13.86,
                14.14, 14.43, 14.71, 15.00, 15.29, 15.57, 15.86, 16.14, 16.43, 16.72,
                17.00, 17.29, 17.57, 17.86, 18.15, 18.43, 18.72, 19.01, 19.29, 20.00};


/**
 * @brief 图像处理模块初始化
 * @details 重置所有图像处理相关的状态标志和计数器。
 *          在每次图像处理循环开始前调用，确保上一帧的状态不影响当前帧。
 *          重置内容包括：环岛状态、停车线状态、断路状态、元素索引等。
 * @param   void
 * @return  void
 */
void standard(void)
{
    Deal_W = XX;
    Deal_H = YY;
    stopline_flag = 0;
    stop_num = 0;
    Annulus_flag = 0;
    Annulus_num = 0;
    Annulus_Zero = 0;
    Annulus_Yaw = 0;
    disappear_flag = 0;
    disappear_num = 0;
    disappear_total = 3;
    elements_index = 0;
}
/**
 * @brief 取绝对值
 * @param   value 输入整数
 * @return  |value|
 */
int my_abs(int value)
{
    if(value >= 0) return value;
    else return -value;
}

/**
 * @brief 灰度直方图统计
 * @details 遍历处理区域（底部YM行）的灰度图像，统计每个灰度级的像素数量，
 *          同时记录实际最小/最大灰度值。结果存入 histogram[] 数组。
 *          注意：只统计 imgGray[IMG_H-YM ~ IMG_H-1] 范围（即处理区域）。
 * @param   void
 * @return  void（结果存入全局 histogram[]、minGray、maxGray）
 */
void getGrayscaleHistogram(void)
{
    minGray = 255;
    maxGray = 0;
    uint8 *ptr = &imgGray[IMG_H-YM][0];           // 处理区域起始地址
    uint8 *ptrEnd = &imgGray[IMG_H-1][_IMG_W] + 1; // 处理区域结束地址
    while (ptr != ptrEnd)
    {
        minGray = *ptr < minGray ? *ptr : minGray;
        maxGray = *ptr > maxGray ? *ptr : maxGray;
        ++histogram[*ptr++];
    }
}

/**
 * @brief 大津法（OSTU）计算二值化阈值
 * @details 使用最大类间方差法自动计算最优二值化阈值。
 *          算法原理：遍历所有可能的阈值，计算前景/背景的类间方差，
 *          选择使方差最大的阈值作为最优分割点。
 *          额外处理：
 *          - 灰度范围限制（minGrayscale~maxGrayscale）
 *          - 阈值上下限保护（minThreshold~maxThreshold）
 *          - 提前退出优化（方差开始下降时停止）
 * @param   void
 * @return  nowThreshold 计算得到的最优二值化阈值
 */
uint8 getOSTUThreshold(void)
{
    getGrayscaleHistogram();
    uint32_t sum = 0, valueSum = 0;
    uint64_t sigma = 0, maxSigma = 0;
    float w1 = 0, w2 = 0;
    int32_t u1 = 0, u2 = 0;
    uint8 min = 0, max = 255;

//    for (min = 0; histogram[min] == 0 && min < 255; ++min)
//        ;
//    for (max = 255; histogram[max] == 0 && max > 0; --max)
//        ;

    min = minGray;
    max = maxGray;
    if(max < minThreshold)     return minThreshold;
    if(min > maxThreshold)     return maxThreshold;

    min = min < minGrayscale ? minGrayscale : min;    //控制全局高曝光或低曝光
    max = max > maxGrayscale ? maxGrayscale : max;

    uint32_t lowSum[256] = {0};
    uint32_t lowValueSum[256] = {0};
    for (uint16_t i = min; i <= max; ++i)
    {
        sum += histogram[i];
        valueSum += histogram[i] * i;
        lowSum[i] = sum;
        lowValueSum[i] = valueSum;
    }
    for (uint16_t i = min; i < max + 1; ++i)
    {
        w1 = (float)lowSum[i] / sum;
        w2 = 1 - w1;
        u1 = (int32_t)(lowValueSum[i] / w1);
        u2 = (int32_t)((valueSum - lowValueSum[i]) / w2);
        sigma = (uint64_t)(w1 * w2 * (u1 - u2) * (u1 - u2));
        if (sigma >= maxSigma)
        {
            maxSigma = sigma;
            nowThreshold = i;
        }
        else
        {
            break;
        }
    }
    nowThreshold = nowThreshold < minThreshold ? minThreshold : nowThreshold;   //控制部分阈值不均匀
    nowThreshold = nowThreshold > maxThreshold ? maxThreshold : nowThreshold;
    previousThreshold = nowThreshold;
    return nowThreshold;
}
/**
 * @brief 大津法二值化处理（含腐蚀去噪和分区域阈值）
 * @details 完整的图像二值化流程：
 *          1. 初始化二值化图像（全黑）和白点统计数组
 *          2. 计算分区域阈值（近/中/远三段不同阈值）
 *          3. 对每个像素进行八邻域腐蚀去噪：
 *             - 检查8个邻域像素，统计白色/黑色邻居数
 *             - 只有当白色邻居>=8时才判定为白点（去噪）
 *             - 白点确定后，同时将其8邻域中接近阈值的点也设为白点（膨胀）
 *          4. 统计每行/每列的白点数量
 * @note    图像坐标系：imgOSTU[y][x] 中y为行号（0=底部），x为列号
 *          原始图像 imgGray 的行号是翻转的（_IMG_H-i）
 * @param   void
 * @return  void（结果存入全局 imgOSTU[]、white_num_row[]、white_num_col[]）
 */
void Get_imgOSTU(void)
{
    memset(imgOSTU, Black, sizeof(imgOSTU));//初始化黑白图全为黑色
    memset(white_num_row, 0, sizeof(white_num_row));//初始化每行白点数
    memset(white_num_col, 0, sizeof(white_num_col));//初始化每列白点数
    img_threshold_group[0]=nowThreshold + close_Threshold; //近景       //近景。 少加，能看清最近
    img_threshold_group[1]=nowThreshold - mid_Threshold;   //中景
    img_threshold_group[2]=nowThreshold - far_Threshold;   //远景       ///远景。，多降，能清晰识别更远
    int k = 0;
    int Loop[9][2] = {{0,1},{1,1},{1,0},{1,-1},{0,-1},{-1,-1},{-1,0},{-1,1}};
    for(int i = 0;i <= YY;i++)  //腐蚀去噪
    {
        if(i == YY/3)
        {
            k = 1;
        }
        else if(i == YY*2/3)
        {
            k = 2;
        }
        for(int j = 0;j <= XX;j++)
        {
          if(imgGray[_IMG_H-i][j] >= img_threshold_group[k])
            {
                int White_num = 0;
                int Black_num = 0;
                for(int k = 0;k <= 8;k++)
                {
                    int x = j + Loop[k][0];
                    int y = i + Loop[k][1];
                    if(x < 0 || x > XX || y < 0 || y > YY)
                    {
                        White_num++;
                    }
                    else if(imgOSTU[y][x] == White)
                    {
                        White_num = 8;
                        break;
                    }
                    else if(imgGray[_IMG_H-y][x] >= nowThreshold)
                    {
                        White_num++;
                    }
                    else
                    {
                        Black_num++;
                    }
                    if(Black_num >= 2)
                    {
                        break;
                    }
                }
                if(White_num >= 8)
                {
                    imgOSTU[i][j] = White;
                    white_num_row[i]++;  //计算每行白点数
                    white_num_col[j]++;  //计算每列白点数
                    for(int k = 0;k <= 8;k++)
                    {
                        int x = j + Loop[k][0];
                        int y = i + Loop[k][1];
                        if(x < 0 || x > XX || y < 0 || y > YY)
                        {
                        }
                        else if(imgOSTU[y][x] != White)
                        {
                            imgOSTU[y][x] = White;
                            white_num_row[y]++;  //计算每行白点数
                            white_num_col[x]++;  //计算每列白点数
                        }
                    }
                }
            }
        }
    }
}
/**
 * @brief 虚线区衔接弥补（补线处理）
 * @details 处理赛道中的虚线区域，通过以下步骤实现补线：
 *          1. 统计行/列白点的最大最小值，判断是否为特殊场景（全白列）
 *          2. 对每个白点，向四个方向（上下左右）标记周围黑点的方向编码
 *          3. 统计各方向组合的出现次数，识别断点类型
 *          4. 将断点补为 Make_up（粉色）或 LandR（橙色）
 *          5. 左右边界白点迁移（将靠近边界的白点迁移到边界上）
 *          6. 上边界白点迁移（将上方孤立白点迁移到处理区域上边界）
 *          7. 绘制四周黑色边框（封闭处理区域）
 * @return  0 = 特殊场景（全白列），直接返回
 *          正常 = 执行完整补线流程
 */
uint8 Dashedline_Makeup(void)
{
/*******************************最长最短白行列统计****************************************/
    white_row_max[0] = 0;
    white_row_min[0] = XX;
    white_col_max[0] = 0;
    white_col_min[0] = XX;
    for(uint8 i = Deal_Bottom; i <= Deal_Top; i++)
    {
        if(white_num_row[i] > white_row_max[0])
        {
            white_row_max[0] = white_num_row[i]; //行白点最大
            white_row_max[1] = i;                //最大白点行
        }
        else if(white_num_row[i] < white_row_min[0])
        {
            white_row_min[0] = white_num_row[i]; //行白点最小
            white_row_min[1] = i;                //最小白点行
        }
    }
    for(uint8 i = Deal_Left;i <= Deal_Right;i++)
    {
        if(white_num_col[i] > white_col_max[0])
        {
            white_col_max[0] = white_num_col[i]; //列白点最大
            white_col_max[1] = i;                //白点最大列
        }
        else if(white_num_col[i] < white_col_min[0])
        {
            white_col_min[0] = white_num_col[i]; //列白点最小
            white_col_min[1] = i;                //白点最小列
        }
    }
    if(white_col_max[0] >= YY && white_row_max[0] < white_width[0])
    {
    //绘制四周黑色边框
    for(uint8 x = 0;x<=XX;x++ )
    {
        if(imgOSTU[Deal_Bottom-1][x] == White || imgOSTU[Deal_Bottom-2][x] == White )
        {
            imgOSTU[Deal_Bottom][x] = White;
        }
        imgOSTU[Deal_Bottom-1][x] = Black;
        imgOSTU[Deal_Bottom-2][x] = Black;

        if(imgOSTU[Deal_Top+1][x] == White || imgOSTU[Deal_Top+2][x] == White )
        {
            imgOSTU[Deal_Top][x] = White;
        }
        imgOSTU[Deal_Top+1][x] = Black;
        imgOSTU[Deal_Top+2][x] = Black;
    }
    for(uint8 y = 0;y<=Deal_Top;y++ )
    {
        if(imgOSTU[y][Deal_Left-1] == White || imgOSTU[y][Deal_Left-2] == White )
        {
            imgOSTU[y][Deal_Left] = White;
        }
        imgOSTU[y][Deal_Left-1] = Black;
        imgOSTU[y][Deal_Left-2] = Black;

        if(imgOSTU[y][Deal_Right+1] == White || imgOSTU[y][Deal_Right+2] == White )
        {
            imgOSTU[y][Deal_Right] = White;
        }
        imgOSTU[y][Deal_Right+1] = Black;
        imgOSTU[y][Deal_Right+2] = Black;
    }
        return 0;
    }
/******************************************************************************/
    memset(imgTran, Black, sizeof(imgTran));//初始化黑白图全为黑色
/**************************imgTran断点统计**************************************/
    for(uint8 i = 0;i <= YY;i++)
    {
        for(uint8 j = 0;j <= XX;j++)
        {
            if(imgOSTU[i][j] == White)
            {
                int w_start = j-2*white_width[i] < 0 ? 0 :j-2*white_width[i];
                int w_end = j+2*white_width[i] > XX ? XX :j+2*white_width[i];
                if(j!=XX)
                {
                    for(int w = j+1;w <= w_end;w++)
                    {
                        if(imgOSTU[i][w] == Black)
                        {
                                imgTran[i][w] += Goto_R;

                        }
                        else
                        {
                            break;
                        }

//                        if(imgOSTU[i][w] == Black)
//                        {
//                            if(imgTran[i][w] == Goto_T)
//                            {
//                                imgTran[i][w] = RT;
//                            }
//                            else
//                            {
//                                imgTran[i][w] = Goto_R;
//                            }
//                        }
//                        else
//                        {
//                            break;
//                        }

                    }
                }
                if(j!=0)
                {
                    for(int w = j-1;w >= w_start;w--)
                    {
                        if(imgOSTU[i][w] == Black)
                        {
                                imgTran[i][w] += Goto_L;

                        }
                        else
                        {
                            break;
                        }
//                        if(imgOSTU[i][w] == Black)
//                        {
//                            if(imgTran[i][w] == Goto_R)
//                            {
//                                imgTran[i][w] = LR;
//                            }
//                            else if(imgTran[i][w] == RT)
//                            {
//                                for(int y = i;y >= 0;y--)
//                                {
//                                    if(imgOSTU[y][w] == Black)
//                                    {
//                                        imgTran[y][w] = LRT;
//                                    }
//                                    else
//                                    {
//                                        break;
//                                    }
//                                }
//                            }
//                            else
//                            {
//                                imgTran[i][w] = Goto_L;
//                            }
//                        }
//                        else
//                        {
//                            break;
//                        }

                    }
                }
                int h_start = i-Length_5cm[i] < 0 ? 0 : i-Length_5cm[i];
                int h_end = i+Length_5cm[i] > YY ? YY : i+Length_5cm[i];
                if(i!=YY)
                {
                    for(int h = i+1;h <= h_end;h++)
                    {
                        if(imgOSTU[h][j] == Black)
                        {
                            imgTran[h][j] += Goto_U;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                if(i!=0)
                {int count = Length_5cm[i];
                    for(int h = i-1;h >= h_start;h--,count--)
                    {
                        if(imgOSTU[h][j] == Black)
                        {
                            imgTran[h][j] += Goto_D;
                        }
                        else
                        {
                            break;
                        }
//                        if(imgOSTU[h][j] == Black)
//                        {
//                            if(imgTran[h][j] == LR || imgTran[h][j] == LRT)
//                            {
//                                for(int y = h;y <= i-1;y++)
//                                {
//                                    imgTran[y][j]=LRD;
//                                }
//                                for(int y = h-1;y >= 0;y--)
//                                {
//                                    if(imgTran[y][j] == LR || imgTran[y][j] == LRT)
//                                    {
//                                        imgTran[y][j]=LRD;
//                                    }
//                                    else
//                                    {
//                                        break;
//                                    }
//                                }
//                                break;
//                            }
//                            else
//                            {
//                                imgTran[h][j]=Goto_D;
//                            }
//                        }
//                        else
//                        {
//                            break;
//                        }
                    }
                }

            }
        }
    }
/**************************断路 Make_up**************************************/
    memset(EXTERN_sum, 0, sizeof(EXTERN_sum));
    memset(EXTERN_ROW, 0, sizeof(EXTERN_ROW));

    for(uint8 i = 0;i <= YY;i++)
    {
        for(uint8 j = 0;j <= XX;j++)
       {
            if(imgOSTU[i][j] == Black && imgTran[i][j] >= 1)//(Length_5cm[i]+white_width[i])/4)
            {
                if(imgTran[i][j] == ULR || imgTran[i][j] == DLR || imgTran[i][j] == UDLR)
                {
                imgOSTU[i][j] = LandR;
                }
                else
                {
                imgOSTU[i][j] = Make_up;
                }
                int Combination = (int)imgTran[i][j];
                EXTERN_sum[Combination]++;
                EXTERN_ROW[Combination][i]++;

            }
        }
    }
/**************************左右边界白点迁移**************************************/
    EXTERN_L = 0;
    EXTERN_R = 0;
    uint8 l_white = 0,r_white = 0;
    uint8 l_end = Deal_Left,r_end = Deal_Right;
    for(uint8 k = 0;k <= (int)white_width[Deal_Top];k++) //左边界位移大小计算
    {
        l_white += white_num_col[0+k];
        if(l_white)
        {
            l_end = 0+k;
            if(l_white >= 25)
            {
                break;
            }
        }
    }
    for(uint8 k = 0;k <= (int)white_width[Deal_Top];k++)  //右边界位移大小计算
    {
        r_white += white_num_col[XX-k];
        if(r_white)
        {
            r_end = XX-k;
            if(r_white >= 25)
            {
                break;
            }
        }
    }
    
    for(uint8 y = Deal_Bottom;y<= YY;y++)  //左边界白点迁移
    {
        for(uint8 k = Deal_Left;k <= l_end;k++)
        {
            if(imgOSTU[y][k] == White)
            {
                imgOSTU[y][Deal_Left] = White;
                EXTERN_L++;
                white_num_row[y]++;  //计算每行白点数
                white_num_col[Deal_Left]++;
                break;
            }
            else if(imgOSTU[y][k] == Black)
            {
                break;
            }
        }
    }
    for(uint8 y = Deal_Bottom;y<= YY;y++)   //右边界白点迁移
    {
        for(uint8 k = Deal_Right;k >= r_end;k--)
        {
            if(imgOSTU[y][k] == White)
            {
                imgOSTU[y][Deal_Right] = White;
                EXTERN_R++;
                white_num_row[y]++;  //计算每行白点数
                white_num_col[Deal_Right]++;
                break;
            }
            else if(imgOSTU[y][k] == Black)
            {
                break;
            }
        }
    }
/**************************上边界白点迁移**************************************/
    if(!Annulus_flag)
    {
    uint8 t_end = YY,b_end = 0;
    uint8 White_Top[XX] = {0};
    for(uint8 x = Deal_Left;x<= Deal_Right;x++) //统计上边界迁移白点数
    {
        for(uint8 y = Deal_Top;y <= t_end;y++)
        {
            if(imgOSTU[y][x] == White)
            {
                White_Top[x] = 1;
                break;
            }
            else if(imgOSTU[y][x] == Black)
            {
                White_Top[x] = 0;
                break;
            }
        }
    }
    for(uint8 x = Deal_Left;x<= Deal_Right;x++)  //删除重复区块
    {
       if(imgOSTU[Deal_Top][x] == White && White_Top[x] == 1)
       {
           White_Top[x] = 0;
           for(int w = x+1;w <= Deal_Right;w++)
           {
             if(White_Top[w] == 1)
             {
                White_Top[w] = 0;
             }
             else
             {
                 break;
             }
           }
           for(int w = x-1;w >= Deal_Left;w--)
           {
               if(White_Top[w] == 1)
               {
                  White_Top[w] = 0;
               }
               else
               {
                   break;
               }
           }
       }
    }
    for(uint8 x = Deal_Left;x<= Deal_Right;x++)    //迁移上边界白点
    {
        if(White_Top[x] == 1)
        {
            imgOSTU[Deal_Top-0][x] = White;
            imgOSTU[Deal_Top-1][x] = White;
            imgOSTU[Deal_Top-2][x] = White;
            white_num_row[Deal_Top-0]++;  //计算每行白点数
            white_num_row[Deal_Top-1]++;  //计算每行白点数
            white_num_row[Deal_Top-2]++;  //计算每行白点数
            white_num_col[x]++;
        }
    }
    }

    //绘制四周黑色边框
    for(uint8 x = 0;x<=XX;x++ )
    {
        if(imgOSTU[Deal_Bottom-1][x] == White || imgOSTU[Deal_Bottom-2][x] == White )
        {
            imgOSTU[Deal_Bottom][x] = White;
        }
        imgOSTU[Deal_Bottom-1][x] = Black;
        imgOSTU[Deal_Bottom-2][x] = Black;

        if(imgOSTU[Deal_Top+1][x] == White || imgOSTU[Deal_Top+2][x] == White )
        {
            imgOSTU[Deal_Top][x] = White;
        }
        imgOSTU[Deal_Top+1][x] = Black;
        imgOSTU[Deal_Top+2][x] = Black;
    }
    for(uint8 y = 0;y<=Deal_Top;y++ )
    {
        if(imgOSTU[y][Deal_Left-1] == White || imgOSTU[y][Deal_Left-2] == White )
        {
            imgOSTU[y][Deal_Left] = White;
        }
        imgOSTU[y][Deal_Left-1] = Black;
        imgOSTU[y][Deal_Left-2] = Black;

        if(imgOSTU[y][Deal_Right+1] == White || imgOSTU[y][Deal_Right+2] == White )
        {
            imgOSTU[y][Deal_Right] = White;
        }
        imgOSTU[y][Deal_Right+1] = Black;
        imgOSTU[y][Deal_Right+2] = Black;
    }
}
/**
 * @brief 寻找左右边界起点
 * @details 从图像底部向上搜索，找到左右边界的起始点。
 *          搜索策略：
 *          1. 从 Deal_Bottom 开始向上扫描30行
 *          2. 找到连续两行白点数>=5的行作为起始行
 *          3. 在该行从左向右找第一个白→黑跳变点（左边界起点）
 *          4. 在该行从右向左找第一个黑→白跳变点（右边界起点）
 *          5. 统计底部丢失线（Lost_line），用于后续边缘特征判断
 * @return  1 = 成功找到左右起点（start_point_l, start_point_r, start_center_x 已赋值）
 *          0 = 未找到有效起点
 */
uint8 get_start_point(void)
{
    b_lost_tip =0;  //底端边界点初始化
    start_center_y = 0;  //起始行数初始化
    uint8 l_found = 0,r_found = 0;//清零
    uint32 l_point = 0,r_point = 0;
    for(uint8 i = Deal_Bottom;i <= Deal_Bottom + 30;i++)  //从下往上寻找可寻边界行数
    {
        if(white_num_row[i] >= 5 && white_num_row[i+1] >= 5) //白点数大于5，开始寻找边界
        {
            start_center_y = i;
            //从左向右，先找黑白跳变点
            for (uint8 i = 0; i < XX-1; i++)
            {
                if ((imgOSTU[start_center_y][i+1] == Make_up || imgOSTU[start_center_y][i+1] == White)&& imgOSTU[start_center_y][i] == Black)
                {//找到左边起点
                    l_point = i;
                    l_found = 1;
                    break;
                }
            }
            //从右向左，先找黑白跳变点
            for (uint8 i = XX; i > 0+1; i--)
            {
                if ((imgOSTU[start_center_y][i-1] == Make_up || imgOSTU[start_center_y][i-1] == White)&& imgOSTU[start_center_y][i] == Black)
                {//找到右边起点
                    r_point = i;
                    r_found = 1;
                    break;
                }
            }
            if(r_found && l_found)
            {
                break;
            }
        }
    }
    //如果左右边界之间存在黑色区块,进行处理判断，将小区域块删除
//    if(r_point - l_point - 1 > white_num_row[start_center_y])
//    {
//        uint8 white_num_L = 0,white_num_R = 0;
//        //获取左右区域10*10范围白色数目
//        for(uint8 i = l_point;i < l_point + 10 && i <= Deal_Right;i++)
//        {
//            for(uint8 j = start_center_y;j < start_center_y + 10 ;j++)
//            {
//                if (imgOSTU[j][i] == White)
//                {
//                   white_num_L++;
//                }
//            }
//        }
//        for(uint8 i = r_point;i > r_point - 10 && i >= Deal_Left;i--)
//        {
//            for(uint8 j = start_center_y;j < start_center_y + 10 ;j++)
//            {
//                if (imgOSTU[j][i] == White)
//                {
//                   white_num_R++;
//                }
//            }
//        }
//        //数目较少位置删除处理
//        if(white_num_L > 50 && white_num_R < 10)
//        {
//            r_found = 0;
//            for (uint8 i = l_point; i < r_point; i++)
//            {
//                if (imgOSTU[start_center_y][i] == White && imgOSTU[start_center_y][i+1] == Black)
//                {
//                    r_point = i+1;
//                    r_found = 1;
//                    break;
//                }
//            }
//        }
//        else if(white_num_R > 50 && white_num_L < 10)
//        {
//            l_found = 0;
//            for (uint8 i = r_point; i > l_point; i--)
//            {
//                if (imgOSTU[start_center_y][i-1] == Black && imgOSTU[start_center_y][i] == White)
//                {
//                    l_point = i-1;
//                    l_found = 1;
//                    break;
//                }
//            }
//        }
//    }
        if(l_found && r_found)//找到左右起点
        {
             //记录b_lost_tip
            for (uint8 i = l_point; i <= r_point; i++)
            {
                if (imgOSTU[start_center_y][i] == White)
                {
                    b_lost_tip++;
                    imgOSTU[Lost_Bottom][i] = Lost_line;
                }
                else if (imgOSTU[start_center_y + 1][i] == White )
                {
                    b_lost_tip++;
                    imgOSTU[Lost_Bottom][i] = Lost_line;
                }
                else if (imgOSTU[Deal_Bottom][i] == White )
                {
                    b_lost_tip++;
                    imgOSTU[Lost_Bottom][i] = Lost_line;
                }
            }
            //起点位置记录
            start_center_x = (l_point+r_point)/2;
            start_point_l = l_point;
            start_point_r = r_point;
            return 1;
        }
        else                     //未找到起点
        {
            return 0;
        }
}


/*============================================================================
 *                    八邻域巡线变量定义
 *============================================================================*/

/* 左边界线数据 */
int points_l[(uint16)USE_num][2] = { { 0 } }; // 左边界点坐标 [i][0]=X, [i][1]=Y
float dir_l[(uint16)USE_num] = { 0 };         // 左边界生长方向（0~7）
uint32 l_data_statics = 0;                     // 左边界有效点数量

/* 右边界线数据 */
int points_r[(uint16)USE_num][2] = { { 0 } }; // 右边界点坐标
float dir_r[(uint16)USE_num] = { 0 };         // 右边界生长方向
uint32 r_data_statics = 0;                     // 右边界有效点数量

/* 极值点记录 */
uint8 hightest = 0;     // 巡线最高点Y坐标
uint16 leftmost[2] = {0};  // 最左点 [0]=X, [1]=Y
uint16 rightmost[2] = {0}; // 最右点
uint16 topmost[2] = {0};   // 最顶点

/*
 * 八邻域巡线原理：
 *   从底部起点开始，沿黑白边界逆时针（左线）或顺时针（右线）生长。
 *   每一步检查当前中心点的8个邻居，找到从黑到白的跳变点作为下一个边界点。
 *
 *   邻域编号（逆时针，左线用）：
 *     3  4  5       方向定义：
 *     2  ·  6       seeds_l[i] = {dx, dy}
 *     1  0  7       i=0: 下(0,-1)  i=1: 左下(-1,-1)  i=2: 左(-1,0)
 *                   i=3: 左上(-1,+1)  i=4: 上(0,+1)  i=5: 右上(+1,+1)
 *                   i=6: 右(+1,0)  i=7: 右下(+1,-1)
 *
 *   邻域编号（顺时针，右线用）：
 *     5  4  3
 *     6  ·  2
 *     7  0  1
 */

/* 左线八邻域变量 */
int center_point_l[2] = { 0 };               // 左线当前中心点坐标
uint8 search_filds_l[8][2] = { { 0 } };      // 左线8个邻居坐标
uint8 index_l = 0;                            // 左线候选点索引
uint8 temp_l[8][2] = { { 0 } };              // 左线候选点临时存储
int8_t seeds_l[8][2] = { {0,-1},{-1,-1},{-1,0},{-1,1},{0,1},{1,1},{1,0},{1,-1} }; // 左线生长种子（逆时针）

/* 右线八邻域变量 */
int center_point_r[2] = { 0 };               // 右线当前中心点坐标
uint8 search_filds_r[8][2] = { { 0 } };      // 右线8个邻居坐标
uint8 index_r = 0;                            // 右线候选点索引
uint8 temp_r[8][2] = { { 0 } };              // 右线候选点临时存储
int8_t seeds_r[8][2] = { {0,-1},{1,-1},{1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1} }; // 右线生长种子（顺时针）

/**
 * @brief 八邻域探索左右边界线
 * @details 从给定起点开始，使用八邻域法同时追踪左右边界线。
 *          追踪过程：
 *          1. 计算当前中心点的8个邻居坐标
 *          2. 找到从黑(Black/Lost_line)到非黑的跳变点
 *          3. 选择Y值最大的候选点（向高处生长）
 *          4. 记录边界点坐标和生长方向
 *          5. 检测边界丢失（到达图像边缘）并标记 Lost_line
 *          6. 更新极值点（最高、最左、最右）
 *          退出条件：
 *          - 左右边界相遇（距离<=1像素）
 *          - 回到起点（形成闭环）
 *          - 连续3步在同一位置（死循环）
 *          - 达到最大迭代次数（USE_num）
 * @param   start_l_x, start_l_y  左边界起点坐标
 * @param   start_r_x, start_r_y  右边界起点坐标
 * @return  void（结果存入 points_l[]、points_r[]、imgOSTU[]）
 */
uint8 search_l_r(uint8 start_l_x, uint8 start_l_y, uint8 start_r_x, uint8 start_r_y)
{
  //初始化巡线最高处
    hightest = 0;
    leftmost[0] =Deal_Right;
    rightmost[0] =Deal_Left;
    topmost[1] =0;
  //左右丢失点初始化
    l_lost_tip = 0;
    r_lost_tip = 0;
    t_lost_tip = 0;
  //初始化左右索引
    l_data_statics = 0;
    r_data_statics = 0;
  //更新中心点
    center_point_l[0] = start_l_x;//x
    center_point_l[1] = start_l_y;//y
    center_point_r[0] = start_r_x;//x
    center_point_r[1] = start_r_y;//y
    points_l[l_data_statics][0] = center_point_l[0];//x
    points_l[l_data_statics][1] = center_point_l[1];//y
    points_r[r_data_statics][0] = center_point_r[0];//x
    points_r[r_data_statics][1] = center_point_r[1];//y
    uint32 break_flag = USE_num; //总循环数
  while (break_flag--)
    {
        //左边8F初始化
        for (uint8 i = 0; i < 8; i++)//传递8F坐标
        {
            search_filds_l[i][0] = center_point_l[0] + seeds_l[i][0];//x
            search_filds_l[i][1] = center_point_l[1] + seeds_l[i][1];//y
        }
        //中心坐标点填充到边线数组内
        //右边8F初始化
        for (uint8 i = 0; i < 8; i++)//传递8F坐标
        {
            search_filds_r[i][0] = center_point_r[0] + seeds_r[i][0];//x
            search_filds_r[i][1] = center_point_r[1] + seeds_r[i][1];//y
        }
        //中心坐标点填充到边线数组内
        //左边生长判断
        l_data_statics++;//索引加一
        index_l = 0;//先清零，后使用
        for (uint8 i = 0; i < 8; i++)
        {
            temp_l[i][0] = 0;//先清零，后使用
            temp_l[i][1] = 0;//先清零，后使用
        }
        for (uint8 i = 0; i < 8; i++)
        {
            if ((imgOSTU[search_filds_l[i][1]][search_filds_l[i][0]] == Black || imgOSTU[search_filds_l[i][1]][search_filds_l[i][0]] == Lost_line)
                && (imgOSTU[search_filds_l[(i + 1) & 7][1]][search_filds_l[(i + 1) & 7][0]] != Black && imgOSTU[search_filds_l[(i + 1) & 7][1]][search_filds_l[(i + 1) & 7][0]] != Lost_line))   //生长种子由黑变白位置点
            {
                temp_l[index_l][0] = search_filds_l[(i)][0];
                temp_l[index_l][1] = search_filds_l[(i)][1];
                index_l++;
                dir_l[l_data_statics - 1] = i;//记录生长方向，数组索引比边界少一
            }
            if (index_l)
            {
                //更新坐标点
                center_point_l[0] = temp_l[0][0];//x
                center_point_l[1] = temp_l[0][1];//y
                for (uint8 j = 0; j < index_l; j++)
                {
                    if (center_point_l[1] < temp_l[j][1])//中心点向高处生长
                    {
                        center_point_l[0] = temp_l[j][0];//x
                        center_point_l[1] = temp_l[j][1];//y
                        dir_l[l_data_statics - 1] = i;//记录生长方向
                    }
                }
            }
            if(center_point_l[0] == Deal_Left -1
                    && imgOSTU[center_point_l[1]][Deal_Left] == White
                    && imgOSTU[center_point_l[1]][Deal_Left-2] != Lost_line)
            {
                l_lost_tip++;
                imgOSTU[center_point_l[1]][Lost_Left] = Lost_line;
            }//l_lost_tip记录
            else if(center_point_l[0] == Deal_Right + 1
                    && imgOSTU[center_point_l[1]][Deal_Right] == White
                    && imgOSTU[center_point_l[1]][Lost_Right] != Lost_line)
            {
                r_lost_tip++;
                imgOSTU[center_point_l[1]][Lost_Right] = Lost_line;
            }
            else if(center_point_l[1] == Deal_Top + 1
                    && imgOSTU[Deal_Top][center_point_l[0]] == White
                    && imgOSTU[Deal_Top + 2][center_point_l[0]] != Lost_line)
            {
                t_lost_tip++;
                imgOSTU[Lost_Top][center_point_l[0]] = Lost_line;
            }//t_lost_tip记录
            if(center_point_l[1] > hightest)
            {
                hightest = center_point_l[1];
                topmost[0] =center_point_l[0];
                topmost[1] =center_point_l[1];
            }//更新记录最高点
            if(center_point_l[1] > hightest)
            {
                hightest = center_point_l[1];
                topmost[0] = center_point_l[0];
                topmost[1] = center_point_l[1];
            }//更新记录最高点
            if(center_point_l[0] < leftmost[0])
            {
              leftmost[0] = center_point_l[0];
              leftmost[1] = center_point_l[1];
            }//更新记录最左点
        }
        //右边判断生长判断
        r_data_statics++;//索引加一
        index_r = 0;//先清零，后使用
        for (uint8 i = 0; i < 8; i++)
        {
            temp_r[i][0] = 0;//先清零，后使用
            temp_r[i][1] = 0;//先清零，后使用
        }
        for (uint8 i = 0; i < 8; i++)
        {
            if ((imgOSTU[search_filds_r[i][1]][search_filds_r[i][0]] == Black || imgOSTU[search_filds_r[i][1]][search_filds_r[i][0]] == Lost_line)
                && (imgOSTU[search_filds_r[(i + 1) & 7][1]][search_filds_r[(i + 1) & 7][0]] != Black && imgOSTU[search_filds_r[(i + 1) & 7][1]][search_filds_r[(i + 1) & 7][0]] != Lost_line))
            {
                temp_r[index_r][0] = search_filds_r[(i)][0];
                temp_r[index_r][1] = search_filds_r[(i)][1];
                index_r++;//索引加一
                dir_r[r_data_statics - 1] = i;//记录生长方向
            }
            if (index_r)
            {
                //更新坐标点
                center_point_r[0] = temp_r[0][0];//x
                center_point_r[1] = temp_r[0][1];//y
                for (uint8 j = 0; j < index_r; j++)  //中心点向高处生长
                {
                    if (center_point_r[1] < temp_r[j][1])
                    {
                        center_point_r[0] = temp_r[j][0];//x
                        center_point_r[1] = temp_r[j][1];//y
                        dir_l[l_data_statics - 1] = i;//记录生长方向
                    }
                }
            }

            if(center_point_r[0] == Deal_Right + 1
                    && imgOSTU[center_point_r[1]][Deal_Right] == White
                    && imgOSTU[center_point_r[1]][Lost_Right] != Lost_line)
            {
                r_lost_tip++;
                imgOSTU[center_point_r[1]][Lost_Right] = Lost_line;
            }//r_lost_tip记录
            else if(center_point_r[0] == Deal_Left - 1
                    && imgOSTU[center_point_r[1]][Deal_Left] == White
                    && imgOSTU[center_point_r[1]][Lost_Left] != Lost_line)
            {
                l_lost_tip++;
                imgOSTU[center_point_r[1]][Lost_Left] = Lost_line;
            }//r_lost_tip记录
            else if(center_point_r[1] == Deal_Top + 1
                    && imgOSTU[Deal_Top][center_point_r[0]] == White
                    && imgOSTU[Lost_Top][center_point_r[0]] != Lost_line)
            {
                t_lost_tip++;
                imgOSTU[Lost_Top][center_point_r[0]] = Lost_line;
            }//t_lost_tip记录
            if(center_point_r[1] > hightest)
            {
                hightest = center_point_r[1];
                topmost[0] =center_point_r[0];
                topmost[1] =center_point_r[1];
            }//更新记录最高点
            if(center_point_r[0] > rightmost[0])
            {
              rightmost[0] = center_point_r[0];
              rightmost[1] = center_point_r[1];
            }//更新记录最右点
        }
        if(hightest == Deal_Top -1)
        {
            for(uint8 i = Deal_Left;i <= Deal_Right;i++)
            {
                imgOSTU[Lost_Top][i] = Black;
                imgOSTU[Lost_Top-1][i] = Black;
            }
        }
        //储存边界数组
        points_l[l_data_statics][0] = center_point_l[0];//x
        points_l[l_data_statics][1] = center_point_l[1];//y
        points_r[r_data_statics][0] = center_point_r[0];//x
        points_r[r_data_statics][1] = center_point_r[1];//y

        if ((points_r[r_data_statics][0]== points_r[r_data_statics-1][0]&& points_r[r_data_statics][0] == points_r[r_data_statics - 2][0]
            && points_r[r_data_statics][1] == points_r[r_data_statics - 1][1] && points_r[r_data_statics][1] == points_r[r_data_statics - 2][1])
            ||(points_l[l_data_statics-1][0] == points_l[l_data_statics - 2][0] && points_l[l_data_statics-1][0] == points_l[l_data_statics - 3][0]
                && points_l[l_data_statics-1][1] == points_l[l_data_statics - 2][1] && points_l[l_data_statics-1][1] == points_l[l_data_statics - 3][1]))
        {
         //三次进入同一个点，退出
            break;
        }

        if (my_abs(points_r[r_data_statics][0] - points_l[l_data_statics][0]) <= 1
            && my_abs(points_r[r_data_statics][1] - points_l[l_data_statics][1]) <= 1 //左右相遇，相遇距离可调
            )
        {
            //左右相遇退出
            break;
        }
        if ((l_data_statics > YY/2 && my_abs(start_l_x - points_l[l_data_statics][0]) <= 1 && my_abs(start_l_y - points_l[l_data_statics][1]) <= 1) ||
            (r_data_statics > YY/2 && my_abs(start_r_x - points_r[r_data_statics][0]) <= 1 && my_abs(start_r_y - points_r[r_data_statics][1]) <= 1))
        {
            //回到起点退出
            break;
        }
}
  //imgOSTU图像绘制左右边线
  for(int i = l_data_statics;i>0;i--)
  {
      imgOSTU[points_l[i][1]][points_l[i][0]] = Left_line;
  }
  for(int i = r_data_statics;i>0;i--)
  {
      imgOSTU[points_r[i][1]][points_r[i][0]] = Right_line;
  }
}

/**
 * @brief 获取四方位边缘丢失特征
 * @details 分析八邻域巡线产生的 Lost_line（紫色标记），提取四方向的边缘特征：
 *          - 底部(b)：b_lost_tip个丢失像素，b_lost_num块丢失区域（0/1/2）
 *          - 顶部(t)：t_lost_tip, t_lost_num
 *          - 左侧(l)：l_lost_tip, l_lost_num
 *          - 右侧(r)：r_lost_tip, r_lost_num
 *
 *          特征区域数量的意义：
 *          - 0块：该方向边界完整（实线）
 *          - 1块：该方向有一个丢失区（弯道/环岛入口）
 *          - 2块：该方向有两个丢失区（十字路口特征）
 *
 *          处理逻辑：
 *          1. 检测各方向的 Lost_line 连续段
 *          2. 过滤掉长度不足的杂点（<length像素）
 *          3. 处理角落重叠（底端与左右相连时仅保留底端）
 *          4. 记录每块丢失区域的中心坐标
 *          5. 特殊情况：无丢失且最高点到达顶部时，补录丢失特征
 * @param   length 判断丢失区域的最小长度阈值（像素）
 * @return  void（结果存入 b_lost_num, t_lost_num, l_lost_num, r_lost_num, *_center[]）
 */
void Get_lost_tip(uint8 length)
{
    dis_Solidline = 0;
    //边缘特征的区域数量初始化
    b_lost_num = 0;
    t_lost_num = 0;
    l_lost_num = 0;
    r_lost_num = 0;
    //边缘特征的中心点初始化
    memset(b_center, 0, sizeof(b_center));
    memset(l_center, 0, sizeof(l_center));
    memset(r_center, 0, sizeof(r_center));
    memset(t_center, 0, sizeof(t_center));
    /***********获取底部边缘特征***********/
    if(b_lost_tip)
    {
        for(uint8  i = Deal_Left; i <= Deal_Right; i++)   //从左到右检测紫色丢失线
        {
            if(imgOSTU[Lost_Bottom][i] == Lost_line)      //检测到紫色丢失线
            {
                if(i <= Deal_Left + length || i >= Deal_Right - length  //在左右临界处检测到紫色丢失线
                   || (i + length <= XX && imgOSTU[Lost_Bottom][i+length] == Lost_line))  //紫色丢失线有一定长度
                {
                    for(uint8 k = i; k <= XX; k++)
                    {
                        if(imgOSTU[Lost_Bottom][k] == Black)  //判断黑色为紫色丢失线尽头
                        {
                        b_center[b_lost_num] = ((uint32)k-1-(uint32)i)/2+(uint32)i;
                        b_lost_num ++;  //底部区域数量记录
                        i = k;
                        break;
                        }
                    }
                }
                else  //零碎的杂点，删除处理
                {
                    for(uint8  k = i; k <= i + length; k++)
                    {
                        if(imgOSTU[Lost_Bottom][k] == Lost_line)
                        {
                        imgOSTU[Lost_Bottom][k] = Black;
                        b_lost_tip--;
                        }
                        else if(imgOSTU[Lost_Bottom][k] == Black)
                        {
                            break;
                        }
                    }
                }
            }
            if(b_lost_num == 2)
            {
                break;
            }
        }
    }
//    qout<<"b_lost_num"<<b_lost_num;
    /***********获取左部边缘特征***********/
    if(l_lost_tip)
    {
       for(uint8  i = Deal_Bottom; i <= Deal_Top; i++)  //从下到上检测紫色丢失线
       {
           if(imgOSTU[i][Lost_Left] == Lost_line)  //检测到紫色丢失线
           {
               if(i <= Deal_Bottom + length)  //左侧边缘块过低，考虑底部连续，仅保留底部
               {
                   for(uint8 j = Deal_Left; j <= Deal_Left + length; j++)
                   {
                     if(imgOSTU[Lost_Bottom][j] == Lost_line)
                     {
                        imgOSTU[Lost_Bottom][Lost_Left] = Lost_line;
                        for(; i <= Deal_Top/2; i++)
                        {
                           if(imgOSTU[i][Lost_Left] == Lost_line)
                           {
                               imgOSTU[i][Lost_Left] = Black;
                               l_lost_tip--;
                           }
                           else if(imgOSTU[i][Lost_Left] == Black)
                           {
                               break;
                           }
                        }
                        break;
                     }
                   }
               }
               else  //正常区域，进行记录
               {
                  uint8 k = i;
                  for(; i <= Lost_Top; i++)
                  {
                    if(imgOSTU[i][Lost_Left] == Black)
                    {
                        l_center[l_lost_num] = ((uint32)i-1-(uint32)k)/2+(uint32)k;
                        l_lost_num++;
                        break;
                    }
                  }
               }
           }
           if(l_lost_num == 2)
           {
               break;
           }
       }
    }
//    qout<<"l_lost_num"<<l_lost_num;
    /***********获取右部边缘特征***********/
    if(r_lost_tip)
    {
       for(uint8  i = Deal_Bottom; i <= Deal_Top; i++)  //从下到上检测紫色丢失线
       {
           if(imgOSTU[i][Lost_Right] == Lost_line)  //检测到紫色丢失线
           {
               if(i <= Deal_Bottom + length)  //右侧边缘块过低，考虑底部连续，仅保留底部
               {
                   for(uint8 j = Deal_Right; j >= Deal_Right - length; j--)
                   {
                     if(imgOSTU[Lost_Bottom][j] == Lost_line)
                     {
                        imgOSTU[Lost_Bottom][Lost_Right] = Lost_line;
                        for(; i <= Deal_Top/2; i++)
                        {
                           if(imgOSTU[i][Lost_Right] == Lost_line)
                           {
                               imgOSTU[i][Lost_Right] = Black;
                               r_lost_tip--;
                           }
                           else if(imgOSTU[i][Lost_Left] == Black)
                           {
                               break;
                           }
                        }
                     }
                     break;
                   }
               }
               else  //正常记录区域
               {
                   uint8 k = i;
                  for(;  i<= Lost_Top; i++)
                  {
                    if(imgOSTU[i][Deal_Right + 2] == Black)
                    {
                        r_center[r_lost_num] = ((uint32)i-1-(uint32)k)/2+(uint32)k;
                        r_lost_num++;
                        break;
                    }
                  }
               }
           }
           if(r_lost_num == 2)
           {
               break;
           }
       }
    }
//    qout<<"r_lost_num"<<r_lost_num;
    /***********获取顶部边缘特征***********/
    if(t_lost_tip)
    {
        uint16 center[5] = {0};
        uint16 num = 0;
        for(uint8  i = Deal_Left; i <= Deal_Right; i++)
        {
            if(imgOSTU[Lost_Top][i] == Lost_line)
            {
                if(i <= Deal_Left + length && l_lost_num)  //区域偏左，且存在左区域，考虑临界区域，保留顶端
                {
                    for(uint8 j = Deal_Top; j >= Deal_Top - length; j--)
                    {
                      if(imgOSTU[j][Lost_Left] == Lost_line)
                      {
                         imgOSTU[Lost_Top][Lost_Left] = Lost_line;
                         for(uint8 k = j; k >= YM/2;k--)
                         {
                             if(imgOSTU[k][Lost_Left] == Lost_line)
                             {
                               l_lost_tip--;
                               imgOSTU[k][Lost_Left] = Black;
                             }
                             else if(imgOSTU[k][Lost_Left] == Black)
                             {
                                 l_lost_num--;
                                 break;
                             }
                         }
                         for(uint8  k = i; k <= XX; k++)
                         {
                             if(imgOSTU[Lost_Top][k] == Black)
                             {
                                 center[num] = ((uint32)k-1-(uint32)i)/2+(uint32)i;
                                 num ++;
                                 i = k;
                                 break;
                             }
                         }
                         break;
                      }
                    }
                }
                else if(i+length >= XX || (i+length <= XX && imgOSTU[Lost_Top][i+length] == Lost_line))  //紫色区域有一定长度
                {
                    for(uint8  k = i; k <= XX; k++)
                    {
                        if(imgOSTU[Lost_Top][k] == Black)
                        {
                            center[num] = ((uint32)k-1-(uint32)i)/2+(uint32)i;
                            num ++;
                            i = k;
                            if(i >= Deal_Right - length && r_lost_num)  //区域偏右，且存在右区域，考虑临界区域，保留顶端
                            {
                                for(uint8 j = Deal_Top; j >= Deal_Top - length; j--)
                                {
                                  if(imgOSTU[j][Lost_Right] == Lost_line)
                                  {
                                     imgOSTU[Lost_Top][Lost_Right] = Lost_line;
                                     for(uint8 k = j; k >= YM/2;k--)
                                     {
                                         if(imgOSTU[k][Lost_Right] == Lost_line)
                                         {
                                           r_lost_tip--;
                                           imgOSTU[k][Lost_Right] = Black;
                                         }
                                         else if(imgOSTU[k][Lost_Right] == Black)
                                         {
                                             r_lost_num--;
                                             break;
                                         }
                                     }
                                     break;
                                  }
                                }
                            }
                            break;
                        }
                    }
                }
                else //零碎杂点，清除
                {
                    for(uint8  k = i; k <= i + length; k++)
                    {
                        if(imgOSTU[Deal_Top + 2][k] == Lost_line)
                        {
                          imgOSTU[Deal_Top + 2][k] = Black;
                          t_lost_tip--;
                        }
                        else if(imgOSTU[Deal_Top + 2][k] == Black)
                        {
                          break;
                        }
                    }
                }
            }
        }
        if(num > 2)
        {
            uint8 Get_center[2] = {0};
            for(uint8 k = 0;k <= Deal_W/2-1;k++)
            {
                for(uint8 i = 0;i<=4;i++)
                {
                    if(center[i] == Deal_W/2+k)
                    {
                        Get_center[t_lost_num] = Deal_W/2+k;
                        t_lost_num++;
                    }
                    if(center[i] == Deal_W/2-k)
                    {
                        Get_center[t_lost_num] = Deal_W/2-k;
                        t_lost_num++;
                    }
                }
                if(t_lost_num >= 2)
                {

                    t_center[0] = Get_center[0] < Get_center[1] ? Get_center[0] : Get_center[1];
                    t_center[1] = Get_center[0] > Get_center[1] ? Get_center[0] : Get_center[1];
                    break;
                }
            }
        }
        else
        {
            t_lost_num = num;
            t_center[0] = center[0];
            t_center[1] = center[1];
        }
    }
    else
    {
      if(l_lost_tip + r_lost_tip == 0 && hightest >= Deal_Top)
//           ((l_lost_tip && l_center[l_lost_num-1] <= hightest/2) ||
//            (r_lost_tip && r_center[r_lost_num-1] <= hightest/2) ||
//            (!l_lost_tip && !r_lost_tip)))
        {
           dis_Solidline = 1;
           int left_lost = 0,left_end = Deal_Top;
           int right_lost = 0,right_end = Deal_Top;
           for(int y = Deal_Top;y >= Deal_Bottom;y--)
           {

               if(imgOSTU[y][Deal_Left] == Left_line || imgOSTU[y][Deal_Left] == Right_line)
               {
                   for(int k = y;k >= Deal_Bottom;k--)
                   {
                       if(imgOSTU[k][Deal_Left] != Black)
                       {
                           left_lost ++;
                       }
                       else
                       {
                         if(k < Deal_H/2)
                         {
                           left_lost = 0;
                           break;
                         }
                         else
                         {
                           left_end = (y+k)/2;
                           break;
                         }
                       }
                   }
                   break;
               }
           }
           for(int y = Deal_Top;y >= Deal_Bottom;y--)
           {

               if(imgOSTU[y][Deal_Right] == Left_line || imgOSTU[y][Deal_Right] == Right_line)
               {
                   for(int k = y;k >= Deal_Bottom;k--)
                   {
                       if(imgOSTU[k][Deal_Right] != Black)
                       {
                           right_lost ++;
                       }
                       else
                       {
                         
                         if(k < Deal_H/2)
                         {
                           right_lost = 0;
                           break;
                         }
                         else
                         {
                           right_end = (y+k)/2;
                           break;
                         }
                       }
                   }
                   break;
               }
           }
           if(left_lost && !right_lost) //补录左端
           {
               imgOSTU[left_end-1][Lost_Left] = Lost_line;
               imgOSTU[left_end][Lost_Left] = Lost_line;
               imgOSTU[left_end+1][Lost_Left] = Lost_line;
               l_center[0] = left_end;
               l_lost_num = 1;
           }
           else if(right_lost && !left_lost) //补录右端
           {
               imgOSTU[right_end-1][Lost_Right] = Lost_line;
               imgOSTU[right_end][Lost_Right] = Lost_line;
               imgOSTU[right_end+1][Lost_Right] = Lost_line;
               r_center[0] = right_end;
               r_lost_num = 1;
           }
           else if(hightest >= Deal_Top)//补录顶端
           {
           int x_mid = topmost[0];
           int x_l = topmost[0];
           int x_r = topmost[0];
           int y_mid = topmost[1];
           for(uint8 y = Deal_Top;y >= Deal_Bottom;y--)
           {
               if(imgOSTU[y][x_mid] == White)
               {
                   y_mid = y;
                   break;
               }
           }
           for(uint8 x = x_mid;x >= Deal_Left;x--)
           {
               if(imgOSTU[y_mid][x] == White)
               {
                  imgOSTU[Lost_Top][x] = Lost_line;
               }
               else
               {
                   x_l = x;
                   break;
               }
           }
           for(uint8 x = x_mid;x <= Deal_Right;x++)
           {
               if(imgOSTU[y_mid][x] == White)
               {
                  imgOSTU[Lost_Top][x] = Lost_line;
               }
               else
               {
                   x_r = x;
                   break;
               }
           }
           t_lost_num = 1;
           t_center[0] = (x_l+x_r)/2;
           }
        }
    }
//    qout<<"t_lost_num"<<t_lost_num;
}
/**
 * @brief 获取中线起点（处理底部复杂区域）
 * @details 当底部有多个丢失区域时，需要选择合适的起点：
 *
 *          单区域（b_lost_num=1）且较宽（可能是停车线/十字）：
 *          - 统计丢失区域中白列的高度
 *          - 找出最高白列和最低白列
 *          - 删除低于2/3分割线的丢失点（保留较高的部分）
 *
 *          双区域（b_lost_num=2）：
 *          - 计算左右两个丢失区域的平均白列高度
 *          - 删除白列较矮的一块区域（保留更有意义的那块）
 *          - 最终只保留一块区域（b_lost_num=1）
 *
 *          最后重新计算起点中心X坐标。
 * @param   void
 * @return  void（更新 start_center_x, b_lost_num, b_lost_tip）
 */
void Get_start_center(void)
{
    //底部仅有一块特征区域，且较宽（一般为停车线或者十字处），则进行删除处理
    if(b_lost_tip >= white_width[Deal_Bottom] + 5 && b_lost_num == 1)
    {
        uint32 max = 0,min = Deal_Top,mid = Deal_Top/2;
        uint8 white_heigh[XM] = {0};
        //统计白列高度，并找出最高和最低白列
        for(uint8 i = start_point_l; i <= start_point_r; i++)
        {
            if(imgOSTU[Lost_Bottom][i] == Lost_line)
            {
                for(uint8 j = Deal_Bottom; j <= Deal_Top + 1; j++)
                {
                    if(imgOSTU[j][i] == Black || imgOSTU[j][i] == Left_line || imgOSTU[j][i] == Right_line)
                    {
                        white_heigh[i] = j;
                        max = max > j ? max : j;
                        min = min < j ? min : j;
                        break;
                    }
                }
            }
        }
        //计算分割白列高度
        if(b_lost_tip >= 2*white_width[Deal_Bottom])
        {
            mid = (max - min)*2/3 + min;
        }
        else
        {
            mid = (max + min)/2;
        }
//        qout<<"b_mid"<<mid;
        //删除低于分割白列的点
        for(uint8 i = start_point_l; i <= start_point_r; i++)
        {
            if(imgOSTU[Lost_Bottom][i] == Lost_line && white_heigh[i] < mid)
            {
                b_lost_tip--;
                imgOSTU[Lost_Bottom][i] = Black;
            }
        }
     }
    else if(b_lost_num == 2)
    {
        uint8 l_point = 0,r_point = XM;
        float l_num = 0,r_num = 0;
        float l_sum = 0,r_sum = 0;
        float l_average = 0,r_average = 0;
        //找到左右特征区域的起点，并计算平均白列高度
        for (uint8 i = start_point_l; i <= start_point_r; i++)
        {
            if (imgOSTU[Lost_Bottom][i] == Lost_line)
            {
                l_point = i;
                for (uint8 j = l_point; j <= Deal_Right; j++)
                {
                    if(imgOSTU[Lost_Bottom][j] == Lost_line)
                    {
                     for(uint8 k = Deal_Bottom + 1; k <= Deal_Top + 1; k++)
                     {
                         if(imgOSTU[k][j] == Left_line || imgOSTU[k][j] == Right_line)
                         {
                             l_num++;
                             l_sum = l_sum + k;
                             break;
                         }
                     }
                    }
                    else if(imgOSTU[Lost_Bottom][j] == Black)
                    {
                        break;
                    }
                }
                break;
            }
        }
        for (uint8 i = start_point_r; i >= start_point_l; i--)
        {
            if (imgOSTU[Lost_Bottom][i] == Lost_line)
            {
                r_point = i;
                for (uint8 j = i; j >= Deal_Left; j--)
                {
                    if(imgOSTU[Lost_Bottom][j] == Lost_line)
                    {
                     for(uint8 k = Deal_Bottom; k <= Deal_Top + 1; k++)
                     {
                         if(imgOSTU[k][j] == Black || imgOSTU[k][j] == Left_line || imgOSTU[k][j] == Right_line)
                         {
                             r_num++;
                             r_sum = r_sum + k;
                             break;
                         }
                     }
                    }
                    else if(imgOSTU[Lost_Bottom][j] == Black)
                    {
                        break;
                    }
                }
                break;
            }
        }
        //计算平均白列高度
        l_average = l_sum/l_num;
        r_average = r_sum/r_num;
//        qout<<"l_average"<<l_average;
//        qout<<"r_average"<<r_average;
        //比较判断，仅仅保留白列高的一块特征区域
        if(l_average >= r_average)
        {
            for (uint8 i = r_point; i >= l_point; i--)
            {
                if (imgOSTU[Lost_Bottom][i] == Lost_line)
                {
                    imgOSTU[Lost_Bottom][i] = Black;
                }
                else
                {
                    break;
                }
            }
        }
        else
        {
            for (uint8 i = l_point; i <= r_point; i++)
            {
                if (imgOSTU[Lost_Bottom][i] == Lost_line)
                {
                    imgOSTU[Lost_Bottom][i] = Black;
                }
                else
                {
                    break;
                }
            }
        }
        b_lost_num = 1;
    }
//    qout<<"b_lost_num"<<b_lost_num;
    //重新获取左右起点以及中心起点
    uint32 l_point = 0,r_point = 0;
    for (uint8 i = start_point_l; i < start_point_r; i++)
    {
        if (imgOSTU[Lost_Bottom][i] == Lost_line)
        {
            l_point = i;
            break;
        }
    }
    for (uint8 i = start_point_r; i > start_point_l; i--)
    {
        if (imgOSTU[Lost_Bottom][i] == Lost_line)
        {
            r_point = i;
            break;
        }
    }
    start_center_x = (l_point+r_point)/2;
//    qout<<"start_center_x"<<start_center_x;
}
/**
 * @brief 绘制顶端直线中线
 * @details 根据起点和顶部丢失区域，绘制直线中线。
 *
 *          单顶部区域（t_lost_num=1）：
 *          - 如果顶部丢失区域较宽（可能是十字/直角弯），先分割处理
 *          - 直接从起点到顶部丢失中心画直线
 *
 *          双顶部区域（t_lost_num=2）：
 *          - 分别计算到左右两个顶部中心的直线
 *          - 统计两条直线经过的黑色像素数
 *          - 选择黑色像素少的那条（即更贴近白区的直线）
 *          - 这种情况通常出现在十字路口或环岛入口
 *
 *          判断赛道类型：
 *          - 起点在最底部且黑点少 → 长直道 (straightlineL)
 *          - 起点在最底部且黑点多 → 短直道 (straightlineS)
 * @return  end_center_y 中线绘制的最高行号
 */
uint8 Get_top_straightline(void)
{
    uint8 Black_num = 0;
    /**********************单顶端区域处理**********************/
    if(t_lost_num == 1)
    {
        //底部仅有一块特征区域，且较宽（一般为停车线或者十字处，或者直角弯），则进行删除处理
        if((t_lost_tip >= white_width[Deal_Top] + 5 && t_lost_num == 1)||
            (t_lost_tip >= 3*white_width[Deal_Top]))
        {
            //统计顶端白列长度，进行分割
            uint32 max = 0,min = Deal_Top,mid = Deal_Top/2;
            uint8 white_low[XM] = {0};
            for(uint8 i = Deal_Left; i <= Deal_Right; i++)
            {
                if(imgOSTU[Lost_Top][i] == Lost_line)
                {
                    for(uint8 j = Deal_Top; j >= 0; j--)
                    {
                        if(imgOSTU[j][i] != White)
                        {
                            white_low[i] = j;
                            max = max > j ? max : j;
                            min = min < j ? min : j;
                            break;
                        }
                    }
                }
            }
            mid = (max + min)/2;
    //        qout<<"t_mid"<<mid;
            for(uint8 i = Deal_Left; i <= Deal_Right; i++)
            {
                if(imgOSTU[Lost_Top][i] == Lost_line && white_low[i] > mid)
                {
                    t_lost_tip--;
                    imgOSTU[Deal_Top + 2][i] = Black;
                }
            }
            //获取终点
            uint32 l_point = 0,r_point = 0;
            end_center_y = Deal_Top;
            for (uint8 i = Deal_Left; i <= Deal_Right; i++)
            {
                if (imgOSTU[Lost_Top][i] == Lost_line)
                {//找到左边起点
                    l_point = i;
                    break;
                }
            }
            //从右向左，先找黑白跳变点
            for (uint8 i = Deal_Right; i >= Deal_Left; i--)
            {
                if (imgOSTU[Lost_Top][i] == Lost_line)
                {//找到右边起点
                    r_point = i;//x
                    break;
                }
            }
            end_center_x = (l_point+r_point)/2;
        }
        else
        {
            end_center_y = Deal_Top;
            end_center_x = t_center[0];
        }
        //通过顶点起点拟合直线
        if(end_center_y <= start_center_y)
        {
          return 0;
        }
        float k = ((float)end_center_x - (float)start_center_x) / ((float)end_center_y - (float)start_center_y);
        for (uint8 i = start_center_y; i <= end_center_y; ++i)
        {
            mid_line[i] = (float)(start_center_x + k * (i - start_center_y));
            if(imgOSTU[i][(uint8)mid_line[i]] != White)
            {
                Black_num++;
            }
            imgOSTU[i][(uint8)mid_line[i]] = Control_line;
        }
    }
    /**********************双顶端区域进行直线判断**********************/
    else if(t_lost_num == 2)
    {
        end_center_y = Deal_Top;
        uint32 t_center_l = t_center[0],t_center_r = t_center[1]; //左右顶点初始化
//        qout<<"t_center_l"<<t_center_l;
//        qout<<"t_center_r"<<t_center_r;
        //判断左右连线之间黑色点数目
        uint8 left_line[YM] = {XM/2};
        uint8 right_line[YM] = {XM/2};
        uint8 Black_num_l = 0,Black_num_r = 0;
        float kl = ((float)t_center_l - (float)start_center_x) / ((float)end_center_y - (float)start_center_y);
        for (uint8 i = start_center_y; i <= end_center_y; ++i)
        {
            left_line[i] = (uint8)(start_center_x + kl * (i - start_center_y));
            if(imgOSTU[i][left_line[i]] != White)
            {
                Black_num_l++;
            }
            else
            {
              imgOSTU[i][left_line[i]] = Judge_line;
            }
        }
        float kr = (float)((float)t_center_r - (float)start_center_x) / ((float)end_center_y - (float)start_center_y);
        for (uint8 i = start_center_y; i <= end_center_y; ++i)
        {
            right_line[i] = (uint8)(start_center_x + kr * (i - start_center_y));
            if(imgOSTU[i][right_line[i]] != White)
            {
                Black_num_r++;
            }
            else
            {
              imgOSTU[i][right_line[i]] = Judge_line;
            }
        }
        //        qout<<"Black_num_l"<<Black_num_l;
        //        qout<<"Black_num_r"<<Black_num_r;
        //通过比较黑色点数，判断引用哪条中线
        if(Black_num_l > Black_num_r)
        {
           end_center_x  = t_center_r;
           Black_num = Black_num_r;
           for (uint8 i = start_center_y; i <= end_center_y; ++i)
           {
               mid_line[i] = right_line[i];
               imgOSTU[i][mid_line[i]] = Control_line;
           }
        }
        else
        {
            end_center_x  = t_center_l;
            Black_num = Black_num_l;
            for (uint8 i = start_center_y; i <= end_center_y; ++i)
            {
                mid_line[i] = left_line[i];
                imgOSTU[i][mid_line[i]] = Control_line;
            }
        }
    }
    if(start_center_y == Deal_Bottom && Black_num < 3)
    {
        IF = straightlineL;
    }
    else if(start_center_y == Deal_Bottom)
    {
        IF = straightlineS;
    }
    return end_center_y;
}

/**
 * @brief 绘制左边界曲线中线
 * @details 当左侧有边界丢失时，从起点到左边界丢失中心画直线中线。
 *          用于左弯道场景，中线偏向左侧以引导车辆左转。
 * @return  end_center_y 中线绘制的最高行号
 *          0 = 终点低于起点（无效）
 */
uint8 Left_curve_line(void)
{
    end_center_x = Deal_Left;                    // 终点X = 左边界
    end_center_y = l_center[l_lost_num - 1];    // 终点Y = 左侧丢失区域中心
    uint8 Black_num = 0;
    if(end_center_y <= start_center_y) return 0; // 终点必须高于起点

    // 从起点到终点画直线中线
    float k = ((float)end_center_x - (float)start_center_x) / ((float)end_center_y - (float)start_center_y);
    for (uint8 i = start_center_y; i <= end_center_y; ++i)
    {
        mid_line[i] = (float)(start_center_x + k * (i - start_center_y));
        if(imgOSTU[i][(uint8)mid_line[i]] != White) Black_num++;
        imgOSTU[i][(uint8)mid_line[i]] = Control_line; // 绘制红色中线
    }

    IF = curve; // 标记为折角弯道
    return end_center_y;
}

/**
 * @brief 绘制右边界曲线中线
 * @details 当右侧有边界丢失时，从起点到右边界丢失中心画直线中线。
 *          用于右弯道场景，中线偏向右侧以引导车辆右转。
 * @return  end_center_y 中线绘制的最高行号
 *          0 = 终点低于起点（无效）
 */
uint8 Right_curve_line(void)
{
    end_center_x = Deal_Right;                   // 终点X = 右边界
    end_center_y = r_center[r_lost_num - 1];    // 终点Y = 右侧丢失区域中心
    uint8 Black_num = 0;
    if(end_center_y <= start_center_y) return 0;

    float k = ((float)end_center_x - (float)start_center_x) / ((float)end_center_y - (float)start_center_y);
    for (uint8 i = start_center_y; i <= end_center_y; ++i)
    {
        mid_line[i] = (float)(start_center_x + k * (i - start_center_y));
        if(imgOSTU[i][(uint8)mid_line[i]] != White) Black_num++;
        imgOSTU[i][(uint8)mid_line[i]] = Control_line;
    }

    IF = curve;
    return end_center_y;
}

/**
 * @brief 停车线识别
 * @details 通过以下特征判断当前赛道是否存在停车线：
 *
 *          前置条件：
 *          - 仅在长直道(straightlineL)上判断
 *          - 车辆偏航角接近发车角度（排除环岛内误判）
 *          - 底部+顶部丢失区域数恰好为2（上下各一块）
 *          - 不是十字路口（总丢失区域<4）
 *          - 距上次停车线足够远（>Stopline_Judge cm）
 *          - 发车后行驶足够距离（>Stopline_Judge cm）
 *
 *          停车线特征（boom检测）：
 *          - 搜索白点数突然增长的行（boom_t 和 boom_b）
 *          - 增长间距在合理范围内（Length_5cm/4 ~ Length_5cm*2）
 *
 *          正入/偏入判断：
 *          - 正入：中线在图像中央，通过左右偏移寻找停车线边界
 *          - 偏入：中线偏左或偏右，通过多组偏移寻找停车线边界
 *          - 要求两组边界平行且宽度合理
 *
 * @return  1 = 识别到停车线（重置环岛/断路计数，记录位置和角度）
 *          0 = 未识别到停车线
 */
uint8 Get_stopline(void)
{
    if(elements_Mode == YES && elements_Lock[elements_index] != Stopline_)
    {
      return 0;
    }
    if(IF != straightlineL)  //仅有直道才判断停车线，否则退出
    {
        return 0;
    }
    int Yaw_error = my_abs((int)imu_data.yaw-Start_angle) - (int)my_abs((int)imu_data.yaw-Start_angle)/360 * 360;
    if(Yaw_error > 30 && Yaw_error < 360-30) //复原到发车角度
    {
        return 0;
    }
    if(b_lost_num + t_lost_num != 2)
    {
        return 0;
    }
    if((b_lost_num+t_lost_num+l_lost_num+r_lost_num) >= 4) //防止十字误判，退出
    {
        return 0;
    }
    if(l_lost_num && r_lost_num) //防止十字误判，退出
    {
        return 0;
    }
    if((l_lost_num && EXTERN_L == 0) || (r_lost_num && EXTERN_R == 0) )
    {
      return 0;
    }
    if(stopline_flag == 0 && Length < Stopline_Judge)  //发车起步前100cm不判断停车线
    {
        return 0;
    }
    if(stopline_flag != 0 && Length - Stopline_Position < Stopline_Judge)   //判断停车线后100cm不判断停车线
    {
        return 0;
    }
    uint8 get_flag = 0; //定义全局判断标志
    uint8 boom_b = 0,boom_t = 0;  //定义白色宽度boom增长的位置，boom_t为增长顶端，boom_b为增长底端
    for(uint8 i = Deal_Top - 5 ; i >= Deal_Bottom + 10;i--) //搜索增长顶端boom_t
    {
        if(white_num_row[i] >= white_num_row[i+5]*2 && white_num_row[i] < Deal_W*4/5) //boom条件
        {
            boom_t = i;
            get_flag = 1; //判断标志增加
        }
        if(white_num_row[i] == 0) //boom条件
        {
            return 0;
        }
    }
    if(get_flag != 1)
    {
        return 0;
    }
    for(uint8 i = Deal_Bottom + 5 ; i < boom_t - 3;i++) //搜索增长顶端boom_b
    {
        if(white_num_row[i] >= white_num_row[i-5]*2 && white_num_row[i] < Deal_W*2/3)//boom条件
        {
            boom_b = i;
            get_flag = 2; //判断标志增加
        }
        if(white_num_row[i] == 0)
        {
            return 0;
        }
    }
    if(get_flag != 2)
    {
        return 0;
    }
    if(boom_t - boom_b < Length_5cm[boom_t]/4 || boom_t - boom_b > Length_5cm[boom_b]*2) //boom增长间距控制在一定范围内
    {
        return 0;
    }
//    qout<<boom_b<<boom_t;
    /**********************正入停车线**********************/
    if(start_center_x > Deal_Left + 15 && start_center_x < Deal_Right - 15 &&
       end_center_x > Deal_Left + 15 && end_center_x < Deal_Right - 15)
    {
        uint8 L_T = YY,L_B = 0,R_T = YY,R_B = 0;
        uint8 x = 0;
        for (uint8 i = start_center_y; i <= end_center_y; ++i)  //中心左偏移寻找左边界顶点
        {
            x = mid_line[i] - b_lost_tip;
            if(imgOSTU[i][x] == White)
            {
                L_B = i;
                break;
            }
            imgOSTU[i][x] = Judge_line;
        }
        for (uint8 i = start_center_y; i <= end_center_y; ++i)  //中心右偏移寻找右边界顶点
        {
            x = mid_line[i] + b_lost_tip;
            if(imgOSTU[i][x] == White)
            {
                R_B = i;
                break;
            }
            imgOSTU[i][x] = Judge_line;
        }
        for (uint8 i = end_center_y; i >= start_center_y; --i)  //中心左偏移寻找左边界底端
        {
            x = mid_line[i] - b_lost_tip;
            if(imgOSTU[i][x] == White)
            {
                L_T = i;
                break;
            }
            imgOSTU[i][x] = Judge_line;
        }
        for (uint8 i = end_center_y; i >= start_center_y; --i)  //中心右偏移寻找右边界底端
        {
            x = mid_line[i] + b_lost_tip;
            if(imgOSTU[i][x] == White)
            {
                R_T = i;
                break;
            }
            imgOSTU[i][x] = Judge_line;
        }
//      qout<<L_T<<L_B<<R_T<<R_B;
      if(L_T - L_B >= 8 && L_T - L_B <= 30 && R_T - R_B >= 8 && R_T - R_B <= 30)  //限制停车线宽度
      {
          get_flag++;
      }
      if(my_abs((L_T - L_B)-(R_T - R_B)) <= 5) //限制限制两顶端、两底端平行
      {
          get_flag++;
      }
    }
    /**********************偏右停车线**********************/
    else if(0 && start_center_x > Deal_Right - 15 || end_center_x > Deal_Right - 15)
    {
      uint8 L_T1 = YY,L_B1 = 0,L_T2 = YY,L_B2 = 0;
      uint8 x = 0;
      for (uint8 i = start_center_y; i <= end_center_y; ++i) //中线左偏移寻找左边界底端1
      {
          x = mid_line[i] - b_lost_tip;
          if(imgOSTU[i][x] == White)
          {
              L_B1 = i;
              break;
          }
          imgOSTU[i][x] = Judge_line;
      }
      for (uint8 i = end_center_y; i >= start_center_y; --i) //中线左偏移寻找左边界顶点1
      {
          x = mid_line[i] - b_lost_tip;
          if(imgOSTU[i][x] == White)
          {
              L_T1 = i;
              break;
          }
          imgOSTU[i][x] = Judge_line;
      }
      for (uint8 i = start_center_y; i <= end_center_y; ++i) //中线左偏移寻找左边界底端2
      {
          x = mid_line[i] - b_lost_tip*3/2;
          if(imgOSTU[i][x] == White)
          {
              L_B2 = i;
              break;
          }
          imgOSTU[i][x] = Judge_line;
      }
      for (uint8 i = end_center_y; i >= start_center_y; --i) //中线左偏移寻找左边界顶点2
      {
          x = mid_line[i] - b_lost_tip*3/2;
          if(imgOSTU[i][x] == White)
          {
              L_T2 = i;
              break;
          }
          imgOSTU[i][x] = Judge_line;
      }
      if(L_T1 - L_B1 >= 5 && L_T1 - L_B1 <= 35 && L_T2 - L_B2 >= 5 && L_T2 - L_B2 <= 35) //限制停车线宽度
      {
          get_flag++;
      }
      if(my_abs((L_T1 - L_B1)-(L_T2 - L_B2)) <= 5) //限制限制两顶端、两底端平行
      {
          get_flag++;
      }
    }
    /**********************偏左停车线**********************/
    else if(0 && start_center_x < Deal_Left + 15 || end_center_x < Deal_Left + 15)
    {
      uint8 R_T1 = YY,R_B1 = 0,R_T2 = YY,R_B2 = 0;
      uint8 x = 0;
      for (uint8 i = start_center_y; i <= end_center_y; ++i)  //中线右偏移寻找右边界底端1
      {
          x = mid_line[i] + b_lost_tip;
          if(imgOSTU[i][x] == White)
          {
              R_B1 = i;
              break;
          }
          imgOSTU[i][x] = Judge_line;
      }
      for (uint8 i = end_center_y; i >= start_center_y; --i) //中线右偏移寻找右边界顶点1
      {
          x = mid_line[i] + b_lost_tip;
          if(imgOSTU[i][x] == White)
          {
              R_T1 = i;
              break;
          }
          imgOSTU[i][x] = Judge_line;
      }
      for (uint8 i = start_center_y; i <= end_center_y; ++i) //中线右偏移寻找右边界底端2
      {
          x = mid_line[i] + b_lost_tip*3/2;
          if(imgOSTU[i][x] == White)
          {
              R_B2 = i;
              break;
          }
          imgOSTU[i][x] = Judge_line;
      }
      for (uint8 i = end_center_y; i >= start_center_y; --i) //中线右偏移寻找右边界顶点2
      {
          x = mid_line[i] + b_lost_tip*3/2;
          if(imgOSTU[i][x] == White)
          {
              R_T2 = i;
              break;
          }
          imgOSTU[i][x] = Judge_line;
      }
      if(R_T1 - R_B1 >= 5 && R_T1 - R_B1 <= 35 && R_T2 - R_B2 >= 5 && R_T2 - R_B2 <= 35) //限制停车线宽度
      {
          get_flag++;
      }
      if(my_abs((R_T1 - R_B1)-(R_T2 - R_B2)) <= 5) //限制限制两顶端、两底端平行
      {
          get_flag++;
      }
    }
//    qout<<get_flag;
    if(get_flag == 4) //满足所有条件,判断为停车线
    {
//        SpeedLoop.OutPut_L = 0; 
//        SpeedLoop.OutPut_R = 0; 
        disappear_num = 0;//断路区清空
        Annulus_num = 0;//环岛数目清空
        memset(histogram, 0, sizeof(histogram));//全局灰度清空
        Stopline_Position = Length;  //记录本次停车线位置
        Start_angle = imu_data.yaw;  //记录停车角度
        elements_index = 0;
        return 1;
    }
    else
    {
       return 0;
    }
}
/**
 * @brief 环岛初步识别
 * @details 通过以下特征判断是否遇到环岛：
 *
 *          核心特征 - K字形（上下聚点）：
 *          - DLR（下左右聚点）连续多帧出现（>=3帧）
 *          - ULR（上左右聚点）也存在
 *          - 四个方向的丢失特征数为3~4个
 *
 *          排除条件：
 *          - 左右同时有丢失（十字路口特征）
 *          - 白点宽度过大（>4/5图像宽度，十字特征）
 *          - 距上次驶出环岛距离不足（<300cm）
 *
 *          四特征点搜索（BL/BR/TL/TR）：
 *          - 根据丢失区域的分布，按顺/逆时针顺序找到四个角点
 *          - 通过K字连线的黑/白比例判断开口方向
 *          - 左环岛：左侧连线黑点多，右侧白点多
 *          - 右环岛：右侧连线黑点多，左侧白点多
 *
 * @return  end_center_y = 绘制的中线高度（识别成功）
 *          0 = 未识别到环岛
 */
uint8 Get_Annulus()
{
//      show_string(18, 1, "Annulus1",RGB565_BLUE ,RGB565_WHITE);
  if(Length < Out_Annulus_Length + 300)
  {
    return 0;
  }
    /*************统计连续5帧下k聚点数目****************/
    if(elements_Mode == YES && elements_Lock[elements_index] != Annulus_)
    {
      return 0;
    }
    static int DLR_appear[10] = {0};
    DLR_appear[9] = DLR_appear[8];
    DLR_appear[8] = DLR_appear[7];
    DLR_appear[7] = DLR_appear[6];
    DLR_appear[6] = DLR_appear[5];
    DLR_appear[5] = DLR_appear[4];
    DLR_appear[4] = DLR_appear[3];
    DLR_appear[3] = DLR_appear[2];
    DLR_appear[2] = DLR_appear[1];
    DLR_appear[1] = DLR_appear[0];
//    qout<<DLR_appear[0] + DLR_appear[1] + DLR_appear[2] + DLR_appear[3] + DLR_appear[4] + DLR_appear[5] + DLR_appear[6] + DLR_appear[7] + DLR_appear[8] + DLR_appear[9];
    if(EXTERN_sum[DLR] > 20)
    {
        DLR_appear[0] = 1;
        if(DLR_appear[0] + DLR_appear[1] + DLR_appear[2] + DLR_appear[3] + DLR_appear[4] + DLR_appear[5] + DLR_appear[6] + DLR_appear[7] + DLR_appear[8] + DLR_appear[9] >= 3)
        {
            //有连续几帧下k聚点，判断环岛
        }
        else
        {
            return 0;
        }
    }
    else
    {
        DLR_appear[0] = 0;
        return 0;
    }

    if( (b_lost_num+t_lost_num+l_lost_num+r_lost_num) > 4 || (b_lost_num+t_lost_num+l_lost_num+r_lost_num) < 3)
    {//限制仅有四个特征区域
        return 0;
    }
    if(l_lost_num && r_lost_num)
    {//限制不是十字
        return 0;
    }
    if(EXTERN_sum[ULR] < 20 || EXTERN_sum[DLR] < 20)
    {//有上下聚点，限制k字特征
        return 0;
    }
    //限制白点宽度,防止十字误判
    uint8 L_end = Deal_Left,R_end = Deal_Right;
    for(int x = Deal_Left;x <= Deal_Right;x++)
    {
        if(white_num_col[x])
        {
            L_end = x;
        }
    }
    for(int x = Deal_Right;x >= Deal_Left;x--)
    {
        if(white_num_col[x])
        {
            R_end = x;
        }
    }
    if(R_end - L_end > Deal_W*4/5)
    {
        return 0;
    }
    //四个特征区域搜索
    int BL_x,BR_x,BL_y,BR_y;
    int TL_x,TR_x,TL_y,TR_y;
    if((b_lost_num+t_lost_num+l_lost_num+r_lost_num) == 4)
    {/********************************实线环岛环岛判断********************************/
        if(b_lost_num == 2 && t_lost_num == 2 )
        {
            BL_y = start_center_y;
            BL_x = b_center[0];
            BR_y = start_center_y;
            BR_x = b_center[1];
            TL_y = Deal_Top;
            TL_x = t_center[0];
            TR_y = Deal_Top;
            TR_x = t_center[1];
        }
        else if(l_lost_num)
        {
            if(t_center[t_lost_num-1] > Deal_W*0.7 || b_center[b_lost_num-1] > Deal_W*0.7)
            {
                return 0;
            }
            //左斜入，顺时针统计特征位置
            uint8 point[4][2] = {{0,0},{0,0},{0,0},{0,0}}; // 初始化为0
            uint8 j = 0;
            if(b_lost_num)
            for(int i = b_lost_num-1; i >= 0 && j<=3;i--)
            {
                point[j][0] = b_center[i];
                point[j][1] = start_center_y;
                j++;
            }
            if(l_lost_num)
            for(int i = 0; i <= l_lost_num-1 && j<=3;i++)
            {
                point[j][0] = Deal_Left;
                point[j][1] = l_center[i];
                j++;
            }
            if(t_lost_num)
            for(int i = 0; i <= t_lost_num-1 && j<=3 ;i++)
            {
                point[j][0] = t_center[i];
                point[j][1] = Deal_Top;
                j++;
            }
            if(j != 4)
            {
                return 0;
            }
            BL_y = point[1][1];
            BL_x = point[1][0];
            BR_y = point[0][1];
            BR_x = point[0][0];

            TL_y = point[2][1];
            TL_x = point[2][0];
            TR_y = point[3][1];
            TR_x = point[3][0];
        }
        else if(r_lost_num)
        {
            if(t_center[t_lost_num-1] < Deal_W*0.3 || b_center[b_lost_num-1] < Deal_W*0.3)
            {
                return 0;
            }
            //右斜入，逆时针统计特征位置
            uint8 point[4][2] = {{0,0},{0,0},{0,0},{0,0}}; // 初始化为0
            uint8 j = 0;
            if(b_lost_num)
            for(int i = 0; i <= b_lost_num-1 && j <= 3;i++)
            {
                point[j][0] = b_center[i];
                point[j][1] = start_center_y;
                j++;
            }
            if(r_lost_num)
            for(int i = 0; i <= r_lost_num-1 && j <= 3;i++)
            {
                point[j][0] = Deal_Right;
                point[j][1] = r_center[i];
                j++;
            }
            if(t_lost_num)
            for(int i = t_lost_num-1; i >= 0 && j <= 3;i--)
            {
                point[j][0] = t_center[i];
                point[j][1] = Deal_Top;
                j++;
            }
            if(j != 4)
            {
                return 0;
            }

            BL_y = point[0][1];
            BL_x = point[0][0];
            BR_y = point[1][1];
            BR_x = point[1][0];

            TL_y = point[3][1];
            TL_x = point[3][0];
            TR_y = point[2][1];
            TR_x = point[2][0];

        }
    }
    else if((b_lost_num+t_lost_num+l_lost_num+r_lost_num) == 3) //虚线入环强制找开口
    {
        if(l_lost_num || r_lost_num)//限制无倾斜
        {
            return 0;
        }
        //寻找上下看聚点位置
        int DLR_x,DLR_y,ULR_x,ULR_y;
        int B_Found = 0,T_Found = 0;
        for(int y = Deal_Bottom;y <= Deal_Top;y++)
        {
            if(EXTERN_ROW[DLR][y] && EXTERN_ROW[DLR][y+1])
            {
                DLR_y = y+1;
                for(int x1 = Deal_Left;x1 <= Deal_Right;x1++ )
                {
                    if(imgTran[DLR_y][x1] == DLR)
                    {
                        for(int x2 = x1;x2 <= Deal_Right;x2++ )
                            if(imgTran[DLR_y][x2] != DLR)
                            {
                                DLR_x = (int)(x1+x2)/2;
                                B_Found = 1;
                                break;
                            }
                        break;
                    }
                }
                break;
            }
        }
        for(int y = Deal_Top;y >= Deal_Bottom;y--)
        {
            if(EXTERN_ROW[ULR][y] && EXTERN_ROW[ULR][y-1])
            {
                ULR_y = y-1;
                for(int x1 = Deal_Left;x1 <= Deal_Right;x1++ )
                {
                    if(imgTran[ULR_y][x1] == ULR)
                    {
                        for(int x2 = x1;x2 <= Deal_Right;x2++ )
                            if(imgTran[ULR_y][x2] != ULR)
                            {
                                ULR_x = (int)(x1+x2)/2;
                                T_Found = 1;
                                break;
                            }
                        break;
                    }
                }
                break;
            }
        }
        if(B_Found+T_Found != 2 || my_abs(ULR_x - DLR_x) > Deal_W/3 || ULR_y - DLR_y < 20) //保证找到上下k，且位置合理
        {
            return 0;
        }
        //寻找四特征点
        if(b_lost_num == 2) //存在正底部
        {
            BL_y = start_center_y;
            BR_y = start_center_y;
            BL_x = b_center[0];
            BR_x = b_center[1];
        }
        else //虚底部
        {
            int start_L = Deal_Left,start_R = Deal_Right; //限制左右搜索起点
            for(int x = Deal_Left;x <= DLR_x;x++)
            {
                if(white_num_col[x])
                {
                    start_L = x;
                    break;
                }
            }
            for(int x = Deal_Right;x >= DLR_x;x--)
            {
                if(white_num_col[x])
                {
                    start_R = x;
                    break;
                }
            }
            //下寻下起点
            int found_flag = 0;
            for(int y = start_center_y;y <= DLR_y &&  !found_flag;y++)
            {
                for(int x1 = start_L;x1 <= DLR_x &&  !found_flag;x1++)
                {
                   if(imgOSTU[y][x1] == White)
                   {
                       for(int x2 = start_L;x2 <= DLR_x &&  !found_flag;x2++)
                       {
                           if(imgOSTU[y+1][x2] == White)
                           {
                               for(int x3 = x2;x3 <= DLR_x && !found_flag;x3++)
                               {
                                   if(imgOSTU[y+1][x3] == White)
                                   {
                                       BL_x = x3;
                                       BL_y = y+1;
                                       found_flag = 1;
                                       break;
                                   }
                               }
                           }
                       }
                   }
                }
            }
            if(found_flag != 1)
            {
                return 0;
            }
            else
            {
              found_flag = 0;
            }
            for(int y = start_center_y;y <= DLR_y && !found_flag;y++)
            {
                for(int x1 = start_R;x1 >= ULR_x && !found_flag;x1--)
                {
                   if(imgOSTU[y][x1] == White)
                   {
                       for(int x2 = start_R;x2 >= DLR_x && !found_flag;x2--)
                       {
                           if(imgOSTU[y+1][x2] == White)
                           {
                               for(int x3 = x2;x3 >= DLR_x && !found_flag;x3--)
                               {
                                   if(imgOSTU[y+1][x3] == White)
                                   {
                                       BR_x = x3;
                                       BR_y = y+1;
                                       found_flag=2;
                                       break;
                                   }
                               }
                           }
                       }
                   }
                }
            }
            if(found_flag != 1)
            {
                return 0;
            }
        }
        if(t_lost_num == 2) //存在正顶部
        {
            TL_y = Deal_Top;
            TR_y = Deal_Top;
            TL_x = t_center[0];
            TR_x = t_center[1];
        }
        else //虚顶部
        {
            int start_L = Deal_Left,start_R = Deal_Right;
            for(int x = Deal_Left;x <= DLR_x;x++)
            {
                if(white_num_col[x])
                {
                    start_L = x;
                    break;
                }
            }
            for(int x = Deal_Right;x >= DLR_x;x--)
            {
                if(white_num_col[x])
                {
                    start_R = x;
                    break;
                }
            }

            int found_flag = 0;
            for(int y = Deal_Top;y >= ULR_y && !found_flag;y--)
            {
                for(int x1 = start_L;x1 <= ULR_x && !found_flag;x1++)
                {
                   if(imgOSTU[y][x1] == White)
                   {
                       for(int x2 = start_L;x2 <= ULR_x && !found_flag;x2++)
                       {
                           if(imgOSTU[y-1][x2] == White)
                           {
                               for(int x3 = x2;x3 <= ULR_x && !found_flag;x3++)
                               {
                                   if(imgOSTU[y-1][x3] == White)
                                   {
                                       TL_x = x3;
                                       TL_y = y-1;
                                       found_flag ++;
                                       break;
                                   }
                               }
                           }
                       }
                   }
                }
            }
            if(found_flag != 1)
            {
                return 0;
            }
            else
            {
              found_flag = 0;
            }
            for(int y = Deal_Top;y >= ULR_y && !found_flag;y--)
            {
                for(int x1 = start_R;x1 >= ULR_x && !found_flag;x1--)
                {
                   if(imgOSTU[y][x1] == White)
                   {
                       for(int x2 = start_R;x2 >= ULR_x && !found_flag;x2--)
                       {
                           if(imgOSTU[y-1][x2] == White)
                           {
                               for(int x3 = x2;x3 >= ULR_x && !found_flag;x3--)
                               {
                                   if(imgOSTU[y-1][x3] == White)
                                   {
                                       TR_x = x3;
                                       TR_y = y-1;
                                       found_flag++;
                                       break;
                                   }
                               }
                           }
                       }
                   }
                }

            }
            if(found_flag != 1)
            {
                return 0;
            }

        }
    }
    else
    {
        return 0;
    }
    if(TR_x - TL_x > Deal_W*4/5 || BR_x - BL_x > Deal_W*4/5 ||
       TR_x <= TL_x || BR_x <= BL_x ||
       my_abs(TL_x - BL_x) > Deal_W*3/5 || my_abs(TR_x - BR_x) > Deal_W*3/5)
    {//四特征x起点位置限制
        return 0;
    }
    if(TR_y < Deal_H/2 || TL_y < Deal_H/2 || BR_y > Deal_H/2 || BL_y > Deal_H/2 ||
       TR_y < BR_y+5 || TL_y < BL_y+5 || TR_y > Deal_Top || TL_y > Deal_Top || BL_y < Deal_Bottom  || BR_y < Deal_Bottom)
    {//四特征y起点位置限制
        return 0;
    }
    //连线进行k字开口朝向判断
    uint8 Left_Feature = 0;
    uint8 Right_Feature = 0;
    float White_num_l = 0,White_num_r = 0;
    float Black_num_l = 0,Black_num_r = 0; 

    float kl = ((float)TL_x - (float)BL_x) / ((float)TL_y - (float)BL_y);
    float kr = ((float)TR_x - (float)BR_x) / ((float)TR_y - (float)BR_y);
    if((kl > 1 || kl < -1) && (kr > 1 || kl < -1))//过于倾斜不予判断
    {
        return 0;
    }

    //    /***********左K特征判断************/
    for (uint8 i = BL_y; i <= TL_y; ++i)
    {
        int xl = (int)(BL_x + kl * (i - BL_y));
        if (xl > Deal_Right) 
        {
          xl = Deal_Right;  // 钳制到有效范围
        } 
        else if (xl < Deal_Left) 
        {
          xl = Deal_Left;
        }
        if(imgOSTU[i][xl] == White)
        {
            White_num_l+= (float)Length_5cm[0]/(float)Length_5cm[i];
        }
        else
        {
            imgOSTU[i][xl] = Judge_line;
            Black_num_l+= (float)Length_5cm[0]/(float)Length_5cm[i];
        }
    }
    if(Black_num_l > White_num_l *2)
    {
        Left_Feature = 1;
    }
    else if(Black_num_l < White_num_l *1.1)
    {
        Left_Feature = 0;
    }
    else
    {
        Left_Feature = 3;
    }
    /***********右K特征判断************/
    for (uint8 i = BR_y; i <= TR_y; ++i)
    {
        int xr = (int)(BR_x + kr * (i - BR_y));
        if (xr > Deal_Right) 
        {
          xr = Deal_Right;  // 钳制到有效范围
        } 
        else if (xr < Deal_Left) 
        {
          xr = Deal_Left;
        }
        if(imgOSTU[i][xr] == White)
        {
            White_num_r += (float)Length_5cm[0]/(float)Length_5cm[i];
        }
        else
        {
            imgOSTU[i][xr] = Judge_line;
            Black_num_r+= (float)Length_5cm[0]/(float)Length_5cm[i];
        }
    }
    if(Black_num_r > White_num_r *2)
    {
        Right_Feature = 1;
    }
    else if(Black_num_r < White_num_r *1.1)
    {
        Right_Feature = 0;
    }
    else
    {
        Right_Feature = 3;
    }

        //根据K字情况，判断左右环岛
        if(Left_Feature && !Right_Feature && !r_lost_num)
        {
            //左环岛
            int start_R = BR_x > TR_x ? BR_x : TR_x;
            int white_num = 0;
            for(int x = start_R; x <=  Deal_Right;x++)
            {
                if(imgOSTU[Lost_Top][x] != Lost_line && imgOSTU[Lost_Bottom][x] != Lost_line)
                {
                    start_R = x + 1;
                    for(int k = start_R; k <=  Deal_Right;k++)
                    {
                        white_num += white_num_col[k];
                    }
                    break;
                }
            }
            if(white_num > 3)
            {
                return 0;
            }
            
            
            start_center_x = b_center[1];
            end_center_x = t_center[0];
            end_center_y = Deal_Top;
            Get_curve_line(start_center_x, start_center_y, end_center_x, end_center_y, (int)10);
            IF = annulus_l;
            Annulus_Zero = imu_data.yaw;
            Annulus_num++;
            elements_index++;
            return end_center_y;
        }
        else if(Right_Feature && !Left_Feature && !l_lost_num)
        {
            //右环岛
            int start_L = BL_x > TL_x ? BL_x : TL_x;
            int white_num = 0;
            for(int x = start_L; x >=  Deal_Left;x--)
            {
                if(imgOSTU[Lost_Top][x] != Lost_line && imgOSTU[Lost_Bottom][x] != Lost_line)
                {
                    start_L = x - 1;
                    for(int k = start_L; k >=  Deal_Left;k--)
                    {
                        white_num += white_num_col[k];
                    }
                    break;
                }
            }
            if(white_num > 3)
            {
                return 0;
            }
            
            
            start_center_x = b_center[0];
            end_center_x = t_center[1];
            end_center_y = Deal_Top;
            Get_curve_line(end_center_x, end_center_y,start_center_x, start_center_y,(int)10);
            IF = annulus_r;
            Annulus_Zero = imu_data.yaw;
            Annulus_num++;
            elements_index++;
            return end_center_y;
        }
        else
        {
            return 0;
        }
}
/**
 * @brief 正在驶入环岛的巡线操作
 * @details 在环岛识别成功后（status=1），执行驶入环岛的中线绘制：
 *          - 左环岛：记录底部→顶部→左侧的特征点，画到环岛入口的中线
 *          - 右环岛：记录底部→顶部→右侧的特征点，画到环岛入口的中线
 *          - 根据白点宽度调整起点位置（避免中线偏出赛道）
 * @return  end_center_y 中线绘制高度
 *          0 = 特征点不足或中线无效
 */
uint8 Into_Annulus_ing()
{
//      show_string(18, 1, "Annulus5",RGB565_BLUE ,RGB565_WHITE);
  uint8 point[4][2] = {{0,0},{0,0},{0,0},{0,0}};
  int count = 0;
    if(IF == annulus_l)
    {
        //左环岛逆时针记录特征点
        uint8 j = 0;
        if(b_lost_num)
        for(int i = b_lost_num-1; i <= b_lost_num-1 && j<=3;i++)
        {
            point[j][0] = b_center[i];
            point[j][1] = start_center_y;
//            qout<<j<<i<<point[j][0]<<point[j][1];
            j++;
        }
        if(t_lost_num)
        for(int i = t_lost_num-1; i >= 0  && j<=3 ;i--)
        {
            point[j][0] = t_center[i];
            point[j][1] = Deal_Top;
//            qout<<j<<i<<point[j][0]<<point[j][1];
            j++;
        }
        if(l_lost_num)
        for(int i = l_lost_num-1; i >= 0 && j<=3;i--)
        {
            point[j][0] = Deal_Left;
            point[j][1] = l_center[i];
//            qout<<j<<i<<point[j][0]<<point[j][1];
            j++;
        }
        count = j-1;
        int White_num = 0;
        for(uint8 x = Deal_Right;x >= point[0][0];x--)
        {
            White_num += white_num_col[x];
            if(White_num >= Deal_H*3)
            {
                point[0][0] = x;
                break;
            }
        }
    }
    else if(IF == annulus_r)
    {
        //右环岛逆时针记录特征点
        uint8 j = 0;
        if(b_lost_num)
        for(int i = 0; i >= 0 && j <= 3;i--)
        {
            point[j][0] = b_center[i];
            point[j][1] = start_center_y;
//            qout<<j<<i<<point[j][0]<<point[j][1];
            j++;
        }
        if(t_lost_num)
        for(int i = 0; i <= t_lost_num-1 && j <= 3;i++)
        {
            point[j][0] = t_center[i];
            point[j][1] = Deal_Top;
//            qout<<j<<i<<point[j][0]<<point[j][1];
            j++;
        }
        if(r_lost_num)
        for(int i = r_lost_num-1; i >= 0 && j <= 3;i--)
        {
            point[j][0] = Deal_Right;
            point[j][1] = r_center[i];
//            qout<<j<<i<<point[j][0]<<point[j][1];
            j++;
        }
        count = j-1;
        int White_num = 0;
        for(uint8 x = Deal_Left;x <= point[0][0];x++)
        {
            White_num += white_num_col[x];
            if(White_num >= Deal_H*3)
            {
                point[0][0] = x;
                break;
            }
        }
    }
    //起始点，终点赋值
    if(count != 0)
    {
      start_center_x = point[0][0];
    }
    else
    {
      return 0;
    }
    if(count >= 2)
    {
    end_center_x = point[2][0];
    end_center_y = point[2][1];
    }
    else
    {
      return 0;
    }

//    qout<<start_center_x<<start_center_y<<end_center_x<<end_center_y;
    //记录中线
    if(end_center_y <= start_center_y)
    {
      return 0;
    }
    float k = ((float)end_center_x - (float)start_center_x) / ((float)end_center_y - (float)start_center_y);
//    qout<<"k"<<k;
    for (uint8 i = start_center_y; i <= end_center_y; ++i)
    {
        mid_line[i] = (float)(start_center_x + k * (i - start_center_y));
        if(mid_line[i] < Deal_Left)
        {
          mid_line[i] = Deal_Left;
        }
        else if(mid_line[i] > Deal_Right)
        {
          mid_line[i] = Deal_Right;
        }
        imgOSTU[i][(uint8)mid_line[i]] = Control_line;
    }
    return end_center_y;
}
/**
 * @brief 判断是否成功驶入环岛
 * @details 当DLR聚点消失（连续2帧无DLR）且底部丢失区域数为1时，
 *          判定车辆已驶入环岛内部，状态机从status=1升级到status=2。
 * @return  1 = 成功驶入环岛
 *          0 = 尚未驶入
 */
* 使用实例     :Into_Annulus_judge();
******************************************************************************/
uint8 Into_Annulus_judge()
{
//   show_string(18, 1, "Annulus2",RGB565_BLUE ,RGB565_WHITE);
   if(b_lost_num != 1)
   {
       return 0;
   }
    static int DLR_disappear[2] = {0};
    DLR_disappear[1] = DLR_disappear[0];
    if(EXTERN_sum[DLR] == 0)
    {
        DLR_disappear[0] = 1;
    }
    else
    {
        DLR_disappear[0] = 0;
    }

    if(DLR_disappear[0] + DLR_disappear[1])
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
/**
 * @brief 环岛内巡线操作
 * @details 在环岛内部（status=2）执行巡线：
 *          - 左环岛：搜索左侧边界丢失区域，绘制曲线中线
 *          - 右环岛：搜索右侧边界丢失区域，绘制曲线中线
 *          - 曲率参数由 Annulus_Curvature[] 控制（根据第N个环岛选择不同曲率）
 * @return  end_center_y 中线绘制高度
 *          0 = 特征不足
 */
uint8 Runing_Annulus()
{
//  Annulus_num
  int Curvature = 10;
  
  if(Annulus_num > 5)
  {
    Curvature = Annulus_Curvature[4];
  }
  else
  {
    Curvature = Annulus_Curvature[Annulus_num - 1];
  }

    if(IF == annulus_l)
    {
        //左环岛搜左线
        if(b_lost_num)
        {
            start_center_x = b_center[0];
        }
        else
        {
            return  0;
        }

        if(l_lost_num)
        {
          end_center_y = l_center[l_lost_num-1];
          end_center_x = Deal_Left;
//          qout<<end_center_y<<end_center_x;
        }
        else if(imgOSTU[Lost_Top][Deal_Left] == Lost_line)
        {
            end_center_y = Deal_Top;
            end_center_x = Deal_Left;
        }
        else if(t_lost_num)
        {
            end_center_y = Deal_Top;
            end_center_x = t_center[0];
//            qout<<end_center_y<<end_center_x;
        }
        else
        {
            return 0;
        }
        if(start_center_x <= end_center_x)
        {
          return 0;
        }
        Get_curve_line(start_center_x,start_center_y,end_center_x, end_center_y,Curvature);
    }
    else if(IF == annulus_r)
    {
        //右环岛搜右线
        if(b_lost_num)
        {
            start_center_x = b_center[b_lost_num-1];
        }
        else
        {
            return 0;
        }

        if(r_lost_num)
        {
            end_center_y = r_center[r_lost_num-1];
            end_center_x = Deal_Right;
        }
        else if(imgOSTU[Lost_Top][Deal_Right] == Lost_line)
        {
            end_center_y = Deal_Top;
            end_center_x = Deal_Right;
        }
        else if(t_lost_num)
        {
            end_center_y = Deal_Top;
            end_center_x = t_center[t_lost_num-1];
        }
        else
        {
            return 0;
        }
        if(end_center_x <= start_center_x)
        {
          return 0;
        }
        Get_curve_line(end_center_x, end_center_y,start_center_x, start_center_y,Curvature);
    }
    return end_center_y;
}
/**
 * @brief 判断是否即将驶出环岛
 * @details 在环岛运行状态（status=2）下，检查是否满足驶出条件：
 *          - 偏航角累计超过250度（绕环岛走了大半圈）
 *          - 出现UDLR四方聚点（环岛出口特征）
 *          - 或者：检测到对侧直道边界出现（左环岛看到右边界，右环岛看到左边界）
 * @return  1 = 即将驶出（记录 Out_Annulus_Length）
 *          0 = 继续环岛内巡线
 */
uint8 Leave_Annulus_judge()
{
//    show_string(18, 1, "Annulus3",RGB565_BLUE ,RGB565_WHITE);
    Annulus_Yaw = imu_data.yaw - Annulus_Zero;
    if(!(Annulus_Yaw <= -250) && !(Annulus_Yaw >= 250))
    {
      return 0;
    }
    static int UDLR_sum = 0;
    UDLR_sum += EXTERN_sum[UDLR];
    if(b_lost_num+t_lost_num+l_lost_num+r_lost_num >= 3 && UDLR_sum >= 400)
    {
        UDLR_sum = 0;
        Out_Annulus_Length = Length;
        return 1;
    }
    else
    {
        if(IF == annulus_r)
            {
                //右环岛，判断左边缘特征出现，即左直道出现
                if((b_lost_num+t_lost_num+l_lost_num+r_lost_num) < 3)
                {
                    return 0;
                }
                //右寻线特征依然存在，且顶端特征位置正常
                if(b_lost_num && l_lost_num && l_center[l_lost_num-1] < Deal_Top - 10 && l_center[l_lost_num-1] > Deal_Bottom + 3)
                {
                    int White_num = 0;
                    int x1 = Deal_Left,x2 = b_center[0];
                    int y1 = start_center_y,y2 = l_center[l_lost_num-1];
                    for(int x = x1;x<=x2;x++)
                    {
                        for(int y= y1;y<=y2;y++)
                        {
                            if(imgOSTU[y][x] == White)
                            {
                                White_num ++;
                            }
                        }
                    }
                    if(White_num < (x2-x1)*(y2-y1))
                    {
                    Out_Annulus_Length = Length;
                    return 1;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    return 0;
                }
            }
            if(IF == annulus_l)
            {
                //左环岛，判断右边缘特征出现，即右直道出现
                if((b_lost_num+t_lost_num+l_lost_num+r_lost_num) < 3|| b_lost_num == 0)
                {
                    return 0;
                }
                if(b_lost_num && r_lost_num && r_center[r_lost_num-1] < Deal_Top - 10 && r_center[r_lost_num-1] > Deal_Bottom + 3)
                {
                    int White_num = 0;
                    int x1 = b_center[b_lost_num-1],x2 = Deal_Right;
                    int y1 = start_center_y , y2 = r_center[r_lost_num-1];
                    for(int x = x1;x<=x2;x++)
                    {
                        for(int y= y1;y<=y2;y++)
                        {
                            if(imgOSTU[y][x] == White)
                            {
                                White_num ++;
                            }
                        }
                    }
                    if(White_num < (x2-x1)*(y2-y1))
                    {
                    Out_Annulus_Length = Length;
                    return 1;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    return 0;
                }
            }
    }
}
/**
 * @brief 驶出环岛的巡线操作
 * @details 在即将驶出环岛时（status=3），切换到直道巡线模式：
 *          - 右环岛驶出：寻找左侧边界特征，绘制向左的直线中线
 *          - 左环岛驶出：寻找右侧边界特征，绘制向右的直线中线
 *          - 中线从底部起点到顶部终点，确保车辆驶出环岛后回到直道
 * @return  end_center_y 中线绘制高度
 *          0 = 特征不足
 */
uint8 Leave_Annulus_ing()
{
//      show_string(18, 1, "Annulus7",RGB565_BLUE ,RGB565_WHITE);

    //出环时，寻直道走
    if(IF == annulus_r)
    {
        uint8 start_found = 0;
        if(l_lost_num)
        {
            start_center_y = Deal_Bottom;
            start_center_x = Deal_Left;
            start_found = 1;
        }
        else if(b_lost_num)
        {
            start_center_y = start_center_y;
            start_center_x = b_center[0];
            start_found = 1;
        }
        uint8 end_found = 0;
        if(t_lost_num)
        {
            end_center_y = Deal_Top;
            end_center_x = t_center[0];
            end_found = 1;
        }
        else if(r_lost_num)
        {
            end_center_y = r_center[r_lost_num-1];
            end_center_x = Deal_Right;
            end_found = 1;
        }
//        qout<<start_center_x<<start_center_y<<end_center_x<<end_center_y;
//        qout<<start_found<<end_found;
        if(start_found == 0 || end_found == 0)
        {
            return 0;
        }
        if(end_center_y <= start_center_y)
        {
          return 0;
        }
       float k = ((float)end_center_x - (float)start_center_x) / ((float)end_center_y - (float)start_center_y);
       for (uint8 i = start_center_y; i <= end_center_y; ++i)
       {
           mid_line[i] = (float)(start_center_x + k * (i - start_center_y));
           if(mid_line[i] < Deal_Left)
           {
             mid_line[i] = Deal_Left;
           }
           else if(mid_line[i] > Deal_Right)
           {
             mid_line[i] = Deal_Right;
           }
           imgOSTU[i][(uint8)mid_line[i]] = Control_line;
       }
       return end_center_y;
    }
    if(IF == annulus_l)
    {
        uint8 start_found = 0;
        if(r_lost_num)
        {
            start_center_y = Deal_Bottom;
            start_center_x = Deal_Right;
            start_found = 1;
        }
        else if(b_lost_num)
        {
            start_center_y = start_center_y;
            start_center_x = b_center[b_lost_num-1];
            start_found = 1;
        }
        uint8 end_found = 0;
        if(t_lost_num)
        {
            end_center_y = Deal_Top;
            end_center_x = t_center[t_lost_num-1];
            end_found = 1;
        }
        else if(l_lost_num)
        {
            end_center_y = l_center[l_lost_num-1];
            end_center_x = Deal_Left;
            end_found = 1;
        }
//        qout<<start_center_x<<start_center_y<<end_center_x<<end_center_y;
//        qout<<start_found<<end_found;
        if(start_found == 0 || end_found == 0)
        {
            return 0;
        }
        if(end_center_y <= start_center_y)
        {
          return 0;
        }
       float k = ((float)end_center_x - (float)start_center_x) / ((float)end_center_y - (float)start_center_y);
       for (uint8 i = start_center_y; i <= end_center_y; ++i)
       {
           mid_line[i] = (float)(start_center_x + k * (i - start_center_y));
           if(mid_line[i] < Deal_Left)
           {
             mid_line[i] = Deal_Left;
           }
           else if(mid_line[i] > Deal_Right)
           {
             mid_line[i] = Deal_Right;
           }
           imgOSTU[i][(uint8)mid_line[i]] = Control_line;
       }
       return end_center_y;
    }
}
/**
 * @brief 判断是否完全驶出环岛
 * @details 在驶出状态（status=3）下，判断车辆是否已完全离开环岛：
 *          - 驶出后行驶距离超过50cm
 *          - 起点终点位置正常（不偏左/偏右）
 *          - 超过60cm强制判定驶出（防止卡死）
 * @return  1 = 完全驶出（重置环岛状态机到0）
 *          0 = 尚未完全驶出
 */
uint8 Out_Annulus()
{
    //起点终点倾斜则退出
    if(Length < Out_Annulus_Length + 50)
    {
      return 0;
    }
    if(t_center[0] < Deal_Left + 10 || t_center[0] > Deal_Right - 10 ||
       b_center[0] < Deal_Left + 10 || b_center[0] > Deal_Right - 10)
    {
        return 0;
    }
    //驶出为直道
//    if(b_lost_num == 1 && t_lost_num == 1 && !l_lost_num && !r_lost_num)
//    {
//        return 1;
//    }
    if(Length > Out_Annulus_Length + 60)
    {
    //未判断驶出，则依靠行驶距离判断
        return 1;
    }
    else
    {
        return 0;
    }
}
/**
 * @brief 环岛处理总调度（状态机）
 * @details 环岛处理状态机，管理环岛的完整生命周期：
 *
 *          状态机流程：
 *          status=0 → Get_Annulus()        初步识别环岛
 *          status=1 → Into_Annulus_judge() 判断驶入 + Into_Annulus_ing() 驶入巡线
 *          status=2 → Leave_Annulus_judge()判断驶出 + Runing_Annulus()   环岛内巡线
 *          status=3 → Out_Annulus()        判断完全驶出 + Leave_Annulus_ing() 驶出巡线
 *          status=0 → 重置，准备识别下一个环岛
 *
 * @return  status 当前环岛状态（0/1/2/3）
 */
uint8 Go_Annulus()
{
    uint8 status = Annulus_flag;
    //环岛状态判断
    if(status == 0)
    {
        Stop_line = Get_Annulus(); //初步环岛识别
        if(Stop_line)
        {
            status = 1;
        }
        return status;
    }
    else if(status == 1)
    {
        status = status + Into_Annulus_judge(); //正式驶入环岛判断
    }
    else if(status == 2)
    {
        status = status + Leave_Annulus_judge(); //即将驶离环岛判断
    }
    else if(status == 3)
    {
        if(Out_Annulus()) //正式离开环岛判断2
        {
            status = 0;
            return status;
        }
    }

    if(status == 1) //驶入环岛
    {
        Stop_line = Into_Annulus_ing();
        return status;
    }
    else if(status == 2) //正式环岛运行
    {
        Stop_line = Runing_Annulus();
        return status;
    }
    else if(status == 3)  //驶离环岛
    {
        Stop_line = Leave_Annulus_ing();
        return status;
    }

}
/**
 * @brief 十字路口识别与处理
 * @details 识别十字路口并绘制通过十字的中线。
 *
 *          识别条件：
 *          - 四个方向均有丢失特征（b_lost + t_lost + l_lost + r_lost >= 3）
 *          - 底部和顶部均有丢失区域
 *          - 底部丢失宽度不超过图像宽度的一半
 *
 *          处理策略：
 *          1. 四特征点（4个丢失区域）：
 *             - 按顺时针顺序排列四个角点
 *             - 从底部到顶部画直线中线
 *             - 检查直线经过的黑色像素数，选择最优路径
 *
 *          2. 三特征点（3个丢失区域）：
 *             - 尝试所有底部→侧面的连线组合
 *             - 计算每条连线的白/黑比例
 *             - 选择白区比例最高的连线作为中线
 *             - 考虑当前偏差方向，选择斜率一致的连线
 *
 * @return  end_center_y 中线绘制高度
 *          0 = 未识别到十字或中线无效
 */
uint8 Deal_crossroads()
{
    if(elements_Mode == YES && elements_Lock[elements_index] != Disappear_)
    {
      return 0;
    }
    //无四边缘，返回
    if( (b_lost_num+t_lost_num+l_lost_num+r_lost_num) <= 3)
    {
        return 0;
    }
    if( (b_lost_num+t_lost_num+l_lost_num+r_lost_num) == 3 && l_lost_num+r_lost_num == 0)
    {
        return 0;
    }
    //没有底端区域，返回
    if(b_lost_num == 0 || t_lost_num == 0)
    {
        return 0;
    }
    if(b_lost_tip > Deal_W/2) //横向广底端
    {
        return 0;
    }
    if((b_lost_num+t_lost_num+l_lost_num+r_lost_num) == 4)
    {
      uint8 point[4][2];
    uint8 j = 0;
    if(b_lost_num)
    for(int i = 0; i <= b_lost_num-1  && j<=3;i++)
    {
        point[j][0] = b_center[i];
        point[j][1] = Deal_Bottom;
//        qout<<j<<i<<point[j][0]<<point[j][1];
        j++;
    }
    if(r_lost_num)
    for(int i = 0; i <= r_lost_num-1  && j<=3;i++)
    {
        point[j][0] = Deal_Right;
        point[j][1] = r_center[i];
//        qout<<j<<i<<point[j][0]<<point[j][1];
        j++;
    }
    if(t_lost_num)
    for(int i = t_lost_num-1; i >= 0  && j<=3;i--)
    {
        point[j][0] = t_center[i];
        point[j][1] = Deal_Top;
//        qout<<j<<i<<point[j][0]<<point[j][1];
        j++;
    }
    if(l_lost_num)
    for(int i = l_lost_num-1; i >= 0  && j<=3;i--)
    {
        point[j][0] = Deal_Left;
        point[j][1] = l_center[i];
//        qout<<j<<i<<point[j][0]<<point[j][1];
        j++;
    }
    if(j < 3)
    {
        return 0;
    }
    if(my_abs(point[1][0]-point[2][0]) < Deal_W*2/5 ||
       my_abs(point[2][0]-point[3][0]) < Deal_W*2/5 ||
       my_abs(point[1][0]-point[3][0]) < Deal_W*2/5 )
    {
        return 0;
    }
    //中线直线判断
    uint8 Black_num = 0;
    float k = ((float)point[2][0] - (float)point[0][0]) / ((float)point[2][1] - (float)point[0][1]);
    for (uint8 i = point[0][1]; i <= point[2][1]; ++i)
    {
        if(imgOSTU[i][(uint8)(point[2][0] + k * (i - point[0][1]))] != White)
        {
            Black_num++;
        }
    }
//    qout<<Black_num;
    if(Black_num < Deal_H/2)
    {
        start_center_x = point[0][0];
        start_center_y = point[0][1];
        end_center_x = point[2][0];
        end_center_y = point[2][1];
        for (uint8 i = start_center_y; i <= end_center_y; ++i)
        {
            mid_line[i] = (float)(start_center_x + k * (i - start_center_y));
            imgOSTU[i][(uint8)mid_line[i]] = Control_line;
        }
        IF = crossroads;
        return end_center_y;
    }
    else
    {
        return 0;
    }
    }
    float White_num[12] = {0};
    float Black_num[12] = {0};
    //顺时针四边缘统计
    int point[6][2] = {{0,0},{0,0},{0,0},{0,0},{0,0},{0,0}};
    int j = 0;
    int count_piont = 0;
    float k_count[12] = {0};
    if(r_lost_num)
    for(int i = 0; i <= r_lost_num-1  && j<=5;i++)
    {
        point[j][0] = Deal_Right;
        point[j][1] = r_center[i];
        j++;
    }
    if(t_lost_num)
    for(int i = t_lost_num-1; i >= 0  && j<=5;i--)
    {
        point[j][0] = t_center[i];
        point[j][1] = Deal_Top;
        j++;
    }
    if(l_lost_num)
    for(int i = l_lost_num-1; i >= 0  && j<=5;i--)
    {
        point[j][0] = Deal_Left;
        point[j][1] = l_center[i];
        j++;
    }
    count_piont = j-1;
    if(count_piont > 5)
    {
        return 0;
    }
    for(int i = 0;i <= b_lost_num-1 && i < 2;i++)
    {
        for(int j = 0;j <= count_piont && j < 6;j++)
        {
            int start_x = b_center[i];
            int start_y = start_center_y;
            int end_x = point[j][0];
            int end_y = point[j][1];
            int index = 6*i+j;
            if (end_y <= start_y)
            {
                 Black_num[index] = 0;
                 White_num[index] = 0;
                 continue;  // 跳过无效点对
            }
            float k = ((float)end_x - (float)start_x) / ((float)end_y - (float)start_y);
            k_count[index] = k;
            uint8 y_start = (start_y < end_y) ? start_y : end_y;
            uint8 y_end = (start_y < end_y) ? end_y : start_y;
            for (uint8 y = start_y; y <= end_y; ++y)
            {
                int x = (float)(start_x + k * (y - start_y));
                if (x > Deal_Right) 
                {
                  x = Deal_Right;  // 钳制到有效范围
                } 
                else if (x < Deal_Left) 
                {
                  x = Deal_Left;
                }
                
                if(imgOSTU[y][x] == White)
                {
                    White_num[index] += Length_5cm[0]/Length_5cm[y];
                }
                else
                {
                    Black_num[index] += Length_5cm[0]/Length_5cm[y];
                    imgOSTU[y][x] = Judge_line;
                }
                
            }
        }
    }
    int Straight_index = 0;
    float Straight_scale = 0;
    for(int i = 0;i <= b_lost_num-1 && i < 2;i++)
    {
        for(int j = 0;j <= count_piont && j < 6;j++)
        {
            int index =  6*i+j;
            float scale = 0;

            if(White_num[index] >  15 && White_num[index] > Black_num[index])
            {
                scale = (float)White_num[index]/((float)White_num[index]+(float)Black_num[index]);
            }
            else
            {
                scale = 0;
            }

            if(scale > Straight_scale)
            {
                Straight_scale = scale;
                Straight_index = index;
            }
            else if(scale >=  Straight_scale*0.7 && scale != 0)
            {
                int index_y = point[(int)index%6][1];
                int Straight_y = point[(int)Straight_index%6][1];

                if(index_y >= Straight_y - 10)
                {
                    if(nowDeviation*k_count[index] > 0 && nowDeviation*k_count[Straight_index] < 0)  //取误差斜率同号
                    {
                        Straight_scale = scale;
                        Straight_index = index;
                    }
                    else if(nowDeviation*k_count[index] < 0 && nowDeviation*k_count[Straight_index] > 0)  //取误差斜率同号
                    {
                        Straight_scale = Straight_scale;
                        Straight_index = Straight_index;
                    }
                    else
                    {
                        float index_k = nowDeviation-k_count[index];
                        float Straight_k = nowDeviation-k_count[Straight_index];
                        index_k = index_k > -index_k ? index_k : -index_k;
                        Straight_k = Straight_k > -Straight_k ?Straight_k:-Straight_k;
                        if(index_k < Straight_k)
                        {
                            Straight_scale = scale;
                            Straight_index = index;
                        }
                    }
                }

            }
        }
    }

    start_center_x = b_center[(int)Straight_index/6];
    end_center_x = point[(int)Straight_index%6][0];
    end_center_y = point[(int)Straight_index%6][1];
    if(end_center_y <= start_center_y)
    {
      return 0;
    }
    float k = ((float)end_center_x - (float)start_center_x) / ((float)end_center_y - (float)start_center_y);
    for (uint8 i = start_center_y; i <= end_center_y; ++i)
    {
        mid_line[i] = (float)(start_center_x + k * (i - start_center_y));
        if (mid_line[i] > Deal_Right) 
        {
          mid_line[i] = Deal_Right;  // 钳制到有效范围
        } 
        else if (mid_line[i] < Deal_Left) 
        {
          mid_line[i] = Deal_Left;
        }
        imgOSTU[i][(uint8)mid_line[i]] = Control_line;
    }
    IF = crossroads;
    return end_center_y;

    return 0;
}


/**
 * @brief 断路检测函数
 * @details 检测赛道中的断路区域（赛道消失），通过以下特征判断：
 *
 *          前置条件：
 *          - 断路次数未达上限（disappear_num < disappear_total）
 *          - 未识别到停车线或为实线直道
 *          - 起点在底部（start_center_y <= Deal_Bottom+3）
 *          - 底部丢失区域数<=1，底部宽度正常
 *          - 无左右/上下大面积聚点（排除十字/环岛）
 *
 *          断路特征（Dis_appear 缓冲数组）：
 *          - Dis_appear=0：无断路特征
 *          - Dis_appear=1：有断路特征（底部白点少，赛道消失）
 *          - Dis_appear=2：强断路特征（底部几乎全黑）
 *
 *          连续多帧（>=4帧）出现断路特征时，确认为断路：
 *          - 记录起始偏航角和里程
 *          - 进入断路状态机（status=1）
 *
 * @return  1 = 检测到断路
 *          0 = 未检测到断路
 */
uint8 Disappear_detection()
{
    static int Dis_appear[5] = {0}; //断路特征缓冲数组
    static int offsets_angle[5] = {0}; //倾斜角度补偿组
    
    Dis_appear[4] = Dis_appear[3];
    Dis_appear[3] = Dis_appear[2];
    Dis_appear[2] = Dis_appear[1];
    Dis_appear[1] = Dis_appear[0];
    if(
      disappear_num < disappear_total&& //少于断路数目
      (Stop_line == 0 || dis_Solidline) &&  //没有获取边缘巡线特征
      start_center_y <= Deal_Bottom+3 &&
      b_lost_num <= 1 &&  //单个或无底部特征
      b_lost_tip <= white_width[start_center_y]*3/2 &&   //底部宽度正常
      EXTERN_sum[LR] <= 50 && EXTERN_sum[UD] <= 50 &&
      Dis_appear[1] >= 1 &&//上一帧满足断路特征
      imgOSTU[Lost_Bottom][Lost_Right] != Lost_line && imgOSTU[Lost_Bottom][Lost_Left] != Lost_line
      )
    {
      int white_num = 0;
      for(uint8 i = Deal_Bottom+5;i <= Deal_H/2;i++)
      {
        white_num += white_num_row[i]; //统计底部白点
      }
      if(white_num <= 3)
      {
        Dis_appear[0] = 2;
      }
      else
      {
        Dis_appear[0] = 1;
      }
    }
    else if(
      (disappear_num < disappear_total)&& //少于断路数目
      (Stop_line == 0 || dis_Solidline)&&  //没有获取边缘巡线特征
      start_center_y <= Deal_Bottom + 3 &&  //白底起点不为0
      b_lost_num == 1 &&  //单个底部特征
      b_lost_tip <= white_width[start_center_y]*3/2 &&   //底部宽度正常
      EXTERN_sum[LR] <= 50 && EXTERN_sum[UD] <= 50 &&
      imgOSTU[Lost_Bottom][Lost_Right] != Lost_line && imgOSTU[Lost_Bottom][Lost_Left] != Lost_line
      )
    {
      if(nowDeviation == Deviation_limit || nowDeviation == -Deviation_limit)
      {
        if(EXTERN_L || EXTERN_R || dis_Solidline)
        {
           Dis_appear[0] = 1;
        }
        else
        {
            Dis_appear[0] = 0;
        }
      }
      else
      {
         Dis_appear[0] = 1;
      }
        if(Dis_appear[1] == 1 ) //连续断路特征
        {
        for(uint8 i = 0;i <= hightest;i++)
        {
            if(white_num_row[i] > 2*white_width[i])  //判断赛道不过宽
            {
                Dis_appear[0] = 0;
                break;
            }
            else if(white_num_row[i] == 0)  //限制断路尽头高度
            {
                if(i >= 50)
                {
                    Dis_appear[0] = 0;
                }
                else if(i < Deal_Bottom+15)
                {
                  int white_num = 0;
                  for(int y=i;y<=Deal_Top;y++)
                  {
                    white_num += white_num_row[y];
                    if(white_num>=0)
                    {
                      Dis_appear[0] = 0;
                      break;
                    }
                  }
                    if(white_num==0)
                    {
                    Dis_appear[0] = 2;
                    }
                }
                else
                {
                    Dis_appear[0] = 1;
                }
                break;
            }
        }
        }
    }
    else
    {
        Dis_appear[0] = 0;
    }
       if(Disappear_angle_L[disappear_num] != 0 && runState != TEST && run_dir == Left && 
         (imu_data.yaw - Start_angle > Disappear_angle_L[disappear_num] + 45 || imu_data.yaw - Start_angle < Disappear_angle_L[disappear_num] - 45))
      {
        return 0;
      }
      if(Disappear_angle_R[disappear_num] != 0 && runState != TEST && run_dir == Right && 
         (imu_data.yaw - Start_angle > Disappear_angle_R[disappear_num] + 45 || imu_data.yaw - Start_angle < Disappear_angle_R[disappear_num] - 45))
      {
        return 0;
      }
    if(Dis_appear[0] == 1)        //存在长白道，进行巡线
        {
        get_start_point();
        end_center_y = 0;
        uint8 l_found = 0,r_found = 0;//清零
        int32 l_point = 0,r_point = 0;
        end_center_y = 0;
        for(int i = Deal_Top; i >= Deal_Bottom;i--)
        {
            if(white_num_row[i] >= 3 && white_num_row[i+1] <= 3)
            {
              end_center_y = i;
              for(int j = i;j >= Deal_Bottom;j--)
              {
                if(white_num_row[i] > 2*white_width[i])
                {
                   end_center_y = 0;
                   break;
                }
              }
                break;
            }
        }
        if(end_center_y >= 10)
        {
            for (uint8 i = 0; i < XX-1; i++)
            {
                if (imgOSTU[end_center_y][i+1] == White && imgOSTU[end_center_y][i] != White)
                {//找到左边起点
                    l_point = i;
                    l_found = 1;
                    break;
                }
            }
            //从右向左，先找黑白跳变点
            for (uint8 i = XX; i > 0+1; i--)
            {
                if (imgOSTU[end_center_y][i-1] == White && imgOSTU[end_center_y][i] != White)
                {//找到右边起点
                    r_point = i;
                    r_found = 1;
                    break;
                }
            }
        }
        if(l_found && r_found)//找到左右起点
            {
            end_center_x = (int)(l_point+r_point)/2;
            float k = ((float)end_center_x - (float)start_center_x) / ((float)end_center_y - (float)start_center_y);
            for (uint8 i = start_center_y; i <= end_center_y; ++i)
            {
                mid_line[i] = (float)(start_center_x + k * (i - start_center_y));
                imgOSTU[i][(uint8)mid_line[i]] = Control_line;
            }
            }
        Stop_line = end_center_y;
        }
    offsets_angle[4] = offsets_angle[3];
    offsets_angle[3] = offsets_angle[2];
    offsets_angle[2] = offsets_angle[1];
    offsets_angle[1] = offsets_angle[0];
    offsets_angle[0] = kbmid[0];
    if(Dis_appear[1] != 1 && Dis_appear[2] != 1 && Dis_appear[3] != 1 && Dis_appear[4] != 1)
    {
      return 0;
    }
    if(Dis_appear[0] == 2 && Dis_appear[1]+Dis_appear[2]+Dis_appear[3]+Dis_appear[4] >= 4)  //三帧断路特征
    {
      if(Disappear_angle_L[disappear_num] != 0 && runState != TEST && run_dir == Left && 
         (imu_data.yaw - Start_angle > Disappear_angle_L[disappear_num] + 45 || imu_data.yaw - Start_angle < Disappear_angle_L[disappear_num] - 45))
      {
        return 0;
      }
      if(Disappear_angle_R[disappear_num] != 0 && runState != TEST && run_dir == Right && 
         (imu_data.yaw - Start_angle > Disappear_angle_R[disappear_num] + 45 || imu_data.yaw - Start_angle < Disappear_angle_R[disappear_num] - 45))
      {
        return 0;
      }
        IF = disappear;
        elements_index++;
        disappear_num++;
//        Disappear_Zero = imu_data.yaw + (offsets_angle[4]*4+offsets_angle[3]*3+offsets_angle[2]*2+offsets_angle[1]*1)/2;
//        Disappear_Zero = 0;
        Disappear_Zero =  imu_data.yaw;

        Disappear_Position = Length;
        return 1;
    }
    else
    {
        return 0;
    }
}

/**
 * @brief 断路处理总调度（状态机）
 * @details 断路处理状态机，管理断路区域的完整通过过程：
 *
 *          状态机流程：
 *          status=0 → Disappear_detection()  断路检测
 *          status=1 → 纯黑区行驶            依靠偏航角保持方向
 *                      - 根据 Disappear_Dir_L/R 参数控制偏航
 *                      - 行驶超过指定距离后进入status=2
 *          status=2 → 调整驶入角度            偏正车头对准赛道
 *                      - 使用修正角度参数
 *                      - 检测到白线（底部连续白点行）后进入status=3
 *          status=3 → 找到白线，恢复巡线      重新搜索边界并画中线
 *                      - 检测到底部白点恢复正常时退出断路状态
 *
 * @return  status 当前断路状态（0/1/2/3）
 *          0 = 无断路或断路处理完成
 */
uint8 Deal_disappear()
{
    int status = disappear_flag;
    if(status == 0)
    {   Disappear_Zero = Start_angle;
        status = Disappear_detection(); //初步识别断路，存在白点状态
    }
    if(status || Write_Dir)
    {
        Disappear_Yaw = imu_data.yaw - Disappear_Zero; //断路拐角
        Disappear_Length = Length - Disappear_Position;  //断路路程
    }
    if(status == 1) //纯黑色区域，真正断路地带,纯偏航角度1
    {
        if(run_dir == Left)  //获取断路偏航角度
        {
            nowDeviation =  (float)Disappear_Dir_L[disappear_num-1][0] - Disappear_Yaw;
        }
        else if(run_dir == Right)
        {
            nowDeviation =  (float)Disappear_Dir_R[disappear_num-1][0] - Disappear_Yaw;
        }

        //超过行驶路程判断进入下一个状态
        if(run_dir == Left && Disappear_Length >= Disappear_Dir_L[disappear_num-1][2])
        {
            status = 2;
        }
        else if(run_dir == Right && Disappear_Length >= Disappear_Dir_R[disappear_num-1][2])
        {
            status = 2;
        }

    }
    if(status == 2) //即将走出纯黑区，偏正驶入角度
    {

        if(run_dir == Left)
        {
            nowDeviation =  (float)Disappear_Dir_L[disappear_num-1][1] - Disappear_Yaw;
        }
        else if(run_dir == Right)
        {
            nowDeviation =  (float)Disappear_Dir_R[disappear_num-1][1] - Disappear_Yaw;
        }

        //判断找到白线，进入巡线状态
        if(nowDeviation > -80 || nowDeviation < 80)
        {
            int32 Black_row = 0;
            uint8 Black_end = YY;

            for(uint8 i = YY;i >= 30;i--)
            {
                if(white_num_row[i] >= 5)
                {
                    for(uint8 k = i;k >= 30;k--)
                    {
                        if(white_num_row[k] >= 3)
                        {
                            Black_row++;
                        }
                        else
                        {
                            Black_end = k+1;
                            break;
                        }
                    }
                    if(Black_row >=5 && Black_end)
                    {
                        status = 3;
                    }
                }
            }
        }

    }
    if(status == 3)
    {
        uint8 l_found = 0,r_found = 0;//清零
        int32 l_point = 0,r_point = 0;
        end_center_y = 0;
        for(uint8 i = Deal_Top; i >= Deal_Bottom+20;i--)
        {
            if(white_num_row[i] >= 3)
            {
                end_center_y = i;
                break;
            }
        }
        if(end_center_y)
        {
            for (uint8 i = 0; i < XX-1; i++)
                    {
                        if (imgOSTU[Deal_Top][i+1] == White && imgOSTU[Deal_Top][i] != White)
                        {//找到左边起点
                            l_point = i;
                            l_found = 1;
                            break;
                        }
                    }
                    //从右向左，先找黑白跳变点
                    for (uint8 i = XX; i > 0+1; i--)
                    {
                        if (imgOSTU[Deal_Top][i-1] == White && imgOSTU[Deal_Top][i] != White)
                        {//找到右边起点
                            r_point = i;
                            r_found = 1;
                            break;
                        }
                    }
        }
        if(l_found && r_found)//找到左右起点
        {
            end_center_x = (int)(l_point+r_point)/2;
            start_center_x = (Deal_Left + Deal_Right)/2;
            start_center_y = Deal_Bottom;
            float k = ((float)end_center_x - (float)start_center_x) / ((float)end_center_y - (float)start_center_y);
            for (uint8 i = start_center_y; i <= end_center_y; ++i)
            {
                mid_line[i] = (float)(start_center_x + k * (i - start_center_y));
                imgOSTU[i][(uint8)mid_line[i]] = Control_line;
            }
        }
        Stop_line = end_center_y;


        for(uint8 i = Deal_Bottom + 30;i >= Deal_Bottom + 20;i--)
        {
            if(white_num_row[i] >= 5)
            {
                status = 0;
            }
        }
    }
    if(status)
    {
      IF = disappear;
    }
    return status;
}
