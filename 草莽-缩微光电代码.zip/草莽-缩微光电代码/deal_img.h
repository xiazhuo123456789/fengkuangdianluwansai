/**
 * @file    deal_img.h
 * @brief   图像处理模块头文件 - 缩微光电智能车
 * @details 定义图像处理所需的宏、枚举类型和全局变量声明。
 *          主要功能包括：二值化、八邻域边界巡线、环岛识别与处理、
 *          十字路口处理、停车线检测、断路检测等。
 *          预定前瞻10-30cm，左右各10cm的视野。
 * @note    图像坐标系：左下角为原点，X轴向右，Y轴向上
 */
#ifndef CODE_DEAL_IMG_H_
#define CODE_DEAL_IMG_H_
#include "zf_common_headfile.h"

/*============================================================================
 *                          图像尺寸与坐标宏定义
 *============================================================================*/

/* 处理图像尺寸（二值化后的有效区域）*/
#define XM MT9V03X_W       // 处理图像 宽度（像素列数）
#define YM MT9V03X_H       // 处理图像 高度（像素行数）
#define XX XM-1            // 处理图像 最大列下标（XM-1）
#define YY YM-1            // 处理图像 最大行下标（YM-1）

/* 原始图像尺寸 */
#define IMG_W  MT9V03X_W   // 原始图像 宽度（像素列数）
#define IMG_H  MT9V03X_H   // 原始图像 高度（像素行数）
#define _IMG_W IMG_W-1     // 原始图像 最大列下标
#define _IMG_H IMG_H-1     // 原始图像 最大行下标

/* 兼容性别名 */
#define COL IMG_W           // 原始图像 列数
#define ROW IMG_H           // 原始图像 行数
#define _COL_IMG_W          // 原始图像 最大列下标（兼容宏）
#define _ROW _IMG_H         // 原始图像 最大行下标（兼容宏）

/* 图像总像素数 */
#define IMG_SIZE (IMG_W * IMG_H)  // 原始图像总像素数
#define MAP_SIZE (YM * XM)        // 处理图像总像素数

/*============================================================================
 *                    八邻域处理区域边界定义
 *============================================================================*/
/*
 * 八邻域巡线的有效处理区域，在原始图像基础上内缩2行/列，
 * 避免边界溢出。四周预留的黑框用于边缘丢失特征（Lost_line）标记。
 *
 *  示意图：
 *   Deal_Top    ─────────────────────  (YY-8)
 *               │  有效处理区域      │
 *   Deal_Bottom ─────────────────────  (5)
 *               Deal_Left    Deal_Right
 *                (2)         (XX-2)
 */
#define Deal_Left   2        // 八邻域处理区域 最左侧列下标
#define Deal_Right  XX-2     // 八邻域处理区域 最右侧列下标
#define Deal_Bottom 5        // 八邻域处理区域 最底端行下标
#define Deal_Top    YY-8     // 八邻域处理区域 最顶端行下标

/* Lost_line 标记区域（比处理区域再外扩2像素，用于标记边界丢失点）*/
#define Lost_Left   Deal_Left - 2    // 左侧丢失标记列
#define Lost_Right  Deal_Right + 2   // 右侧丢失标记列
#define Lost_Bottom Deal_Bottom - 2  // 底部丢失标记行
#define Lost_Top    Deal_Top + 2     // 顶部丢失标记行

/*============================================================================
 *                        像素值与标记色定义
 *============================================================================*/
/*
 * 二值化图像中各像素值的含义：
 *   Black(0)      - 黑色，赛道外区域或边界
 *   White(255)    - 白色，赛道内区域
 *   Control_line  - 红色，计算出的中线（控制线）
 *   Left_line     - 绿色，左边界线
 *   Right_line    - 蓝色，右边界线
 *   Lost_line     - 紫色，边界丢失标记线
 *   Judge_line    - 青色，判断辅助线（用于环岛/十字等特征判断）
 *   Make_up       - 粉色，虚线补线标记
 *   LandR         - 橙色，左右聚点标记（同时被左右边界经过的点）
 */
#define Black 0            // 黑色 - 赛道外/边界
#define White 255          // 白色 - 赛道内
#define Control_line 1     // 红色 - 中线（控制线）
#define Left_line 2        // 绿色 - 左边界线
#define Right_line 3       // 蓝色 - 右边界线
#define Lost_line 4        // 紫色 - 边界丢失标记
#define Judge_line 5       // 青色 - 判断辅助线
#define Make_up 6          // 粉色 - 虚线补线
#define LandR 7            // 橙色 - 左右聚点
#define USE_num YM*4       // 八邻域边界点数组最大容量（每行4个点）

/*============================================================================
 *                          枚举类型定义
 *============================================================================*/

/**
 * @brief 赛道类型标志位
 * @details 用于标识当前图像识别出的赛道类型，指导巡线策略选择
 */
enum ImgFlag
{
    straightlineS,   // 短直道 - 普通直道段
    straightlineL,   // 长直道 - 较长的直道段（可用于停车线判断）
    curve,           // 折角弯道 - 左右边界丢失导致的弯道
    annulus_l,       // 左环岛 - 环岛开口朝左
    annulus_r,       // 右环岛 - 环岛开口朝右
    crossroads,      // 十字路口
    startline,       // 停车线（起跑线）
    disappear,       // 断路 - 赛道消失区域
};

/**
 * @brief 元素处理模式
 * @details 控制是否启用赛道元素（环岛、断路、停车线）的识别
 */
typedef enum Elements_Mode
{
    NO,    // 不启用元素识别（仅基础巡线）
    YES,   // 启用元素识别
} Elements_Mode;

/**
 * @brief 元素锁定类型
 * @details 用于锁定当前正在处理的元素类型，防止多种元素同时触发
 */
typedef enum Elements_Lock
{
    Empty_,       // 空状态，无元素锁定
    Annulus_,     // 环岛锁定
    Disappear_,   // 断路锁定
    Stopline_,    // 停车线锁定
} Elements_Lock;

/**
 * @brief 环岛巡线模式
 * @details 控制环岛内的巡线策略
 */
typedef enum Annulus_Mode
{
    Differential,  // 差速模式（通过差速控制转向）
    Tracing,       // 纯巡线模式（通过中线偏差控制转向）
} Annulus_Mode;

/*============================================================================
 *                        全局变量声明 - 元素状态控制
 *============================================================================*/

/* 元素识别控制 */
extern volatile Elements_Mode elements_Mode;   // 元素识别模式开关（YES/NO）
extern volatile Elements_Lock elements_Lock[10]; // 元素锁定队列（防止多元素冲突）
extern volatile Annulus_Mode Annulus_mode;      // 环岛巡线模式（差速/巡线）
extern int elements_index;                      // 当前元素锁定队列索引

/* 赛道类型标志 */
extern enum ImgFlag IF;     // 当前帧赛道类型
extern enum ImgFlag IF_L;   // 上一帧赛道类型

/* 环岛相关 */
extern uint8 Annulus_flag;          // 环岛状态机标志（0=未识别, 1=识别, 2=驶入, 3=驶离）
extern int Annulus_Curvature[5];    // 环岛曲率参数（控制环岛内转弯幅度）
extern int Annulus_num;             // 环岛计数器（第N个环岛）
extern int Curvature;               // 当前曲率值

/* 停车线相关 */
extern uint8 stop_num;              // 停车线检测计数
extern uint8 stopline_flag;         // 停车线识别标志（1=已识别过停车线）

/*============================================================================
 *                        全局变量声明 - 二值化与阈值
 *============================================================================*/

extern uint8_t nowThreshold;        // 当前OSTU二值化阈值
extern uint8_t previousThreshold;   // 上一帧二值化阈值（用于平滑）
extern int minGrayscale;            // 灰度最小值下限（防止过暗）
extern int maxGrayscale;            // 灰度最大值上限（防止过亮）
extern uint8_t minThreshold;        // 阈值下限保护
extern uint8_t maxThreshold;        // 阈值上限保护
extern int minGray;                 // 当前帧实际最小灰度值
extern int maxGray;                 // 当前帧实际最大灰度值

/* 分区域阈值（上/中/远三段不同阈值，适应不同距离的曝光差异）*/
extern uint8 img_threshold_group[3]; // [0]=近景阈值 [1]=中景阈值 [2]=远景阈值
extern uint8 close_Threshold;       // 近景阈值偏移量（加）
extern uint8 far_Threshold;         // 远景阈值偏移量（减）
extern uint8 mid_Threshold;         // 中景阈值偏移量（减）

extern uint16 EXP_TIME;             // 曝光时间（微秒）
extern int UD_OFFSET_DEF;           // 上下偏移补偿默认值

/*============================================================================
 *                        全局变量声明 - 图像数据
 *============================================================================*/

extern uint8 imgGray[IMG_H][IMG_W];    // 原始灰度图像
extern uint8 img2wifi[IMG_H][IMG_W];   // 无线传输图像（用于WiFi图传）
extern uint8 imgOSTU[YM][XM];          // 二值化处理后的图像（主处理对象）
extern uint8 imgTran[IMG_H][IMG_W];    // 虚线补线中间图像（方向标记图）

/* 白点统计 */
extern uint8 white_num_row[YM];        // 每行白点数量（用于赛道宽度判断）
extern uint8 white_num_col[XM];        // 每列白点数量（用于赛道边界迁移）

/* 中线数据 */
extern uint8 mid_line[YM];             // 中线X坐标数组（每行一个X值）

/*============================================================================
 *                    全局变量声明 - 起点与终点坐标
 *============================================================================*/

/* 巡线起点（底部搜索到的左右边界中点）*/
extern uint8 start_center;             // 起点中心X（上一帧）
extern uint8 start_center_x;           // 起点中心X坐标
extern uint8 start_center_y;           // 起点中心Y坐标（搜索起始行）
extern uint8 start_point_l;            // 左边界起点X坐标
extern uint8 start_point_r;            // 右边界起点X坐标

/* 巡线终点（中线顶部端点）*/
extern uint8 end_center_x;             // 终点中心X坐标
extern uint8 end_center_y;             // 终点中心Y坐标

/*============================================================================
 *                    全局变量声明 - 八邻域巡线数据
 *============================================================================*/

/* 左边界线数据 */
extern int points_l[(uint16)USE_num][2]; // 左边界点坐标数组 [i][0]=X, [i][1]=Y
extern float dir_l[(uint16)USE_num];     // 左边界生长方向（0~7，对应八邻域方向）
extern uint32 l_data_statics;            // 左边界有效点数量

/* 右边界线数据 */
extern int points_r[(uint16)USE_num][2]; // 右边界点坐标数组 [i][0]=X, [i][1]=Y
extern float dir_r[(uint16)USE_num];     // 右边界生长方向
extern uint32 r_data_statics;            // 右边界有效点数量

/* 极值点记录 */
extern uint8 hightest;                   // 巡线最高点Y坐标
extern uint16 leftmost[2];               // 最左点 [0]=X, [1]=Y
extern uint16 rightmost[2];              // 最右点 [0]=X, [1]=Y
extern uint16 topmost[2];                // 最顶点 [0]=X, [1]=Y

/*============================================================================
 *                    全局变量声明 - 边缘丢失特征
 *============================================================================*/

/*
 * 边缘丢失特征用于识别赛道类型：
 *   b_lost_tip/t_lost_tip/l_lost_tip/r_lost_tip - 四方向丢失的总像素数
 *   b_lost_num/t_lost_num/l_lost_num/r_lost_num - 四方向丢失区域的数量（最多2块）
 *   b_center/l_center/r_center/t_center         - 各方向丢失区域的中心坐标
 *
 * 例如：b_lost_num=2 表示底部有两块丢失区域（十字路口特征）
 *       l_lost_num=1 表示左侧有一块丢失区域（左弯道或左环岛）
 */
extern uint8 l_lost_tip;    // 左侧边界丢失总像素数
extern uint8 r_lost_tip;    // 右侧边界丢失总像素数
extern uint8 t_lost_tip;    // 顶部边界丢失总像素数
extern uint8 b_lost_tip;    // 底部边界丢失总像素数
extern uint8 b_lost_num;    // 底部丢失区域数量（0/1/2）
extern uint8 t_lost_num;    // 顶部丢失区域数量（0/1/2）
extern uint8 l_lost_num;    // 左侧丢失区域数量（0/1/2）
extern uint8 r_lost_num;    // 右侧丢失区域数量（0/1/2）

/* 丢失区域中心坐标（最多记录2块区域的中心）*/
extern uint16 b_center[3];  // 底部丢失区域中心 [0]=第1块X, [1]=第2块X, [2]=Y
extern uint16 l_center[3];  // 左侧丢失区域中心
extern uint16 r_center[3];  // 右侧丢失区域中心
extern uint16 t_center[3];  // 顶部丢失区域中心

extern uint8 Stop_line;     // 中线绘制高度（Stop_line行以上为有效巡线区域）
extern uint8 dis_Solidline; // 实线判断标志（1=左右边界均无丢失，为实线直道）

/*============================================================================
 *                    全局变量声明 - 环岛处理
 *============================================================================*/

extern float Out_Annulus_Length;   // 驶出环岛时的里程记录（防止重复识别）

/*============================================================================
 *                    全局变量声明 - 停车线处理
 *============================================================================*/

extern float Stopline_Position;    // 上次停车线位置的里程记录
extern float Stop_Length;          // 停车线处理相关里程

/*============================================================================
 *                    全局变量声明 - 断路处理
 *============================================================================*/

extern uint8 disappear_flag;       // 断路状态机标志（0=未识别, 1=纯黑区, 2=调整角度, 3=找到白线）
extern int disappear_num;          // 断路计数器（第N个断路区）
extern int disappear_total;        // 断路区总数限制
extern float Disappear_Length;     // 断路区行驶里程
extern float Disappear_Zero;       // 断路区起始偏航角
extern float Disappear_Yaw;        // 断路区内累计偏航角
extern float Start_angle;          // 发车时的偏航角（用于判断回到初始朝向）
extern int Disappear_angle_L[3];   // 左行断路区各段目标角度
extern int Disappear_angle_R[3];   // 右行断路区各段目标角度
extern int Disappear_Dir_L[3][3];  // 左行断路方向参数 [段][0]=初始角度 [1]=修正角度 [2]=行驶距离
extern int Disappear_Dir_R[3][3];  // 右行断路方向参数

/*============================================================================
 *                    全局变量声明 - 行驶方向与状态
 *============================================================================*/

/**
 * @brief 智能车行驶方向
 * @details 断路处理时用于选择不同的角度补偿策略
 */
typedef enum RUN_Dir
{
    Left,   // 左行
    Right,  // 右行
} RUN_Dir;
extern volatile RUN_Dir run_dir;   // 当前行驶方向

/*============================================================================
 *                    全局变量声明 - 辅助数据
 *============================================================================*/

/* 虚线补线相关 */
extern float white_width[YM];     // 每行赛道理论白点宽度（标定值，用于虚线补线判断）
extern float k1[YM];              // 像素-实际距离换算系数1（行方向）
extern float k2[YM];              // 像素-实际距离换算系数2（行方向）

/* 图像处理耗时 */
extern float start_time;          // 图像处理开始时间
extern float end_time;            // 图像处理结束时间
extern float deal_time;           // 图像处理总耗时

/* 图像处理状态 */
extern uint8 dealimg_finish_flag; // 图像处理完成标志
extern int deal_runing;           // 图像处理运行标志（防止重入）

/*============================================================================
 *                          函数声明
 *============================================================================*/

/*----- 图像预处理 -----*/
void standard(void);              // 图像处理模块初始化（重置所有状态标志）
uint8 getOSTUThreshold(void);     // 大津法计算二值化阈值
void Get_imgOSTU(void);           // 二值化处理（含腐蚀去噪、分区域阈值）

/*----- 虚线补线 -----*/
uint8 Dashedline_Makeup(void);    // 虚线区衔接弥补（白点迁移、断点补线）

/*----- 边界搜索 -----*/
uint8 get_start_point(void);      // 寻找左右边界起点（底部黑白跳变点）
uint8 search_l_r(uint8 start_l_x, uint8 start_l_y, uint8 start_r_x, uint8 start_r_y); // 八邻域探索左右边界线

/*----- 边缘特征与中线 -----*/
void Get_lost_tip(uint8 length);  // 获取四方位边缘丢失特征
void Get_start_center(void);      // 获取中线起点（处理底部复杂区域）
uint8 Get_top_straightline(void); // 绘制顶端直线中线
void Get_curve_line(uint8 x1, uint8 y1, uint8 x2, uint8 y2, uint8 n); // 绘制曲线中线
uint8 Left_curve_line(void);      // 左边界曲线中线
uint8 Right_curve_line(void);     // 右边界曲线中线

/*----- 停车线检测 -----*/
uint8 Get_stopline(void);         // 停车线识别

/*----- 环岛处理 -----*/
uint8 Get_Annulus(void);          // 环岛初步识别
uint8 Go_Annulus(void);           // 环岛处理总调度（状态机）

/*----- 十字路口处理 -----*/
uint8 Deal_crossroads(void);      // 十字路口识别与处理

/*----- 断路处理 -----*/
uint8 Disappear_detection(void);  // 断路检测
uint8 Deal_disappear(void);       // 断路处理总调度（状态机）

#endif // DEAL_IMG_H
